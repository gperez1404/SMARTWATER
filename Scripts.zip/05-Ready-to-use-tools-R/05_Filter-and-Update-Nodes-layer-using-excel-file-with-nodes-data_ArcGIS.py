# -*- coding: utf-8 -*-
"""
Created on Thu Jul 28 11:20:17 2022

This tool helps the user to filter a layer with nodes using an excel file 
with a lsit of nodes

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with the Python interpreter of ArcGIS Pro.

# location of python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 


###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#                                                     PACKAGES YOU NEED TO LOAD
###############################################################################
import os
import sys
import time
import math

import openpyxl
from openpyxl import load_workbook, Workbook

import pandas as pd
import arcpy
from arcpy.sa import *
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^    EMD OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

description_p1 = r'File path Nodes layer to filter (All Nodes):'
description_p2 = r'File path of Excel Work-book to filter Nodes'
description_p3 = r'Name of the Sheet with the nodes list'
description_p4 = r'Name of the field with the nodes ID (No quotation marks):'
description_p5 = r'Location to save result layer:'
description_p6 = r'Name of the result layer:'

list_p_descriptions = [description_p1,description_p2,description_p3,
                       description_p4,description_p5,description_p6]

default_values_p1  = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\SMARTW_all_nodes_SMI_C1TTTSY'
default_values_p2  = r'R:\03_GISdata\data_Gabriel\04-Tools\02-Python-Scripts\02-Input-files-R\Nodes_ Scenario_Huasco.xlsx'
default_values_p3  = r'Scenario_Huasco'                                                                                 
default_values_p4  = r'ID_CONN'                                                                                     
default_values_p5  = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Scratch.gdb'      
default_values_p6  = r'Nodes_Huasco_Scenario'      

list_of_keys =['p1','p2','p3','p4','p5','p6']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1  = arcpy.GetParameterAsText(0)
p2  = arcpy.GetParameterAsText(1)
p3  = arcpy.GetParameterAsText(2)
p4  = arcpy.GetParameterAsText(3)
p5  = arcpy.GetParameterAsText(4)
p6  = arcpy.GetParameterAsText(5)


###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                          Definition of Main() 
###############################################################################    

def main_function(p1,p2,p3,p4,p5,p6):
   
    time_before_execution = time.time()

    arcpy.AddMessage(r'p1 =' + str(p1))
    arcpy.AddMessage(r'p2 =' + str(p2))
    arcpy.AddMessage(r'p3 =' + str(p3))
    arcpy.AddMessage(r'p4 =' + str(p4))
    arcpy.AddMessage(r'p5 =' + str(p5))
    arcpy.AddMessage(r'p6 =' + str(p6))
    
    # Define global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    layer_Nodes         = p1
    Excel_file          = p2
    Excel_sheeet_name   = p3
    column_with_Nodes_ID= p4
    location_results   = p5
    result_file_name   = p6
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    arcpy.AddMessage(r'Loading layer with Nodes to be filtered, please wait....')
    
    # load the nodes layer:
    #..........................................................................
    List_of_fields_layer = [f.name for f in arcpy.ListFields(layer_Nodes)]    
    List_of_fields_layer.remove('Shape')   
    
    NP_Array_input_attribute_table =  arcpy.da.FeatureClassToNumPyArray (layer_Nodes,List_of_fields_layer,skip_nulls=False,null_value=-99999)
    df_input_Nodes= pd.DataFrame(NP_Array_input_attribute_table, columns = List_of_fields_layer)
    
    list_nodes_IDs_layer = df_input_Nodes['ID_CONN'].tolist()
    
    #..........................................................................
    
    arcpy.AddMessage(r'Loading excel file, please wait....')
    
    #Load excel sheet as data-frame object:
    #..........................................................................
    try:
        df_excel_file= pd.read_excel(Excel_file, sheet_name=Excel_sheeet_name)
    except ValueError:
        arcpy.AddMessage( r'Attempted file path: '  + Excel_file)
        arcpy.AddMessage( r'attempted Sheet name:' + Excel_sheeet_name)
        arcpy.AddMessage( r"Oops! ")
        arcpy.AddMessage( r'ERROR 101: you have introduced the wrong file location or the wrong Sheet name,  Try again...')
    #..........................................................................        
    
    arcpy.AddMessage(r'Checking inputs, please wait....')

    # Check that the input Sheet has the required fields otherwise launch an exception 
    #..........................................................................
    list_column_names = df_excel_file.columns.tolist()
    
    if not ( column_with_Nodes_ID in list_column_names):
        arcpy.AddMessage(r"ERROR 101: The column name specified by the user (" + column_with_Nodes_ID + r') does not exist in the specified excel file !')
        sys.exit(r"ERROR 101: The column name specified by the user (" + column_with_Nodes_ID + r') does not exist in the specified excel file !' )
    #..........................................................................    
    
    arcpy.AddMessage(r'Inputs Ok !')

    arcpy.AddMessage(r'Creating layer to save results, please wait....')
    
    # Make a copy of the input layer:
    #..........................................................................
    layer_filtered = os.path.join(location_results,result_file_name)
    arcpy.CopyFeatures_management(layer_Nodes, layer_filtered)
    #..........................................................................
    
    # Filter the input layer:
    #..........................................................................
    
    List_nodes_to_keep= df_excel_file[column_with_Nodes_ID].tolist()
    
    nodes_to_delete = list(set(list_nodes_IDs_layer).difference(List_nodes_to_keep))
    
    count=0
    Number_of_rows_to_delete = len(nodes_to_delete)
    with arcpy.da.UpdateCursor(layer_filtered, ['ID_CONN']) as cursor:
      for row in cursor:
          current_node = row[0]
          count=count+1
          if current_node in nodes_to_delete:
              cursor.deleteRow()
              if(count%10 == 0):
                  arcpy.AddMessage( r'Row ' + str(count) +  r' out of ' + str(Number_of_rows_to_delete)+' deleted')
                  elapsed_time = (time.time() - time_before_execution)
                  Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
                  Fraction_of_hours, hours =math.modf(Seconds/3600)
                  arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    
    arcpy.AddMessage(r'layer with nodes fitered successfully !')
    #..........................................................................
    
    # Print execution time in console:
    #..........................................................................
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
     
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    #..........................................................................
    
###############################################################################
#      ^      ^      ^      ^      ^      ^      ^      ^  Definition of Main() 
###############################################################################   

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################
    