# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 17:55:51 2022

@author: uqgpere2
"""

###############################################################################
#                        PACKAGES YOU NEED TO LOAD
###############################################################################

import os
import glob
import sys
import shutil
import warnings
import string
import math
import traceback
import re                                 

import openpyxl
from openpyxl import load_workbook, Workbook

import itertools
from itertools import permutations  

import arcpy
from arcpy.sa import *

import numpy as np
import pandas as pd

from decimal import Decimal

import datetime
import time 

from functools import partial
from functools import reduce


###############################################################################
#                                                     PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

# Description of inputs:
#..............................................................................
description_p1 = r'Layer with all nodes'
description_p2 = r'Name of ID field for nodes layer (No quotation marks)'
description_p3 = r'Location of the Cost raster file (ArcGID format)'
description_p4 = r'Location of the surface raster (DEM in ArcGID format)'
description_p5 = r'Location of the Environmental Restriction raster (ArcGID format) '
description_p6 = r'Location to create a new folder to save all the results (Folder)'
description_p7 = r'Folder name to save all the results (No spaces)'
#..............................................................................

list_p_descriptions = [description_p1,description_p2,description_p3,description_p4,
                       description_p5,description_p6,description_p7]

list_of_keys =['p1','p2','p3','p4','p5','p6','p7']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

# to consult the meaning of a paramter: dict_parameters.get('pX')

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                         Creation of functions
###############################################################################

#..............................................................................

def arcgis_table_to_df(in_fc, input_fields=None, query=""):
    """Function will convert an arcgis table into a pandas dataframe with an object ID index, and the selected
    input fields using an arcpy.da.SearchCursor.
    :param - in_fc - input feature class or table to convert
    :param - input_fields - fields to input to do a search cursor for retrieval
    :param - query - SQL query to grab appropriate values
    :returns - pandas.DataFrame"""
    OIDFieldName = arcpy.Describe(in_fc).OIDFieldName
    if input_fields:
        final_fields = [OIDFieldName] + input_fields
    else:
        final_fields = [field.name for field in arcpy.ListFields(in_fc)]
    data = [row for row in arcpy.da.SearchCursor(in_fc,final_fields,where_clause=query)]
    fc_dataframe = pd.DataFrame(data,columns=final_fields)
    fc_dataframe = fc_dataframe.set_index(OIDFieldName,drop=True)
    return fc_dataframe


#..............................................................................

#..............................................................................

def rename_fields(table, out_table, new_name_by_old_name):
    """ Renames specified fields in input feature class/table
    :table:                 input table (fc, table, layer, etc)
    :out_table:             output table (fc, table, layer, etc)
    :new_name_by_old_name:  {'old_field_name':'new_field_name',...}
    ->  out_table
    """
    existing_field_names = [field.name for field in arcpy.ListFields(table)]

    field_mappings = arcpy.FieldMappings()
    field_mappings.addTable(table)

    for old_field_name, new_field_name in new_name_by_old_name.items():
        if old_field_name not in existing_field_names:
            message = "Field: {0} not in {1}".format(old_field_name, table)
            raise Exception(message)

        mapping_index = field_mappings.findFieldMapIndex(old_field_name)
        field_map = field_mappings.fieldMappings[mapping_index]
        output_field = field_map.outputField
        output_field.name = new_field_name
        output_field.aliasName = new_field_name
        field_map.outputField = output_field
        field_mappings.replaceFieldMap(mapping_index, field_map)

    # use merge with single input just to use new field_mappings
    arcpy.Merge_management(table, out_table, field_mappings)
    return out_table

#..............................................................................

#..............................................................................
def create_new_numeric_field (inFeatures,N_field_Name,N_field_Alias,N_field_type,N_field_Precision,N_field_Scale,N_field_is_nullable):
    
    arcpy.AddField_management(in_table=inFeatures,
                              field_name=N_field_Name,
                              field_type=N_field_type,
                              field_precision=N_field_Precision,
                              field_scale=N_field_Scale,
                              field_alias=N_field_Alias,
                              field_is_nullable=N_field_is_nullable)
    
#..............................................................................

#..............................................................................
def create_new_text_field (inFeatures,N_field_Name,N_field_Alias,N_field_type,FieldLength,N_field_is_nullable):
    
    arcpy.AddField_management(in_table=inFeatures,
                              field_name=N_field_Name,
                              field_type=N_field_type,
                              field_length=FieldLength,
                              field_alias=N_field_Alias,
                              field_is_nullable=N_field_is_nullable)


#..............................................................................

#..............................................................................

def merge_2_layers(Layer_1,Layer_2,Field_to_identify_rows,Location_Temp_results,Result_layer):
    
    # Get the list of IDs Layer 1:
    #..............................................................................
    List_of_field_names = [f.name for f in arcpy.ListFields(Layer_1)]    
    List_of_field_names.remove('Shape')
        
    NP_Array_L1 =  arcpy.da.FeatureClassToNumPyArray (Layer_1,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_L1= pd.DataFrame(NP_Array_L1, columns = List_of_field_names)

    list_IDs_L1 = df_L1[Field_to_identify_rows].tolist()

    # Get the list of IDs Layer 2:
    #..............................................................................

    List_of_field_names = [f.name for f in arcpy.ListFields(Layer_2)]    
    List_of_field_names.remove('Shape')

    NP_Array_L2 =  arcpy.da.FeatureClassToNumPyArray (Layer_2,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_L2 = pd.DataFrame(NP_Array_L2, columns = List_of_field_names)

    list_IDs_L2 = df_L2[Field_to_identify_rows].tolist()

    # make a copy of L1:
    Temp_copy = os.path.join(Location_Temp_results, r'temp_copy_LCPs')    
    arcpy.CopyFeatures_management(Layer_1, Temp_copy)
     
    # Delete the rows that are repeated:
    list_Ids_repeated = list(set(list_IDs_L1) & set(list_IDs_L2))
    
    if (len(list_Ids_repeated)>0):    
    
        with arcpy.da.UpdateCursor(Temp_copy, [Field_to_identify_rows]) as cursor:
          for row in cursor:
              current_LCP = row[0]
              if current_LCP in list_Ids_repeated:
                  arcpy.AddMessage( r'Row deleted: ' + current_LCP)
                  cursor.deleteRow()

    # Merge the New LCPs to the copy:
    arcpy.management.Merge([Temp_copy,Layer_2],Result_layer)
    arcpy.AddMessage( r'Layer  : ' + str(Layer_1) + r' merged to: ' + str(Layer_2)+ r' !!')

#..............................................................................
    
#..............................................................................
def return_tuple_inputs_PCD_BL_gen(l1,l2,l3,l4,l5,l6,l7,l8,l9,l10):
    
    merged_list = [(l1[i],l2[i],l3[i],l4[i],l5[i],l6[i],l7[i],l8[i],l9[i],l10[i]) for i in range(0, len(l1))]
    
    return merged_list
#..............................................................................    

#..............................................................................

def Gen_PCD_rasters_and_BL_rasters_selected_nodes(Task_index,                # 1
                                                  path_layer_with_all_nodes, # 2
                                                  list_ID_nodes_as_text,     # 3
                                                  ID_field_nodes,            # 4 
                                                  location_PCD_BL_rasters,   # 5
                                                  path_file_with_cost_raster,# 6
                                                  path_file_with_DEM,        # 7 
                                                  location_temp_layers,      # 8
                                                  time_before_execution,     # 9
                                                  location_log_file):        #10
    
    arcpy.AddMessage('.......................................................')
    arcpy.AddMessage( r'Task # ' + str(Task_index +1) ) 
    arcpy.AddMessage( r'PCD and BL raster Generation' ) 
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write(  r'PCD and BL raster generation Task # ' + str(Task_index +1) + r' started at:' + str(Current_date) + r' '+ str(Current_time))
    
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    Number_of_nodes_current_task =len(list_ID_nodes_as_text)
    count_node=1
    for node in list_ID_nodes_as_text:
        
        ID_node_to_parse = node
        
        arcpy.AddMessage("Generating rasters for node with ID =" + str(ID_node_to_parse) )
        arcpy.AddMessage("Please wait....... ")
        
                            
        # Use the ID to select by attribute
    
        SQL_expression  = r'"'+ str(ID_field_nodes[0]) + r'"= ' +  str(ID_node_to_parse)
    
        # Create a new TEMP layer to save the selection
        layer_with_one_object = arcpy.MakeFeatureLayer_management(path_layer_with_all_nodes, r"node_" + str(ID_node_to_parse), SQL_expression)
        
        # save the TEMP layer 
        source_node_name = r'node_' + str(ID_node_to_parse)
        source_node_path = os.path.join(location_temp_layers,source_node_name)
        
        arcpy.CopyFeatures_management(layer_with_one_object, source_node_path)
    
        arcpy.AddMessage("Temp Layer for node with ID = "+ str(ID_node_to_parse) + " was created successfully !")
                    
        # Create inputs to execute the PathDistance() tool 
        
        Backlink_file_name= r'Backlink_to_node_' + str(ID_node_to_parse)
        Backlink_raster_path = os.path.join(location_PCD_BL_rasters,Backlink_file_name)
        
        PCD_raster_file_name= r'PCD_to_node_' + str(ID_node_to_parse)
        PCD_raster_path =os.path.join(location_PCD_BL_rasters,PCD_raster_file_name)
                    
        arcpy.AddMessage( "Generating PCD raster and Backlink raster ....")
        arcpy.AddMessage( "this takes several minutes, please wait.......")
        PCD_raster = arcpy.sa.PathDistance(in_source_data=source_node_path,
                                           in_cost_raster=path_file_with_cost_raster,
                                           in_surface_raster=path_file_with_DEM,
                                           in_horizontal_raster="",
                                           horizontal_factor="BINARY 1 45",
                                           in_vertical_raster="",
                                           vertical_factor="BINARY 1 -30 30",
                                           maximum_distance=None,
                                           out_backlink_raster=Backlink_raster_path,
                                           source_cost_multiplier="",
                                           source_start_cost="",
                                           source_resistance_rate="",
                                           source_capacity="",
                                           source_direction="")
        PCD_raster.save(PCD_raster_path)
        
        arcpy.AddMessage(" PCD raster and Backlink raster for node with ID = "+ str(ID_node_to_parse) + " created successfully !")
        
        elapsed_time = (time.time() - time_before_execution)
        Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
        Fraction_of_hours, hours =math.modf(Seconds/3600)
          
        arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
        
        arcpy.AddMessage('...........................')
        
        Current_date_time = str(datetime.datetime.now())
        Current_date = Current_date_time.split()[0]
        Current_time = Current_date_time.split()[1]
        
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write(r'PCD raster and Backlink raster for node with ID = ' + str(ID_node_to_parse) + r' (Task ' + str(Task_index +1) + r', node # ' + str(count_node) + r' out of ' + str(Number_of_nodes_current_task)+ r') '+ r'created at: ' + str(Current_date) + r' '+ str(Current_time))
            log_file.write('\n')
            log_file.write('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
            log_file.write('\n')
            log_file.write('...........................')
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        count_node = count_node+1
    
#..............................................................................    

#..............................................................................

def generate_LCP_layer(Task_index,
                       path_layer_with_all_nodes,
                       ID_field_nodes,
                       ID_node_to_parse,
                       location_PCD_BL_rasters,
                       location_temp_layers,
                       location_to_save_layer_LCPs,
                       time_before_execution_task):
    
    arcpy.AddMessage('...................................')
    arcpy.AddMessage( r'Task # ' + str(Task_index +1) + ' LCPs node ' + str(ID_node_to_parse)) 
    
    
    # Use the ID to select by attribute

    SQL_expression  = r'"'+ str(ID_field_nodes[0]) + r'"= ' +  str(ID_node_to_parse)

    # Create a new TEMP layer to save the selection
    layer_with_one_object = arcpy.MakeFeatureLayer_management(path_layer_with_all_nodes, r"node_" + str(ID_node_to_parse), SQL_expression)
    
    # save the TEMP layer 
    source_node_name = r'node_' + str(ID_node_to_parse)
    source_node_path = os.path.join(location_temp_layers,source_node_name)
    
    arcpy.CopyFeatures_management(layer_with_one_object, source_node_path)

    arcpy.AddMessage("Temp Layer for node with ID = "+ str(ID_node_to_parse) + " was created successfully !" + r' | Task ' + str(Task_index +1))
                
    # Create inputs to execute the PathDistance() tool 
    
    Backlink_file_name= r'Backlink_to_node_' + str(ID_node_to_parse)
    Backlink_raster_path = os.path.join(location_PCD_BL_rasters,Backlink_file_name)
    
    PCD_raster_file_name= r'PCD_to_node_' + str(ID_node_to_parse)
    PCD_raster_path =os.path.join(location_PCD_BL_rasters,PCD_raster_file_name)
    
    # create a temp layer with all the other nodes except for the source node:
            
    tempLayer_all_other_nodes= r"all_other_nodes_except_for_" + str(ID_node_to_parse)
    tempLayer_all_other_nodes_path=os.path.join(location_temp_layers,tempLayer_all_other_nodes)
    
    arcpy.CopyFeatures_management(path_layer_with_all_nodes, tempLayer_all_other_nodes_path)
            
    # Delete the source point from TEMP layer
    with arcpy.da.UpdateCursor(tempLayer_all_other_nodes_path, ID_field_nodes) as cursor:
        for point in cursor:
            if point[0] == int(ID_node_to_parse):
                cursor.deleteRow()
            
           
    # Here you execute the CostPathAsPolyline() tool to create
    # the file with Least Cost Polylines of the current node
    
    LCP_name = r'LCPs_source_node_' + str(ID_node_to_parse)
    LCP_path = os.path.join(location_temp_layers,LCP_name) 
    
    LCP = r'LCPs_node_' + str(ID_node_to_parse) 
    New_LCP_path= os.path.join(location_to_save_layer_LCPs,LCP)
    
    PathType = "EACH_ZONE" 

    # The  least cost polyline layer (LCP) has the following attributes:

    # OBJECT ID
    # PathCost 
    # DestID ->  WARNING !! This is not the ID of the end point of the line. This can be confusing becasue it is the opposite of how the line was drawn
    # Shape_Length 
    
    arcpy.AddMessage(r" Generating LCP polylines for node with ID = "+ str(ID_node_to_parse) + r' | Task ' + str(Task_index +1) )
    
    arcpy.sa.CostPathAsPolyline(in_destination_data= tempLayer_all_other_nodes_path,
                                in_cost_distance_raster= PCD_raster_path,
                                in_cost_backlink_raster= Backlink_raster_path,
                                out_polyline_features= LCP_path,
                                path_type= PathType, 
                                destination_field= str(ID_field_nodes[0]),
                                force_flow_direction_convention= "INPUT_RANGE")
    
     
    # Here you rename the attribute 'DestID' -> 'OriginID'
    
    dict_old_names_new_names = {}
    
    old_name = r'DestID'
    new_name = r'OriginID'
    
    dict_old_names_new_names[old_name] = new_name
    
    LCP = r'LCPs_node_' + str(ID_node_to_parse) 
    New_LCP_path= os.path.join(location_to_save_layer_LCPs,LCP)
    
    rename_fields(LCP_path, New_LCP_path, dict_old_names_new_names)
    
    #delte the Temp file:
    arcpy.management.Delete(LCP_path)

    LCP_path = New_LCP_path
                        
    # Here you add an attribute with the ID of the Source Node
    # to all the paths. The source node is the Destination node 
    # of each line
                        
    inFeatures = LCP_path
    fieldName  = "DestinID"
    fieldAlias = fieldName
    field_type = "SHORT"
    fieldPrecision = 12
    fieldScale = 0
    
    #  AddField 
    arcpy.AddField_management(in_table=inFeatures,
                              field_name=fieldName,
                              field_type=field_type,
                              field_precision=fieldPrecision,
                              field_scale=fieldScale,
                              field_alias=fieldAlias,
                              field_is_nullable="NULLABLE")
                    
    # Populate the new field DestinID' 
            
    ID_source_node = ID_node_to_parse
    field_to_modify = [fieldName]
    
    with arcpy.da.UpdateCursor(LCP_path, field_to_modify) as cursor:
        for row in cursor:
            row[0] = ID_source_node
            cursor.updateRow(row)
            
    # Here you add an attribute with the Path description to all
    # LCPs
    # 'PathDes' = 'From-xxxx-to-xxxx'
    
    # The start point of the line is the DestID and the end of the line
    # is the SourceID. This sounds counterintuitive but if you don't 
    # describe the line in this way the stack profiles will be 
    # created wrong (inverted)
    
    inFeatures = LCP_path
    fieldName  = "PathDes"
    fieldAlias = fieldName
    field_type = "TEXT"
    fieldLength = 20
    
    #  AddField 
    arcpy.AddField_management(in_table=inFeatures,
                              field_name=fieldName,
                              field_type=field_type,
                              field_length=fieldLength,
                              field_alias=fieldAlias,
                              field_is_nullable="NULLABLE")
                    
    # Populate the new field
    
    fields_to_use = ['OriginID','DestinID','PathDes']
    
    with arcpy.da.UpdateCursor(LCP_path, fields_to_use) as cursor:
        for row in cursor:
            ID_start_node= row[0]
            ID_end_node  = row[1]
            
            row[2]= str(r'From-' + str( ID_start_node ) + r'-to-'+ str(ID_end_node))
            cursor.updateRow(row)
    
    # Get the number of polylines and print it on screen 
    
    NP_Array_LCPs_attribute_table =  arcpy.da.FeatureClassToNumPyArray (LCP_path,["PathDes"],skip_nulls=False,null_value=-99999)
    df_LCPs_desciption = pd.DataFrame(NP_Array_LCPs_attribute_table, columns = ["PathDes"])
    list_of_existing_LCPs = df_LCPs_desciption['PathDes'].tolist()
    Number_of_LCPs=len(list_of_existing_LCPs)    
    
    
    arcpy.AddMessage(r"LCP polylines (one way) for node with ID = "+ str(ID_node_to_parse) + " generated successfully" + r' | Task ' + str(Task_index +1) )
    arcpy.AddMessage(r'Number of LCPs : ' + str(Number_of_LCPs) + r' | Task ' + str(Task_index +1))

    elapsed_time = (time.time() - time_before_execution_task)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
        
    arcpy.AddMessage('Elapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task ' + str(Task_index +1))
    arcpy.AddMessage('...................................')
    
#..............................................................................    

#..............................................................................

def generate_return_LCP_layer (Task_index,
                               path_layer_with_LCPs_one_way,
                               ID_key_layer,
                               location_temp_layers,
                               location_to_save_layer_LCPs,
                               time_before_execution):
    
    # Debugging:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    #path_layer_with_LCPs_one_way =r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_RESULTS_ADDING_2_NEW_NODES\Results_Task_1\LCPs_task_1.gdb\LCPs_node_237'
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # Load the attribute table of the LCP layer as df:
    #..........................................................................
    List_of_field_names_LCPs = [f.name for f in arcpy.ListFields(path_layer_with_LCPs_one_way)]    
    List_of_field_names_LCPs.remove('Shape')
    
    OIDField_LCPs = arcpy.Describe(path_layer_with_LCPs_one_way).OIDFieldName

    NP_Array_LCPs=  arcpy.da.FeatureClassToNumPyArray (path_layer_with_LCPs_one_way,List_of_field_names_LCPs,skip_nulls=False,null_value=-99999)
    df_LCPs = pd.DataFrame(NP_Array_LCPs, columns = List_of_field_names_LCPs)

    list_of_LCP_descriptions_one_way = df_LCPs['PathDes'].tolist()
    list_of_LCP_OBID_one_way = df_LCPs[OIDField_LCPs].tolist()
    
    Number_of_LCPs_one_way=len(list_of_LCP_OBID_one_way)
    
    #..........................................................................

    # Generate the list of LCP descriptions in the opposite way:
    #..........................................................................
    list_of_LCP_descriptions_return = list_of_LCP_descriptions_one_way.copy()
    list_of_LCP_descriptions_return = [r'From-' + ((s.strip('From-')).replace(r'-to-',r'-')).split(r'-')[1] + r'-to-' + ((s.strip('From-')).replace(r'-to-',r'-')).split(r'-')[0] for s in list_of_LCP_descriptions_return]
    #..........................................................................
    
    # Make the lists of inverted Origin-Destination IDs
    #..........................................................................
    list_of_Origins_return = df_LCPs['DestinID'].tolist()
    list_of_Destinations_return = df_LCPs['OriginID'].tolist()
    #..........................................................................
    
    # Make the list of Object IDs return LCPs:
    #..........................................................................
    Last_OID_one_way = list_of_LCP_OBID_one_way[Number_of_LCPs_one_way-1]
    list_of_LCP_OBID_return = []
    
    for i in range((Last_OID_one_way+1),(Last_OID_one_way+Number_of_LCPs_one_way)+1):
        list_of_LCP_OBID_return.append(i)
    #..........................................................................
    
    # Make df for return LCPs:
    #..........................................................................
    df_LCPs_return = df_LCPs.copy()
    df_LCPs_return.drop([OIDField_LCPs,'DestinID', 'OriginID','PathDes'], axis=1)
    
    df_LCPs_return[OIDField_LCPs] = list_of_LCP_OBID_return
    df_LCPs_return['OriginID'] = list_of_Origins_return
    df_LCPs_return['DestinID'] = list_of_Destinations_return
    df_LCPs_return['PathDes'] = list_of_LCP_descriptions_return
    #..........................................................................
    
    # Make a copy of the LCPs layer:
    #..........................................................................
    name_return_layer =r'LCPs_node_' + str(ID_key_layer) + r'_return'
    path_layer_return_LCPs = os.path.join(location_to_save_layer_LCPs,name_return_layer)
    arcpy.CopyFeatures_management(path_layer_with_LCPs_one_way, path_layer_return_LCPs)
    #..........................................................................
    
    # Replace values of copy layer:
    #..........................................................................
    
    # Replace the respective fields in the layer :

    fields_to_modify = [OIDField_LCPs,
                        'DestinID',
                        'OriginID',
                        'PathDes']

    row_count=0

    with arcpy.da.UpdateCursor(path_layer_return_LCPs, fields_to_modify) as cursor:
      
        for row in cursor:
            row[0]  = df_LCPs_return[OIDField_LCPs][row_count]
            row[1]  = df_LCPs_return['DestinID'][row_count]
            row[2]  = df_LCPs_return['OriginID'][row_count]
            row[3]  = df_LCPs_return['PathDes'][row_count]
            cursor.updateRow(row)
            row_count=row_count+1
    
    
    arcpy.AddMessage(r"Layer with return LCPs for node with ID = "+ str(ID_key_layer) + " generated successfully" + r' | Task ' + str(Task_index +1) )
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
        
    arcpy.AddMessage('Elapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task ' + str(Task_index +1))
    arcpy.AddMessage('...................................')
    #..........................................................................

#..............................................................................

#..............................................................................

def process_LCP_layer(Task_index,
                      ID_node_to_parse,
                      path_layer_with_LCPs,
                      path_layer_with_all_nodes,
                      path_file_with_DEM,
                      path_file_with_Environmental_restriction,
                      ID_field_nodes_layer,
                      location_to_save_temp_layers, 
                      location_to_save_stack_profiles,
                      location_to_save_csv_files,
                      file_path_to_save_deltaH_values,
                      file_path_to_save_EnvR_values,
                      time_before_execution,
                      location_log_file):
    
    # create the path to save the results: 
    #..........................................................................
    location_LCPs= os.path.dirname(os.path.abspath(path_layer_with_LCPs))
    Result_layer = os.path.join(location_LCPs, r'LCPs_node_' + str(ID_node_to_parse) + r'_with_attributes')
    #..........................................................................        
        
    # Get attributes nodes:
    #..........................................................................
    ID_field_nodes_layer=[ID_field_nodes_layer]
        
    # List of Node attributes to load
    list_node_attributes_to_load = [r'ID_CONN',r'ID_MCI', r'TYPE',r'NODE',r'Elevation_M', r'STATUS','NAME',r'Q_m3s']
    
    # Get a list of all the existing fields of the Nodes layer:
    #List_of_field_names_nodes_layer = [f.name for f in arcpy.ListFields(path_layer_with_all_nodes)]    
    
    NP_Array_Nodes_layer =  arcpy.da.FeatureClassToNumPyArray (path_layer_with_all_nodes,list_node_attributes_to_load,skip_nulls=False,null_value=-99999)
    df_Node_attributes = pd.DataFrame(NP_Array_Nodes_layer, columns = list_node_attributes_to_load)
    #..........................................................................
    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    # Existing Fields LCP layer:
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>

    Field_PathCost= r'PathCost'
    Field_description= r'PathDes'
    Existing_field_with_ID_origin_point = r'OriginID'
    Existing_field_with_ID_destination_point = r'DestinID'
    Field_PathLenght = r'Shape_Length'
    
    Field_to_match_tables=Field_description
    
    OIDField_LCPs = arcpy.Describe(path_layer_with_LCPs).OIDFieldName
    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    # New Fields LCP layer    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    
    # New Field 1 = 'EnvRes' | NUMERIC: 2 Decimals
    New_field_Environmental_restriction = r'EnvRes'  
    N_field_1_Name  =  New_field_Environmental_restriction
    N_field_1_Alias =  New_field_Environmental_restriction
    N_field_1_type = "DOUBLE"
    N_field_1_Precision = 12
    N_field_1_Scale = 2
    N_field_1_is_nullable= "NULLABLE"
    
    # New Field 2 = 'Delta_H' | NUMERIC: 2 Decimals
    New_field_Delta_H = r'Delta_H'  
    N_field_2_Name  = New_field_Delta_H 
    N_field_2_Alias = New_field_Delta_H 
    N_field_2_type = "DOUBLE"
    N_field_2_Precision = 12
    N_field_2_Scale = 2
    N_field_2_is_nullable= "NULLABLE"
    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    # Attributes Origin nodes:
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    
    # New Field 3 =  'O_MCI' | TEXT: 10 Characters
    New_field_with_origin_MCI_ID = r'O_MCI'    
    N_field_3_Name  = New_field_with_origin_MCI_ID 
    N_field_3_Alias = New_field_with_origin_MCI_ID 
    N_field_3_type = "TEXT"
    N_field_3_Length  = 10
    N_field_3_is_nullable= "NULLABLE"
    
    # New Field 4 =  'O_type' | TEXT: 40 Characters
    New_filed_with_origin_type = r'O_type'   
    N_field_4_Name  = New_filed_with_origin_type 
    N_field_4_Alias = New_filed_with_origin_type 
    N_field_4_type = "TEXT"
    N_field_4_Length  = 40
    N_field_4_is_nullable= "NULLABLE"
    
    # New Field 5 = 'O_Node' | TEXT: 5 Characters
    New_Field_with_origin_description = r'O_Node'   
    N_field_5_Name  = New_Field_with_origin_description 
    N_field_5_Alias = New_Field_with_origin_description 
    N_field_5_type = "TEXT"
    N_field_5_Length  = 5
    N_field_5_is_nullable= "NULLABLE"
    
    # New Field 6 = 'O_elev' |  NUMERIC: 2 Decimals
    New_Field_with_origin_elevation  = r'O_elev'   
    N_field_6_Name  = New_Field_with_origin_elevation
    N_field_6_Alias = New_Field_with_origin_elevation
    N_field_6_type = "DOUBLE"
    N_field_6_Precision = 12
    N_field_6_Scale = 2
    N_field_6_is_nullable= "NULLABLE"
    
    # New Field 7 = 'O_status' | TEXT: 10 Characters
    New_Field_with_origin_status  = r'O_status' 
    N_field_7_Name  = New_Field_with_origin_status 
    N_field_7_Alias = New_Field_with_origin_status 
    N_field_7_type = "TEXT"
    N_field_7_Length  = 15
    N_field_7_is_nullable= "NULLABLE"
    
    # New Field 8 = 'O_name' | TEXT: 80 Characters
    New_Field_with_origin_name = r'O_name'  
    N_field_8_Name  = New_Field_with_origin_name 
    N_field_8_Alias = New_Field_with_origin_name 
    N_field_8_type = "TEXT"
    N_field_8_Length  = 80
    N_field_8_is_nullable= "NULLABLE"
    
    # New Field 9 = O_Qm3s'  |  NUMERIC: 6 Decimals
    New_Field_with_origin_Q = r'O_Qm3s'   
    N_field_9_Name  = New_Field_with_origin_Q
    N_field_9_Alias = New_Field_with_origin_Q
    N_field_9_type = "DOUBLE"
    N_field_9_Precision = 12
    N_field_9_Scale = 6
    N_field_9_is_nullable= "NULLABLE"
    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    # Attributes Destination nodes:
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    
    # New Field 10 = 'D_MCI' | TEXT: 10 Characters
    New_field_with_destination_MCI_ID  = r'D_MCI'    
    N_field_10_Name  = New_field_with_destination_MCI_ID 
    N_field_10_Alias = New_field_with_destination_MCI_ID 
    N_field_10_type = "TEXT"
    N_field_10_Length  = 10
    N_field_10_is_nullable= "NULLABLE"
    
    # New Field 11 = 'D_type' | TEXT: 40 Characters
    New_filed_with_destination_type = r'D_type'  
    N_field_11_Name  = New_filed_with_destination_type 
    N_field_11_Alias = New_filed_with_destination_type 
    N_field_11_type = "TEXT"
    N_field_11_Length  = 40
    N_field_11_is_nullable= "NULLABLE"
    
    # New Field 12 = | TEXT: 5 Characters
    New_Field_with_destination_description= r'D_Node'   
    N_field_12_Name  = New_Field_with_destination_description 
    N_field_12_Alias = New_Field_with_destination_description 
    N_field_12_type = "TEXT"
    N_field_12_Length  = 5
    N_field_12_is_nullable= "NULLABLE"
    
    # New Field 13 = 'D_elev' |  NUMERIC: 2 Decimals
    New_Field_with_destination_elevation  = r'D_elev'   
    N_field_13_Name  = New_Field_with_destination_elevation
    N_field_13_Alias = New_Field_with_destination_elevation
    N_field_13_type = "DOUBLE"
    N_field_13_Precision = 12
    N_field_13_Scale = 2
    N_field_13_is_nullable= "NULLABLE"
    
    # New Field 14 = 'D_status' | TEXT: 10 Characters
    New_filed_with_destination_status = r'D_status' 
    N_field_14_Name  = New_filed_with_destination_status 
    N_field_14_Alias = New_filed_with_destination_status 
    N_field_14_type = "TEXT"
    N_field_14_Length  = 15
    N_field_14_is_nullable= "NULLABLE"
    
    # New Field 15 = 'D_name' | TEXT: 80 Characters
    New_filed_with_destination_name = r'D_name'   
    N_field_15_Name  = New_filed_with_destination_name 
    N_field_15_Alias = New_filed_with_destination_name 
    N_field_15_type = "TEXT"
    N_field_15_Length  = 80
    N_field_15_is_nullable= "NULLABLE"
    
    # New Field 16 ='D_Qm3s' |  NUMERIC: 6 Decimals
    New_filed_with_destination_Q = r'D_Qm3s'   
    N_field_16_Name  = New_filed_with_destination_Q
    N_field_16_Alias = New_filed_with_destination_Q
    N_field_16_type = "DOUBLE"
    N_field_16_Precision = 12
    N_field_16_Scale = 6
    N_field_16_is_nullable= "NULLABLE"
    
    
    # Load attribute table LCPs current task
    #..........................................................................
    LCPs_current_task = path_layer_with_LCPs
    OIDField_LCP_layer_current_task = arcpy.Describe(LCPs_current_task).OIDFieldName
    
    List_of_field_names_LCPs_current_task = [f.name for f in arcpy.ListFields(LCPs_current_task)]    
    List_of_field_names_LCPs_current_task.remove('Shape')

    NP_Array_LCPs_current_task =  arcpy.da.FeatureClassToNumPyArray (LCPs_current_task,List_of_field_names_LCPs_current_task,skip_nulls=False,null_value=-99999)
    df_LCPs_current_task = pd.DataFrame(NP_Array_LCPs_current_task, columns = List_of_field_names_LCPs_current_task)

    list_LCPs_descriptions_current_task = df_LCPs_current_task[Field_description].tolist()
    List_of_LCP_number_IDs_current_task =df_LCPs_current_task [OIDField_LCP_layer_current_task].tolist()
    Number_of_LCPs_current_task=len(list_LCPs_descriptions_current_task) 
    
    #..........................................................................
    
    # Calculate Delta H and Env Restrictions for all LCPS current task
    #..........................................................................

    List_of_LCP_descriptions = []
    List_of_Delta_H = []
    List_of_Envir_Res =[]
    
    # Field positions              0                    |                  1                     |        2       
    fields_to_use = [Existing_field_with_ID_origin_point,Existing_field_with_ID_destination_point,Field_description]
    
    LCP_count=1
         
    with arcpy.da.UpdateCursor(LCPs_current_task, fields_to_use) as cursor:
        
        # Loop trough all the LCPs to create the stack profiles 

        for row in cursor:
            
            # Each row represent a LCP
            Description_current_row= str(row[2])
            
            arcpy.AddMessage("Extracting Stack profile for LCP going " + Description_current_row.replace(r'-', r' ' ) )
            arcpy.AddMessage("Profile " + str(LCP_count) + r" out of " + str(Number_of_LCPs_current_task) + r' | Task # ' + str(Task_index +1) )
            
            # Create a Temp layer with just 1 LCP using select by attribute
            
            SQL_expression = "PathDes= '{}'".format(Description_current_row)

            one_LCP= arcpy.MakeFeatureLayer_management(LCPs_current_task, "Temp_LCP", SQL_expression)
            
            # save the TEMP layer 
            Temp_LCP_name = r'One_LCP'
            Temp_LCP_path = os.path.join(location_to_save_temp_layers,Temp_LCP_name)
            arcpy.CopyFeatures_management(one_LCP, Temp_LCP_path)

            H = 0
            
            try:
                
                # Generate Stack profile
                #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    
                name_stack_profile_table = r'Stack_profile_' + Description_current_row.replace(r'-', r'_')
                Stack_profile_path = os.path.join(location_to_save_stack_profiles,name_stack_profile_table)
                
                # Create a stack profile (dbf file/table)
                arcpy.AddMessage(" Creating Stack profile for LCP going " + Description_current_row )
                
                arcpy.ddd.StackProfile(Temp_LCP_path,path_file_with_DEM,Stack_profile_path,None)
                    
                # transform the Table with the stack profile into a csv file
                csv_file_name = name_stack_profile_table + '.csv'
                arcpy.TableToTable_conversion(Stack_profile_path, location_to_save_csv_files,  csv_file_name)
                    
                arcpy.AddMessage("Stack profile for LCP going " + Description_current_row + r' created successfully !')
                
                # here you calcualte the Delta H
                #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

                try:
                    df = arcgis_table_to_df(Stack_profile_path)
                    n = len(df.index)
                     
                    # Calculate the difference in elevation only for the path sections that
                    # are going against gravity (from lower to higher elevation)
                     
                    for i in range(1,n):
                        
                        A = df.FIRST_Z[i+1]-df.FIRST_Z[i]
                        if A < 0:
                            A = 0
                            H = H + A
                        else:
                            H = H + A
                   
                    
                except IndexError:
                    pass
                arcpy.AddMessage("Delta H for LCP going " + Description_current_row + r' : ' + str(H))
                
            except IndexError:
                
                print('Error Generating Stack profile for path going ' + Description_current_row.replace(r'-', r' ' ) )
                print('Delta H not calcualted')
                print('Stack profile files not generated')
                
                arcpy.AddMessage('Error Generating Stack profile for path going ' + Description_current_row.replace(r'-', r' ' ) )
                arcpy.AddMessage('Delta H not calcualted')
                pass
            
            # Add values for current LCP:
            List_of_LCP_descriptions.append(Description_current_row)
            List_of_Delta_H.append(H)
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                
            # Here you extract the Environmental restriction raster for the current LCP:
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            Ouput_table_name_ZE= r'Total_EvR_LCP_' + Description_current_row.replace(r'-', r'_' )
            Ouput_table_ZE=  os.path.join(location_to_save_temp_layers,Ouput_table_name_ZE)
            StatisticType = "SUM"
            
            arcpy.AddMessage( r'Calculating Zonal Stats for LCP ' + Description_current_row.replace(r'-', r' ' ) )
            
            arcpy.ia.ZonalStatisticsAsTable(Temp_LCP_path,
                                            OIDField_LCPs,
                                            path_file_with_Environmental_restriction,
                                            Ouput_table_ZE,
                                            "DATA",
                                            StatisticType,
                                            "CURRENT_SLICE",
                                            90,
                                            "AUTO_DETECT")
            
                
            # here you extract the ZE value and add it to the master df  
            array = arcpy.da.TableToNumPyArray(Ouput_table_ZE, [StatisticType], skip_nulls=True)
            SUM_Evr = round(array[0].tolist()[0],3) # get the number out of the table
            List_of_Envir_Res.append(SUM_Evr)
            
            #Save current progress in case of an unexpected interrumtion:    
            #..................................................................
            data_temp_dH = {'PathDes':List_of_LCP_descriptions,'Delta_H':List_of_Delta_H}
          
            df_delta_H = pd.DataFrame(data_temp_dH)
            
            # Write the excel files with Delta H:

            df_delta_H.to_excel(file_path_to_save_deltaH_values)
            
            data_temp_EnvR = {'PathDes':List_of_LCP_descriptions,'EnvRes':List_of_Envir_Res}
              
            df_EnvR= pd.DataFrame(data_temp_EnvR)
                
            # Write the excel files with Delta H:
                
            df_EnvR.to_excel(file_path_to_save_EnvR_values)
            
            #..................................................................
            
            arcpy.AddMessage( r' LCP ' + str(LCP_count) + r' out of ' + str(Number_of_LCPs_current_task) + r' was processed susscefully !' + r' | Task # ' + str(Task_index +1))
            
            elapsed_time = (time.time() - time_before_execution)
            Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
            Fraction_of_hours, hours =math.modf(Seconds/3600)
            arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1))
            arcpy.AddMessage( r' Loop for DElta h and EnvR finished sucessfully ' + r' | Task # ' + str(Task_index +1))
            arcpy.AddMessage('.............')
            
            LCP_count=LCP_count+1
        
        
    
    arcpy.AddMessage(r'Number of LCPs current task: ' +  str(Number_of_LCPs_current_task) + r' | Task # ' + str(Task_index +1))
    arcpy.AddMessage(r'Number of LCP descriptions current task: ' +  str(len(List_of_LCP_descriptions)) + r' | Task # ' + str(Task_index +1)) 
    arcpy.AddMessage(r'Number of Delta H values current task: ' +  str(len(List_of_Delta_H)) + r' | Task # ' + str(Task_index +1)) 
    arcpy.AddMessage(r'Number of EnvR values current task: ' +  str(len(List_of_Envir_Res)) + r' | Task # ' + str(Task_index +1)) 
    
    # Create DataFrame to save all the  Delta H values :
    #..........................................................................
    data_DeltaH_current_task = {OIDField_LCPs:List_of_LCP_number_IDs_current_task, 'PathDes':List_of_LCP_descriptions, 'Delta_H':List_of_Delta_H}
  
    df_delta_H = pd.DataFrame(data_DeltaH_current_task)
    
    # Write the excel files with Delta H:

    df_delta_H.to_excel(file_path_to_save_deltaH_values)

    # Delete the first column with no name
    work_book_DeltaH = load_workbook(file_path_to_save_deltaH_values)
    sheet_deltaH =work_book_DeltaH['Sheet1']
    sheet_deltaH.delete_cols(1,1)
    work_book_DeltaH.save(file_path_to_save_deltaH_values)
    
    arcpy.AddMessage(r'Excel file with summary of Delta H created sucessfully' + r' | Task # ' + str(Task_index +1))

    #..........................................................................    
    

    # Create DataFrame to save all the  Environmental Restriction SUM  values :
    #......................................................................

    data_EnvR_current_task = {OIDField_LCPs:List_of_LCP_number_IDs_current_task,'PathDes':List_of_LCP_descriptions,'EnvRes':List_of_Envir_Res}
      
    df_EnvR= pd.DataFrame(data_EnvR_current_task)
        
    # Write the excel files with Delta H:
        
    df_EnvR.to_excel(file_path_to_save_EnvR_values)
        
    # Delete the first column with no name
    work_book = load_workbook(file_path_to_save_EnvR_values)
    sheet =work_book['Sheet1']
    sheet.delete_cols(1,1)
    work_book.save(file_path_to_save_EnvR_values)
    arcpy.AddMessage(r'Excel file with summary of Env Restriction created sucessfully' + r' | Task # ' + str(Task_index +1))

    #......................................................................
    
    # Create a new df with the attributes to add 
    # This is the same order in which the attributes will be added to the layer:
    #..............................................................................
    
    df_delta_H = pd.read_excel (file_path_to_save_deltaH_values)
    df_EnvR = pd.read_excel (file_path_to_save_EnvR_values)
        
    df_New_attribute_values = pd.merge(left=df_EnvR, right=df_delta_H, how='left', left_on=Field_to_match_tables, right_on=Field_to_match_tables)
    
    # WARNING !
    # The object ID fields are arbitrary and meaningless when creating layers 
    # using parallel computing. These numnbers depend of the order in which 
    # each row was created. when doing parallel processing it is impossible to 
    # guarantee that the Object ID of features is unique (layers are split)
    
    # DO NOT RELATE TABLES USING OBJECT IDS !
    
    # It is better to merge tables using the description field, 
    # so let's delEte the OBJECT ID fields from both tables 
    
    df_LCPs_current_task.drop(['OBJECTID'], axis=1, inplace=True)    
    df_New_attribute_values.drop(['OBJECTID_x'], axis=1, inplace=True)    
    df_New_attribute_values.drop(['OBJECTID_y'], axis=1, inplace=True)    
    
    
    df_New_attributes_LCP_layer = pd.merge(left=df_LCPs_current_task, right=df_New_attribute_values, how='left', left_on=Field_to_match_tables, right_on=Field_to_match_tables)

    # Here you re-order the df so it coincides with the way the attributes 
    # are created in the new layer:
        
    new_order =[Field_description,                       # PathDes
                Field_PathLenght,                        # Shape_Length
                Existing_field_with_ID_origin_point,     # OriginID
                Existing_field_with_ID_destination_point,# DestinID 
                Field_PathCost,                          # PathCost
                New_field_Environmental_restriction,     # EnvRes
                New_field_Delta_H]                       # Delta_H 
    
    df_New_attributes_LCP_layer = df_New_attributes_LCP_layer.reindex(columns=new_order)
    
       
    # Here you merge the 7 attributes of the Origin Node to the df:
    df_New_attributes_LCP_layer=pd.merge(left=df_New_attributes_LCP_layer, right=df_Node_attributes, how='left', left_on=Existing_field_with_ID_origin_point, right_on=ID_field_nodes_layer[0])
    
    # Rename Columns of the Origin node attributes:
    df_New_attributes_LCP_layer = df_New_attributes_LCP_layer.rename(columns={r'ID_MCI':New_field_with_origin_MCI_ID,
                                                                              r'TYPE':New_filed_with_origin_type,
                                                                              r'NODE':New_Field_with_origin_description,
                                                                              r'Elevation_M':New_Field_with_origin_elevation,
                                                                              r'STATUS':New_Field_with_origin_status,
                                                                              r'NAME':New_Field_with_origin_name,
                                                                              r'Q_m3s':New_Field_with_origin_Q}) 
    
    
    # Here you merge the 7 attributes of the Destination node to the df:
    df_New_attributes_LCP_layer=pd.merge(left=df_New_attributes_LCP_layer, right=df_Node_attributes, how='left', left_on=Existing_field_with_ID_destination_point, right_on=ID_field_nodes_layer[0])
    
    # Rename Columns
    df_New_attributes_LCP_layer = df_New_attributes_LCP_layer.rename(columns={r'ID_MCI':New_field_with_destination_MCI_ID,
                                                                              r'TYPE':New_filed_with_destination_type,
                                                                              r'NODE':New_Field_with_destination_description,
                                                                              r'Elevation_M':New_Field_with_destination_elevation,
                                                                              r'STATUS':New_filed_with_destination_status,
                                                                              r'NAME':New_filed_with_destination_name,
                                                                              r'Q_m3s':New_filed_with_destination_Q})
    

    # Delete attributes you are not going to use after  merging:
    df_New_attributes_LCP_layer.drop(r'ID_CONN_x', axis=1, inplace=True)   
    df_New_attributes_LCP_layer.drop(r'ID_CONN_y', axis=1, inplace=True)    
        
    #Create a copy of the LCP layer to save the results
    #...............................................................................
    
    arcpy.CopyFeatures_management(LCPs_current_task, Result_layer)
    
    List_of_field_names_LCPs_current_task = [f.name for f in arcpy.ListFields(LCPs_current_task)]    

    # Delete  fields of the copy layer except for :
    Fields_to_keep= [OIDField_LCPs,
                     r'Shape',
                     Field_description,
                     'Shape_Length']
    
    Fields_to_delete = np.setdiff1d(List_of_field_names_LCPs_current_task,Fields_to_keep)
    
    Fields_to_delete=Fields_to_delete.tolist()
    
    arcpy.DeleteField_management(Result_layer, Fields_to_delete)
    
    # Write the attribute table of the new layer
    #..........................................................................    
    location_attribute_table_current_task=location_to_save_temp_layers.replace(r'\Temp_layers.gdb',r'')
    attribute_table_current_task= os.path.join(location_attribute_table_current_task, r'attribute_table_task_' + str(Task_index +1)+ r'.xlsx')
    df_New_attributes_LCP_layer.to_excel(attribute_table_current_task)
        
    # Delete the first column with no name
    work_book = load_workbook(attribute_table_current_task)
    sheet =work_book['Sheet1']
    sheet.delete_cols(1,1)
    work_book.save(attribute_table_current_task)
    #..........................................................................

    # Add the new attributes to the output LCP layer:
    #..............................................................................
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1))
    
    arcpy.AddMessage(r'Creating new fields in LCP layer |  Task # ' +  str(Task_index +1)+ r', please wait....')

    # here you create the path to the attribute table:
        
    Result_layer_filename, Result_layer_extension = os.path.splitext(Result_layer)
    
    if (Result_layer_extension == r'.shp'):
        inFeatures= Result_layer_filename + r'.dbf' # if resutl layer is a shapefile
    else:
        inFeatures = Result_layer # if result layer is inside a Geo-database
    
    # Catalog of new fields:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    # N_field_1  = Environmental_restriction =  r'EnvRes'  
    # N_field_2  = Delta_H =                    r'Delta_H'  
    # N_field_3  = origin_MCI_ID =              r'O_MCI'    
    # N_field_4  = origin_type =                r'O_type'  
    # N_field_5  = origin_description =         r'O_Node'   
    # N_field_6  = origin_elevation  =          r'O_elev'   
    # N_field_7  = origin_status =              r'O_status' 
    # N_field_8  = origin_name =                r'O_name'   
    # N_field_9  = origin_Q =                   r'O_Qm3s'   
    # N_field_10 = destination_MCI_ID  =        r'D_MCI'    
    # N_field_11 = destination_type =           r'D_type'  
    # N_field_12 = destination_description=     r'D_Node'   
    # N_field_13 = destination_elevation  =     r'D_elev'   
    # N_field_14 = destination_status =         r'D_status' 
    # N_field_15 = destination_name =           r'D_name'   
    # N_field_16 = destination_Q =              r'D_Qm3s'
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    # Add Field  NUMERIC -> OriginID
    arcpy.AddField_management(inFeatures, Existing_field_with_ID_origin_point, "SHORT", 10,field_alias=Existing_field_with_ID_origin_point, field_is_nullable="NULLABLE")
    # Add Field  NUMERIC -> DestinID
    arcpy.AddField_management(inFeatures, Existing_field_with_ID_destination_point, "SHORT", 10,field_alias=Existing_field_with_ID_destination_point, field_is_nullable="NULLABLE")
    # Add Field  DOUBLE -> PathCost
    arcpy.AddField_management(in_table=inFeatures,field_name=Field_PathCost,field_type="DOUBLE",field_precision=12,field_scale=2,field_alias=Field_PathCost,field_is_nullable="NULLABLE")

    # Field 1: NUMERIC
    create_new_numeric_field(inFeatures,N_field_1_Name,N_field_1_Alias,N_field_1_type,N_field_1_Precision,N_field_1_Scale,N_field_1_is_nullable)
    
    # Field 2: NUMERIC
    create_new_numeric_field(inFeatures,N_field_2_Name,N_field_2_Alias,N_field_2_type,N_field_2_Precision,N_field_2_Scale,N_field_2_is_nullable)
    
    # Field 3 TEXT
    create_new_text_field (inFeatures,N_field_3_Name,N_field_3_Alias,N_field_3_type,N_field_3_Length,N_field_3_is_nullable)
    
    # Field 4: TEXT
    create_new_text_field (inFeatures,N_field_4_Name,N_field_4_Alias,N_field_4_type,N_field_4_Length,N_field_4_is_nullable)
    
    # Field 5: TEXT
    create_new_text_field (inFeatures,N_field_5_Name,N_field_5_Alias,N_field_5_type,N_field_5_Length,N_field_5_is_nullable)
    
    # Field 6: NUMERIC
    create_new_numeric_field(inFeatures,N_field_6_Name,N_field_6_Alias,N_field_6_type,N_field_6_Precision,N_field_6_Scale,N_field_6_is_nullable)
    
    # Field 07: TEXT
    create_new_text_field (inFeatures,N_field_7_Name,N_field_7_Alias,N_field_7_type,N_field_7_Length,N_field_7_is_nullable)
   
    # Field 08: TEXT
    create_new_text_field (inFeatures,N_field_8_Name,N_field_8_Alias,N_field_8_type,N_field_8_Length,N_field_8_is_nullable)
    
    # Field 09: NUMERIC
    create_new_numeric_field(inFeatures,N_field_9_Name,N_field_9_Alias,N_field_9_type,N_field_9_Precision,N_field_9_Scale,N_field_9_is_nullable)
    
    # Field 10: TEXT
    create_new_text_field (inFeatures,N_field_10_Name,N_field_10_Alias,N_field_10_type,N_field_10_Length,N_field_10_is_nullable)
    
    # Field 11: TEXT
    create_new_text_field (inFeatures,N_field_11_Name,N_field_11_Alias,N_field_11_type,N_field_11_Length,N_field_11_is_nullable)
    
    # Field 12: TEXT
    create_new_text_field (inFeatures,N_field_12_Name,N_field_12_Alias,N_field_12_type,N_field_12_Length,N_field_12_is_nullable)
    
    # Field 13: NUMERIC
    create_new_numeric_field(inFeatures,N_field_13_Name,N_field_13_Alias,N_field_13_type,N_field_13_Precision,N_field_13_Scale,N_field_13_is_nullable)
    
    # Field 14: TEXT
    create_new_text_field (inFeatures,N_field_14_Name,N_field_14_Alias,N_field_14_type,N_field_14_Length,N_field_14_is_nullable)
    
    # Field 15: TEXT
    create_new_text_field (inFeatures,N_field_15_Name,N_field_15_Alias,N_field_15_type,N_field_15_Length,N_field_15_is_nullable)
    
    # Field 16: NUMERIC
    create_new_numeric_field(inFeatures,N_field_16_Name,N_field_16_Alias,N_field_16_type,N_field_16_Precision,N_field_16_Scale,N_field_16_is_nullable)
    #..............................................................................
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1))
    
    # Modify attributes:
    #..............................................................................
    
    arcpy.AddMessage(r'Assigning new attributes to polylines, please wait....' + r' | Task # ' + str(Task_index +1))
    
    # Here you make sure the dataframe you will use to assign values to the GIS layer
    # has the same order that the polylines: 
    
    Layer_order =  df_LCPs_current_task[Field_to_match_tables].tolist()
    
    df_New_attributes_LCP_layer= df_New_attributes_LCP_layer.iloc[list(map(df_New_attributes_LCP_layer[Field_to_match_tables].tolist().index, Layer_order))]
    
    fields_to_modify = [Existing_field_with_ID_origin_point,
                        Existing_field_with_ID_destination_point,
                        Field_PathCost,
                        N_field_1_Name,N_field_2_Name,N_field_3_Name,N_field_4_Name,
                        N_field_5_Name,N_field_6_Name,N_field_7_Name,N_field_8_Name,
                        N_field_9_Name,N_field_10_Name,N_field_11_Name,N_field_12_Name,
                        N_field_13_Name,N_field_14_Name,N_field_15_Name,N_field_16_Name]
    
    row_count=0
    
    with arcpy.da.UpdateCursor(inFeatures, fields_to_modify) as cursor:
      
        for row in cursor:
          
          row[0]  =int(df_New_attributes_LCP_layer[Existing_field_with_ID_origin_point][row_count])      # NUMERIC Integer : 'OriginID' 
          row[1]  =int(df_New_attributes_LCP_layer[Existing_field_with_ID_destination_point][row_count]) # NUMERIC Integer : 'OriginID' 
          row[2]  =round(df_New_attributes_LCP_layer[Field_PathCost][row_count],2)                       # NUMERIC 2 decimals : 'PathCost' 
          
          row[3]  = round(df_New_attributes_LCP_layer[N_field_1_Name][row_count],2)   # New Field 1  : NUMERIC 2 decimals : 'EnvRes' 
          row[4]  = round(df_New_attributes_LCP_layer[N_field_2_Name][row_count],2)   # New Field 2  : NUMERIC 2 decimals : 'Delta_H'
          row[5]  = df_New_attributes_LCP_layer[N_field_3_Name][row_count]            # New Field 3  : TEXT               : 'O_MCI'  
          row[6]  = df_New_attributes_LCP_layer[N_field_4_Name][row_count]            # New Field 4  : TEXT               : 'O_type' 
          row[7]  = df_New_attributes_LCP_layer[N_field_5_Name][row_count]            # New Field 5  : TEXT               : 'O_Node'
          row[8]  = round(df_New_attributes_LCP_layer[N_field_6_Name][row_count],2)   # New Field 6  : NUMERIC 2 decimals : 'O_elev'
          row[9]  = df_New_attributes_LCP_layer[N_field_7_Name][row_count]            # New Field 7  : TEXT               : 'O_status' 
          row[10] = df_New_attributes_LCP_layer[N_field_8_Name][row_count]            # New Field 8  : TEXT               : 'O_name'  
          row[11] = round(df_New_attributes_LCP_layer[N_field_9_Name][row_count],6)   # New Field 9  : NUMERIC 6 decimals : 'O_Qm3s'
          row[12] = df_New_attributes_LCP_layer[N_field_10_Name][row_count]           # New Field 10 : TEXT               : 'D_MCI' 
          row[13] = df_New_attributes_LCP_layer[N_field_11_Name][row_count]           # New Field 11 : TEXT               : 'D_type'
          row[14] = df_New_attributes_LCP_layer[N_field_12_Name][row_count]           # New Field 12 : TEXT               : 'D_Node' 
          row[15] = round(df_New_attributes_LCP_layer[N_field_13_Name][row_count],2)  # New Field 13 : NUMERIC 2 decimals : 'D_elev'  
          row[16] = df_New_attributes_LCP_layer[N_field_14_Name][row_count]           # New Field 14 : TEX                : 'D_status' 
          row[17] = df_New_attributes_LCP_layer[N_field_15_Name][row_count]           # New Field 15 : TEXT               : 'D_name' 
          row[18] = round(df_New_attributes_LCP_layer[N_field_16_Name][row_count],6)  # New Field 16 : NUMERIC 6 decimals : 'D_Qm3s'
          
          # Replace -9999 values for Null if the field is nullable
          if(np.logical_and(row[3] == -99999, N_field_1_is_nullable == "NULLABLE")):
              row[3] = None
          if(np.logical_and(row[4] == -99999, N_field_2_is_nullable == "NULLABLE")):
              row[4] = None
          if(np.logical_and(row[8] == -99999, N_field_6_is_nullable == "NULLABLE")):
              row[8] = None
          if(np.logical_and(row[11] == -99999, N_field_9_is_nullable == "NULLABLE")):
              row[11] = None
          if(np.logical_and(row[15] == -99999, N_field_13_is_nullable == "NULLABLE")):
              row[15] = None
          if (np.logical_and(row[18] == -99999, N_field_16_is_nullable == "NULLABLE")):
              row[18] = None
          
          row_count=row_count+1
          cursor.updateRow(row)
          
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
        
    arcpy.AddMessage('All fields populated succesfully !' + r' | Task # ' + str(Task_index +1))
    
    arcpy.AddMessage(r'Results' + r' Task # ' + str(Task_index +1) + ' loated at : ' + inFeatures)
    arcpy.AddMessage(' Task # ' + str(Task_index +1) + r' Finished sucessfully !!')
    arcpy.AddMessage('.......................................................')
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('.......................................................')
        log_file.write('\n')
        log_file.write(r'Layer with LCPs (one way) for node ' + str(ID_node_to_parse) +' | Task #' + str(Task_index +1)+ r' Located at: ' + str(inFeatures) )
        log_file.write('\n')
        log_file.write(r'File with delta H values (one way) for node  '+ str(ID_node_to_parse) +' | Task #' + str(Task_index +1)+ r' Located at: ' + str(file_path_to_save_deltaH_values) )
        log_file.write('\n')
        log_file.write(r'File with Environmental restriction values (one way) for node ' + str(ID_node_to_parse) +' | Task #' + str(Task_index +1)+ r' Located at: ' + str(file_path_to_save_EnvR_values) )
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#..............................................................................
    
#..............................................................................

def process_inverted_LCP_layer(Task_index,
                               ID_node_to_parse,
                               path_layer_with_LCPs,
                               path_layer_with_all_nodes,
                               path_file_with_DEM,
                               path_file_with_Environmental_restriction,
                               ID_field_nodes_layer,
                               location_to_save_temp_layers, 
                               location_to_save_stack_profiles,
                               location_to_save_csv_files,
                               file_path_to_save_deltaH_values,
                               file_path_to_save_EnvR_values,
                               time_before_execution,
                               location_log_file):
    
    # create the path to save the results: 
    #..........................................................................
    location_LCPs= os.path.dirname(os.path.abspath(path_layer_with_LCPs))
    Result_layer = os.path.join(location_LCPs, r'LCPs_node_' + str(ID_node_to_parse) + r'_return_with_attributes')
    #..........................................................................        
        
    # Get attributes nodes:
    #..........................................................................
    ID_field_nodes_layer=[ID_field_nodes_layer]
        
    # List of Node attributes to load
    list_node_attributes_to_load = [r'ID_CONN',r'ID_MCI', r'TYPE',r'NODE',r'Elevation_M', r'STATUS','NAME',r'Q_m3s']
    
    # Get a list of all the existing fields of the Nodes layer:
    #List_of_field_names_nodes_layer = [f.name for f in arcpy.ListFields(path_layer_with_all_nodes)]    
    
    NP_Array_Nodes_layer =  arcpy.da.FeatureClassToNumPyArray (path_layer_with_all_nodes,list_node_attributes_to_load,skip_nulls=False,null_value=-99999)
    df_Node_attributes = pd.DataFrame(NP_Array_Nodes_layer, columns = list_node_attributes_to_load)
    #..........................................................................
    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    # Existing Fields LCP layer:
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>

    Field_PathCost= r'PathCost'
    Field_description= r'PathDes'
    Existing_field_with_ID_origin_point = r'OriginID'
    Existing_field_with_ID_destination_point = r'DestinID'
    Field_PathLenght = r'Shape_Length'
    
    Field_to_match_tables=Field_description
    
    OIDField_LCPs = arcpy.Describe(path_layer_with_LCPs).OIDFieldName
    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    # New Fields LCP layer    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    
    # New Field 1 = 'EnvRes' | NUMERIC: 2 Decimals
    New_field_Environmental_restriction = r'EnvRes'  
    N_field_1_Name  =  New_field_Environmental_restriction
    N_field_1_Alias =  New_field_Environmental_restriction
    N_field_1_type = "DOUBLE"
    N_field_1_Precision = 12
    N_field_1_Scale = 2
    N_field_1_is_nullable= "NULLABLE"
    
    # New Field 2 = 'Delta_H' | NUMERIC: 2 Decimals
    New_field_Delta_H = r'Delta_H'  
    N_field_2_Name  = New_field_Delta_H 
    N_field_2_Alias = New_field_Delta_H 
    N_field_2_type = "DOUBLE"
    N_field_2_Precision = 12
    N_field_2_Scale = 2
    N_field_2_is_nullable= "NULLABLE"
    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    # Attributes Origin nodes:
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    
    # New Field 3 =  'O_MCI' | TEXT: 10 Characters
    New_field_with_origin_MCI_ID = r'O_MCI'    
    N_field_3_Name  = New_field_with_origin_MCI_ID 
    N_field_3_Alias = New_field_with_origin_MCI_ID 
    N_field_3_type = "TEXT"
    N_field_3_Length  = 10
    N_field_3_is_nullable= "NULLABLE"
    
    # New Field 4 =  'O_type' | TEXT: 40 Characters
    New_filed_with_origin_type = r'O_type'   
    N_field_4_Name  = New_filed_with_origin_type 
    N_field_4_Alias = New_filed_with_origin_type 
    N_field_4_type = "TEXT"
    N_field_4_Length  = 40
    N_field_4_is_nullable= "NULLABLE"
    
    # New Field 5 = 'O_Node' | TEXT: 5 Characters
    New_Field_with_origin_description = r'O_Node'   
    N_field_5_Name  = New_Field_with_origin_description 
    N_field_5_Alias = New_Field_with_origin_description 
    N_field_5_type = "TEXT"
    N_field_5_Length  = 5
    N_field_5_is_nullable= "NULLABLE"
    
    # New Field 6 = 'O_elev' |  NUMERIC: 2 Decimals
    New_Field_with_origin_elevation  = r'O_elev'   
    N_field_6_Name  = New_Field_with_origin_elevation
    N_field_6_Alias = New_Field_with_origin_elevation
    N_field_6_type = "DOUBLE"
    N_field_6_Precision = 12
    N_field_6_Scale = 2
    N_field_6_is_nullable= "NULLABLE"
    
    # New Field 7 = 'O_status' | TEXT: 10 Characters
    New_Field_with_origin_status  = r'O_status' 
    N_field_7_Name  = New_Field_with_origin_status 
    N_field_7_Alias = New_Field_with_origin_status 
    N_field_7_type = "TEXT"
    N_field_7_Length  = 15
    N_field_7_is_nullable= "NULLABLE"
    
    # New Field 8 = 'O_name' | TEXT: 80 Characters
    New_Field_with_origin_name = r'O_name'  
    N_field_8_Name  = New_Field_with_origin_name 
    N_field_8_Alias = New_Field_with_origin_name 
    N_field_8_type = "TEXT"
    N_field_8_Length  = 80
    N_field_8_is_nullable= "NULLABLE"
    
    # New Field 9 = O_Qm3s'  |  NUMERIC: 6 Decimals
    New_Field_with_origin_Q = r'O_Qm3s'   
    N_field_9_Name  = New_Field_with_origin_Q
    N_field_9_Alias = New_Field_with_origin_Q
    N_field_9_type = "DOUBLE"
    N_field_9_Precision = 12
    N_field_9_Scale = 6
    N_field_9_is_nullable= "NULLABLE"
    
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    # Attributes Destination nodes:
    #<><><><><><><><><><>><><><><><><><><><><><>><><><><><><><><><><><>><><><><>
    
    # New Field 10 = 'D_MCI' | TEXT: 10 Characters
    New_field_with_destination_MCI_ID  = r'D_MCI'    
    N_field_10_Name  = New_field_with_destination_MCI_ID 
    N_field_10_Alias = New_field_with_destination_MCI_ID 
    N_field_10_type = "TEXT"
    N_field_10_Length  = 10
    N_field_10_is_nullable= "NULLABLE"
    
    # New Field 11 = 'D_type' | TEXT: 40 Characters
    New_filed_with_destination_type = r'D_type'  
    N_field_11_Name  = New_filed_with_destination_type 
    N_field_11_Alias = New_filed_with_destination_type 
    N_field_11_type = "TEXT"
    N_field_11_Length  = 40
    N_field_11_is_nullable= "NULLABLE"
    
    # New Field 12 = | TEXT: 5 Characters
    New_Field_with_destination_description= r'D_Node'   
    N_field_12_Name  = New_Field_with_destination_description 
    N_field_12_Alias = New_Field_with_destination_description 
    N_field_12_type = "TEXT"
    N_field_12_Length  = 5
    N_field_12_is_nullable= "NULLABLE"
    
    # New Field 13 = 'D_elev' |  NUMERIC: 2 Decimals
    New_Field_with_destination_elevation  = r'D_elev'   
    N_field_13_Name  = New_Field_with_destination_elevation
    N_field_13_Alias = New_Field_with_destination_elevation
    N_field_13_type = "DOUBLE"
    N_field_13_Precision = 12
    N_field_13_Scale = 2
    N_field_13_is_nullable= "NULLABLE"
    
    # New Field 14 = 'D_status' | TEXT: 10 Characters
    New_filed_with_destination_status = r'D_status' 
    N_field_14_Name  = New_filed_with_destination_status 
    N_field_14_Alias = New_filed_with_destination_status 
    N_field_14_type = "TEXT"
    N_field_14_Length  = 15
    N_field_14_is_nullable= "NULLABLE"
    
    # New Field 15 = 'D_name' | TEXT: 80 Characters
    New_filed_with_destination_name = r'D_name'   
    N_field_15_Name  = New_filed_with_destination_name 
    N_field_15_Alias = New_filed_with_destination_name 
    N_field_15_type = "TEXT"
    N_field_15_Length  = 80
    N_field_15_is_nullable= "NULLABLE"
    
    # New Field 16 ='D_Qm3s' |  NUMERIC: 6 Decimals
    New_filed_with_destination_Q = r'D_Qm3s'   
    N_field_16_Name  = New_filed_with_destination_Q
    N_field_16_Alias = New_filed_with_destination_Q
    N_field_16_type = "DOUBLE"
    N_field_16_Precision = 12
    N_field_16_Scale = 6
    N_field_16_is_nullable= "NULLABLE"
    
    
    # Load attribute table LCPs current task
    #..........................................................................
    LCPs_current_task = path_layer_with_LCPs
    OIDField_LCP_layer_current_task = arcpy.Describe(LCPs_current_task).OIDFieldName
    
    List_of_field_names_LCPs_current_task = [f.name for f in arcpy.ListFields(LCPs_current_task)]    
    List_of_field_names_LCPs_current_task.remove('Shape')

    NP_Array_LCPs_current_task =  arcpy.da.FeatureClassToNumPyArray (LCPs_current_task,List_of_field_names_LCPs_current_task,skip_nulls=False,null_value=-99999)
    df_LCPs_current_task = pd.DataFrame(NP_Array_LCPs_current_task, columns = List_of_field_names_LCPs_current_task)

    list_LCPs_descriptions_current_task = df_LCPs_current_task[Field_description].tolist()
    List_of_LCP_number_IDs_current_task =df_LCPs_current_task [OIDField_LCP_layer_current_task].tolist()
    Number_of_LCPs_current_task=len(list_LCPs_descriptions_current_task) 
    
    #..........................................................................
    
    # Calculate Delta H and Env Restrictions for all LCPS current task
    #..........................................................................

    List_of_LCP_descriptions = []
    List_of_Delta_H = []
    List_of_Envir_Res =[]
    
    # Field positions              0                    |                  1                     |        2       
    fields_to_use = [Existing_field_with_ID_origin_point,Existing_field_with_ID_destination_point,Field_description]
    
    LCP_count=1
         
    with arcpy.da.UpdateCursor(LCPs_current_task, fields_to_use) as cursor:
        
        # Loop trough all the LCPs to create the stack profiles 

        for row in cursor:
            
            # Each row represent a LCP
            Description_current_row= str(row[2])
            
            arcpy.AddMessage("Extracting Stack profile for LCP going " + Description_current_row.replace(r'-', r' ' ) )
            arcpy.AddMessage("Profile " + str(LCP_count) + r" out of " + str(Number_of_LCPs_current_task) + r' | Task # ' + str(Task_index +1) )
            
            # Create a Temp layer with just 1 LCP using select by attribute
            
            SQL_expression = "PathDes= '{}'".format(Description_current_row)

            one_LCP= arcpy.MakeFeatureLayer_management(LCPs_current_task, "Temp_LCP", SQL_expression)
            
            # save the TEMP layer 
            Temp_LCP_name = r'One_LCP'
            Temp_LCP_path = os.path.join(location_to_save_temp_layers,Temp_LCP_name)
            arcpy.CopyFeatures_management(one_LCP, Temp_LCP_path)

            H = 0
            
            try:
                
                # Generate Stack profile
                #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    
                name_stack_profile_table = r'Stack_profile_' + Description_current_row.replace(r'-', r'_')
                Stack_profile_path = os.path.join(location_to_save_stack_profiles,name_stack_profile_table)
                
                # Create a stack profile (dbf file/table)
                arcpy.AddMessage(" Creating Stack profile for LCP going " + Description_current_row )
                
                arcpy.ddd.StackProfile(Temp_LCP_path,path_file_with_DEM,Stack_profile_path,None)
                    
                # transform the Table with the stack profile into a csv file
                csv_file_name = name_stack_profile_table + '.csv'
                arcpy.TableToTable_conversion(Stack_profile_path, location_to_save_csv_files,  csv_file_name)
                    
                arcpy.AddMessage("Stack profile for LCP going " + Description_current_row + r' created successfully !')
                
                # here you calcualte the Delta H
                #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

                try:
                    df = arcgis_table_to_df(Stack_profile_path)
                    n = len(df.index)
                     
                    # Calculate the difference in elevation only for the path sections that
                    # are going against gravity (from lower to higher elevation)
                     
                    for i in range(1,(n-1)):
                        
                        A = df.FIRST_Z[i]-df.FIRST_Z[i+1]
                        if A < 0:
                            A = 0
                            H = H + A
                        else:
                            H = H + A
                   
                    
                except IndexError:
                    pass
                arcpy.AddMessage("Delta H for LCP going " + Description_current_row + r' : ' + str(H))
                
            except IndexError:
                
                print('Error Generating Stack profile for path going ' + Description_current_row.replace(r'-', r' ' ) )
                print('Delta H not calcualted')
                print('Stack profile files not generated')
                
                arcpy.AddMessage('Error Generating Stack profile for path going ' + Description_current_row.replace(r'-', r' ' ) )
                arcpy.AddMessage('Delta H not calcualted')
                pass
            
            # Add values for current LCP:
            List_of_LCP_descriptions.append(Description_current_row)
            List_of_Delta_H.append(H)
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                
            # Here you extract the Environmental restriction raster for the current LCP:
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            Ouput_table_name_ZE= r'Total_EvR_LCP_' + Description_current_row.replace(r'-', r'_' )
            Ouput_table_ZE=  os.path.join(location_to_save_temp_layers,Ouput_table_name_ZE)
            StatisticType = "SUM"
            
            arcpy.AddMessage( r'Calculating Zonal Stats for LCP ' + Description_current_row.replace(r'-', r' ' ) )
            
            arcpy.ia.ZonalStatisticsAsTable(Temp_LCP_path,
                                            OIDField_LCPs,
                                            path_file_with_Environmental_restriction,
                                            Ouput_table_ZE,
                                            "DATA",
                                            StatisticType,
                                            "CURRENT_SLICE",
                                            90,
                                            "AUTO_DETECT")
            
                
            # here you extract the ZE value and add it to the master df  
            array = arcpy.da.TableToNumPyArray(Ouput_table_ZE, [StatisticType], skip_nulls=True)
            SUM_Evr = round(array[0].tolist()[0],3) # get the number out of the table
            List_of_Envir_Res.append(SUM_Evr)
            
            #Save current progress in case of an unexpected interrumtion:    
            #..................................................................
            data_temp_dH = {'PathDes':List_of_LCP_descriptions,'Delta_H':List_of_Delta_H}
          
            df_delta_H = pd.DataFrame(data_temp_dH)
            
            # Write the excel files with Delta H:

            df_delta_H.to_excel(file_path_to_save_deltaH_values)
            
            data_temp_EnvR = {'PathDes':List_of_LCP_descriptions,'EnvRes':List_of_Envir_Res}
              
            df_EnvR= pd.DataFrame(data_temp_EnvR)
                
            # Write the excel files with Delta H:
                
            df_EnvR.to_excel(file_path_to_save_EnvR_values)
            
            #..................................................................
            
            arcpy.AddMessage( r' LCP ' + str(LCP_count) + r' out of ' + str(Number_of_LCPs_current_task) + r' was processed susscefully !' + r' | Task # ' + str(Task_index +1))
            
            elapsed_time = (time.time() - time_before_execution)
            Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
            Fraction_of_hours, hours =math.modf(Seconds/3600)
            arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1))
            arcpy.AddMessage( r' Loop for DElta h and EnvR finished sucessfully ' + r' | Task # ' + str(Task_index +1))
            arcpy.AddMessage('.............')
            
            LCP_count=LCP_count+1
        
        
    
    arcpy.AddMessage(r'Number of LCPs current task: ' +  str(Number_of_LCPs_current_task) + r' | Task # ' + str(Task_index +1))
    arcpy.AddMessage(r'Number of LCP descriptions current task: ' +  str(len(List_of_LCP_descriptions)) + r' | Task # ' + str(Task_index +1)) 
    arcpy.AddMessage(r'Number of Delta H values current task: ' +  str(len(List_of_Delta_H)) + r' | Task # ' + str(Task_index +1)) 
    arcpy.AddMessage(r'Number of EnvR values current task: ' +  str(len(List_of_Envir_Res)) + r' | Task # ' + str(Task_index +1)) 
    
    # Create DataFrame to save all the  Delta H values :
    #..........................................................................
    data_DeltaH_current_task = {OIDField_LCPs:List_of_LCP_number_IDs_current_task, 'PathDes':List_of_LCP_descriptions, 'Delta_H':List_of_Delta_H}
  
    df_delta_H = pd.DataFrame(data_DeltaH_current_task)
    
    # Write the excel files with Delta H:

    df_delta_H.to_excel(file_path_to_save_deltaH_values)

    # Delete the first column with no name
    work_book_DeltaH = load_workbook(file_path_to_save_deltaH_values)
    sheet_deltaH =work_book_DeltaH['Sheet1']
    sheet_deltaH.delete_cols(1,1)
    work_book_DeltaH.save(file_path_to_save_deltaH_values)
    
    arcpy.AddMessage(r'Excel file with summary of Delta H created sucessfully' + r' | Task # ' + str(Task_index +1))

    #..........................................................................    
    

    # Create DataFrame to save all the  Environmental Restriction SUM  values :
    #......................................................................

    data_EnvR_current_task = {OIDField_LCPs:List_of_LCP_number_IDs_current_task,'PathDes':List_of_LCP_descriptions,'EnvRes':List_of_Envir_Res}
      
    df_EnvR= pd.DataFrame(data_EnvR_current_task)
        
    # Write the excel files with Delta H:
        
    df_EnvR.to_excel(file_path_to_save_EnvR_values)
        
    # Delete the first column with no name
    work_book = load_workbook(file_path_to_save_EnvR_values)
    sheet =work_book['Sheet1']
    sheet.delete_cols(1,1)
    work_book.save(file_path_to_save_EnvR_values)
    arcpy.AddMessage(r'Excel file with summary of Env Restriction created sucessfully' + r' | Task # ' + str(Task_index +1))

    #......................................................................
    
    # Create a new df with the attributes to add 
    # This is the same order in which the attributes will be added to the layer:
    #..............................................................................
    
    df_delta_H = pd.read_excel (file_path_to_save_deltaH_values)
    df_EnvR = pd.read_excel (file_path_to_save_EnvR_values)
        
    df_New_attribute_values = pd.merge(left=df_EnvR, right=df_delta_H, how='left', left_on=Field_to_match_tables, right_on=Field_to_match_tables)
    
    # WARNING !
    # The object ID fields are arbitrary and meaningless when creating layers 
    # using parallel computing. These numnbers depend of the order in which 
    # each row was created. when doing parallel processing it is impossible to 
    # guarantee that the Object ID of features is unique (layers are split)
    
    # DO NOT RELATE TABLES USING OBJECT IDS !
    
    # It is better to merge tables using the description field, 
    # so let's delEte the OBJECT ID fields from both tables 
    
    df_LCPs_current_task.drop(['OBJECTID'], axis=1, inplace=True)    
    df_New_attribute_values.drop(['OBJECTID_x'], axis=1, inplace=True)    
    df_New_attribute_values.drop(['OBJECTID_y'], axis=1, inplace=True)    
    
    
    df_New_attributes_LCP_layer = pd.merge(left=df_LCPs_current_task, right=df_New_attribute_values, how='left', left_on=Field_to_match_tables, right_on=Field_to_match_tables)

    # Here you re-order the df so it coincides with the way the attributes 
    # are created in the new layer:
        
    new_order =[Field_description,                       # PathDes
                Field_PathLenght,                        # Shape_Length
                Existing_field_with_ID_origin_point,     # OriginID
                Existing_field_with_ID_destination_point,# DestinID 
                Field_PathCost,                          # PathCost
                New_field_Environmental_restriction,     # EnvRes
                New_field_Delta_H]                       # Delta_H 
    
    df_New_attributes_LCP_layer = df_New_attributes_LCP_layer.reindex(columns=new_order)
    
       
    # Here you merge the 7 attributes of the Origin Node to the df:
    df_New_attributes_LCP_layer=pd.merge(left=df_New_attributes_LCP_layer, right=df_Node_attributes, how='left', left_on=Existing_field_with_ID_origin_point, right_on=ID_field_nodes_layer[0])
    
    # Rename Columns of the Origin node attributes:
    df_New_attributes_LCP_layer = df_New_attributes_LCP_layer.rename(columns={r'ID_MCI':New_field_with_origin_MCI_ID,
                                                                              r'TYPE':New_filed_with_origin_type,
                                                                              r'NODE':New_Field_with_origin_description,
                                                                              r'Elevation_M':New_Field_with_origin_elevation,
                                                                              r'STATUS':New_Field_with_origin_status,
                                                                              r'NAME':New_Field_with_origin_name,
                                                                              r'Q_m3s':New_Field_with_origin_Q}) 
    
    
    # Here you merge the 7 attributes of the Destination node to the df:
    df_New_attributes_LCP_layer=pd.merge(left=df_New_attributes_LCP_layer, right=df_Node_attributes, how='left', left_on=Existing_field_with_ID_destination_point, right_on=ID_field_nodes_layer[0])
    
    # Rename Columns
    df_New_attributes_LCP_layer = df_New_attributes_LCP_layer.rename(columns={r'ID_MCI':New_field_with_destination_MCI_ID,
                                                                              r'TYPE':New_filed_with_destination_type,
                                                                              r'NODE':New_Field_with_destination_description,
                                                                              r'Elevation_M':New_Field_with_destination_elevation,
                                                                              r'STATUS':New_filed_with_destination_status,
                                                                              r'NAME':New_filed_with_destination_name,
                                                                              r'Q_m3s':New_filed_with_destination_Q})
    

    # Delete attributes you are not going to use after  merging:
    df_New_attributes_LCP_layer.drop(r'ID_CONN_x', axis=1, inplace=True)   
    df_New_attributes_LCP_layer.drop(r'ID_CONN_y', axis=1, inplace=True)    
        
    #Create a copy of the LCP layer to save the results
    #...............................................................................
    
    arcpy.CopyFeatures_management(LCPs_current_task, Result_layer)
    
    List_of_field_names_LCPs_current_task = [f.name for f in arcpy.ListFields(LCPs_current_task)]    

    # Delete  fields of the copy layer except for :
    Fields_to_keep= [OIDField_LCPs,
                     r'Shape',
                     Field_description,
                     'Shape_Length']
    
    Fields_to_delete = np.setdiff1d(List_of_field_names_LCPs_current_task,Fields_to_keep)
    
    Fields_to_delete=Fields_to_delete.tolist()
    
    arcpy.DeleteField_management(Result_layer, Fields_to_delete)
    
    # Write the attribute table of the new layer
    #..........................................................................    
    location_attribute_table_current_task=location_to_save_temp_layers.replace(r'\Temp_layers.gdb',r'')
    attribute_table_current_task= os.path.join(location_attribute_table_current_task, r'attribute_table_task_' + str(Task_index +1)+ r'.xlsx')
    df_New_attributes_LCP_layer.to_excel(attribute_table_current_task)
        
    # Delete the first column with no name
    work_book = load_workbook(attribute_table_current_task)
    sheet =work_book['Sheet1']
    sheet.delete_cols(1,1)
    work_book.save(attribute_table_current_task)
    #..........................................................................

    # Add the new attributes to the output LCP layer:
    #..............................................................................
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1))
    
    arcpy.AddMessage(r'Creating new fields in LCP layer |  Task # ' +  str(Task_index +1)+ r', please wait....')

    # here you create the path to the attribute table:
        
    Result_layer_filename, Result_layer_extension = os.path.splitext(Result_layer)
    
    if (Result_layer_extension == r'.shp'):
        inFeatures= Result_layer_filename + r'.dbf' # if resutl layer is a shapefile
    else:
        inFeatures = Result_layer # if result layer is inside a Geo-database
    
    # Catalog of new fields:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    # N_field_1  = Environmental_restriction =  r'EnvRes'  
    # N_field_2  = Delta_H =                    r'Delta_H'  
    # N_field_3  = origin_MCI_ID =              r'O_MCI'    
    # N_field_4  = origin_type =                r'O_type'  
    # N_field_5  = origin_description =         r'O_Node'   
    # N_field_6  = origin_elevation  =          r'O_elev'   
    # N_field_7  = origin_status =              r'O_status' 
    # N_field_8  = origin_name =                r'O_name'   
    # N_field_9  = origin_Q =                   r'O_Qm3s'   
    # N_field_10 = destination_MCI_ID  =        r'D_MCI'    
    # N_field_11 = destination_type =           r'D_type'  
    # N_field_12 = destination_description=     r'D_Node'   
    # N_field_13 = destination_elevation  =     r'D_elev'   
    # N_field_14 = destination_status =         r'D_status' 
    # N_field_15 = destination_name =           r'D_name'   
    # N_field_16 = destination_Q =              r'D_Qm3s'
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    # Add Field  NUMERIC -> OriginID
    arcpy.AddField_management(inFeatures, Existing_field_with_ID_origin_point, "SHORT", 10,field_alias=Existing_field_with_ID_origin_point, field_is_nullable="NULLABLE")
    # Add Field  NUMERIC -> DestinID
    arcpy.AddField_management(inFeatures, Existing_field_with_ID_destination_point, "SHORT", 10,field_alias=Existing_field_with_ID_destination_point, field_is_nullable="NULLABLE")
    # Add Field  DOUBLE -> PathCost
    arcpy.AddField_management(in_table=inFeatures,field_name=Field_PathCost,field_type="DOUBLE",field_precision=12,field_scale=2,field_alias=Field_PathCost,field_is_nullable="NULLABLE")

    # Field 1: NUMERIC
    create_new_numeric_field(inFeatures,N_field_1_Name,N_field_1_Alias,N_field_1_type,N_field_1_Precision,N_field_1_Scale,N_field_1_is_nullable)
    
    # Field 2: NUMERIC
    create_new_numeric_field(inFeatures,N_field_2_Name,N_field_2_Alias,N_field_2_type,N_field_2_Precision,N_field_2_Scale,N_field_2_is_nullable)
    
    # Field 3 TEXT
    create_new_text_field (inFeatures,N_field_3_Name,N_field_3_Alias,N_field_3_type,N_field_3_Length,N_field_3_is_nullable)
    
    # Field 4: TEXT
    create_new_text_field (inFeatures,N_field_4_Name,N_field_4_Alias,N_field_4_type,N_field_4_Length,N_field_4_is_nullable)
    
    # Field 5: TEXT
    create_new_text_field (inFeatures,N_field_5_Name,N_field_5_Alias,N_field_5_type,N_field_5_Length,N_field_5_is_nullable)
    
    # Field 6: NUMERIC
    create_new_numeric_field(inFeatures,N_field_6_Name,N_field_6_Alias,N_field_6_type,N_field_6_Precision,N_field_6_Scale,N_field_6_is_nullable)
    
    # Field 07: TEXT
    create_new_text_field (inFeatures,N_field_7_Name,N_field_7_Alias,N_field_7_type,N_field_7_Length,N_field_7_is_nullable)
   
    # Field 08: TEXT
    create_new_text_field (inFeatures,N_field_8_Name,N_field_8_Alias,N_field_8_type,N_field_8_Length,N_field_8_is_nullable)
    
    # Field 09: NUMERIC
    create_new_numeric_field(inFeatures,N_field_9_Name,N_field_9_Alias,N_field_9_type,N_field_9_Precision,N_field_9_Scale,N_field_9_is_nullable)
    
    # Field 10: TEXT
    create_new_text_field (inFeatures,N_field_10_Name,N_field_10_Alias,N_field_10_type,N_field_10_Length,N_field_10_is_nullable)
    
    # Field 11: TEXT
    create_new_text_field (inFeatures,N_field_11_Name,N_field_11_Alias,N_field_11_type,N_field_11_Length,N_field_11_is_nullable)
    
    # Field 12: TEXT
    create_new_text_field (inFeatures,N_field_12_Name,N_field_12_Alias,N_field_12_type,N_field_12_Length,N_field_12_is_nullable)
    
    # Field 13: NUMERIC
    create_new_numeric_field(inFeatures,N_field_13_Name,N_field_13_Alias,N_field_13_type,N_field_13_Precision,N_field_13_Scale,N_field_13_is_nullable)
    
    # Field 14: TEXT
    create_new_text_field (inFeatures,N_field_14_Name,N_field_14_Alias,N_field_14_type,N_field_14_Length,N_field_14_is_nullable)
    
    # Field 15: TEXT
    create_new_text_field (inFeatures,N_field_15_Name,N_field_15_Alias,N_field_15_type,N_field_15_Length,N_field_15_is_nullable)
    
    # Field 16: NUMERIC
    create_new_numeric_field(inFeatures,N_field_16_Name,N_field_16_Alias,N_field_16_type,N_field_16_Precision,N_field_16_Scale,N_field_16_is_nullable)
    #..............................................................................
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1))
    
    # Modify attributes:
    #..............................................................................
    
    arcpy.AddMessage(r'Assigning new attributes to polylines, please wait....' + r' | Task # ' + str(Task_index +1))
    
    # Here you make sure the dataframe you will use to assign values to the GIS layer
    # has the same order that the polylines: 
    
    Layer_order =  df_LCPs_current_task[Field_to_match_tables].tolist()
    
    df_New_attributes_LCP_layer= df_New_attributes_LCP_layer.iloc[list(map(df_New_attributes_LCP_layer[Field_to_match_tables].tolist().index, Layer_order))]
    
    fields_to_modify = [Existing_field_with_ID_origin_point,
                        Existing_field_with_ID_destination_point,
                        Field_PathCost,
                        N_field_1_Name,N_field_2_Name,N_field_3_Name,N_field_4_Name,
                        N_field_5_Name,N_field_6_Name,N_field_7_Name,N_field_8_Name,
                        N_field_9_Name,N_field_10_Name,N_field_11_Name,N_field_12_Name,
                        N_field_13_Name,N_field_14_Name,N_field_15_Name,N_field_16_Name]
    
    row_count=0
    
    with arcpy.da.UpdateCursor(inFeatures, fields_to_modify) as cursor:
      
        for row in cursor:
          
          row[0]  =int(df_New_attributes_LCP_layer[Existing_field_with_ID_origin_point][row_count])      # NUMERIC Integer : 'OriginID' 
          row[1]  =int(df_New_attributes_LCP_layer[Existing_field_with_ID_destination_point][row_count]) # NUMERIC Integer : 'OriginID' 
          row[2]  =round(df_New_attributes_LCP_layer[Field_PathCost][row_count],2)                       # NUMERIC 2 decimals : 'PathCost' 
          
          row[3]  = round(df_New_attributes_LCP_layer[N_field_1_Name][row_count],2)   # New Field 1  : NUMERIC 2 decimals : 'EnvRes' 
          row[4]  = round(df_New_attributes_LCP_layer[N_field_2_Name][row_count],2)   # New Field 2  : NUMERIC 2 decimals : 'Delta_H'
          row[5]  = df_New_attributes_LCP_layer[N_field_3_Name][row_count]            # New Field 3  : TEXT               : 'O_MCI'  
          row[6]  = df_New_attributes_LCP_layer[N_field_4_Name][row_count]            # New Field 4  : TEXT               : 'O_type' 
          row[7]  = df_New_attributes_LCP_layer[N_field_5_Name][row_count]            # New Field 5  : TEXT               : 'O_Node'
          row[8]  = round(df_New_attributes_LCP_layer[N_field_6_Name][row_count],2)   # New Field 6  : NUMERIC 2 decimals : 'O_elev'
          row[9]  = df_New_attributes_LCP_layer[N_field_7_Name][row_count]            # New Field 7  : TEXT               : 'O_status' 
          row[10] = df_New_attributes_LCP_layer[N_field_8_Name][row_count]            # New Field 8  : TEXT               : 'O_name'  
          row[11] = round(df_New_attributes_LCP_layer[N_field_9_Name][row_count],6)   # New Field 9  : NUMERIC 6 decimals : 'O_Qm3s'
          row[12] = df_New_attributes_LCP_layer[N_field_10_Name][row_count]           # New Field 10 : TEXT               : 'D_MCI' 
          row[13] = df_New_attributes_LCP_layer[N_field_11_Name][row_count]           # New Field 11 : TEXT               : 'D_type'
          row[14] = df_New_attributes_LCP_layer[N_field_12_Name][row_count]           # New Field 12 : TEXT               : 'D_Node' 
          row[15] = round(df_New_attributes_LCP_layer[N_field_13_Name][row_count],2)  # New Field 13 : NUMERIC 2 decimals : 'D_elev'  
          row[16] = df_New_attributes_LCP_layer[N_field_14_Name][row_count]           # New Field 14 : TEX                : 'D_status' 
          row[17] = df_New_attributes_LCP_layer[N_field_15_Name][row_count]           # New Field 15 : TEXT               : 'D_name' 
          row[18] = round(df_New_attributes_LCP_layer[N_field_16_Name][row_count],6)  # New Field 16 : NUMERIC 6 decimals : 'D_Qm3s'
          
          # Replace -9999 values for Null if the field is nullable
          if(np.logical_and(row[3] == -99999, N_field_1_is_nullable == "NULLABLE")):
              row[3] = None
          if(np.logical_and(row[4] == -99999, N_field_2_is_nullable == "NULLABLE")):
              row[4] = None
          if(np.logical_and(row[8] == -99999, N_field_6_is_nullable == "NULLABLE")):
              row[8] = None
          if(np.logical_and(row[11] == -99999, N_field_9_is_nullable == "NULLABLE")):
              row[11] = None
          if(np.logical_and(row[15] == -99999, N_field_13_is_nullable == "NULLABLE")):
              row[15] = None
          if (np.logical_and(row[18] == -99999, N_field_16_is_nullable == "NULLABLE")):
              row[18] = None
          
          row_count=row_count+1
          cursor.updateRow(row)
          
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
        
    arcpy.AddMessage('All fields populated succesfully !' + r' | Task # ' + str(Task_index +1))
    
    arcpy.AddMessage(r'Results' + r' Task # ' + str(Task_index +1) + ' loated at : ' + inFeatures)
    arcpy.AddMessage(' Task # ' + str(Task_index +1) + r' Finished sucessfully !!')
    arcpy.AddMessage('.......................................................')
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('.......................................................')
        log_file.write('\n')
        log_file.write(r'Layer with LCPs (return) for node ' + str(ID_node_to_parse) +' | Task #' + str(Task_index +1)+ r' Located at: ' + str(inFeatures) )
        log_file.write('\n')
        log_file.write(r'File with delta H values (return) for node '+ str(ID_node_to_parse) +' | Task #' + str(Task_index +1)+ r' Located at: ' + str(file_path_to_save_deltaH_values) )
        log_file.write('\n')
        log_file.write(r'File with Environmental restriction values (return) for node ' + str(ID_node_to_parse) +' | Task #' + str(Task_index +1)+ r' Located at: ' + str(file_path_to_save_EnvR_values) )
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

#..............................................................................


#..............................................................................
def return_tuple_inputs_LCPs_gen(l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15):
    
    merged_list = [(l1[i],l2[i],l3[i],l4[i],l5[i],l6[i],l7[i],l8[i],l9[i],l10[i],l11[i],l12[i],l13[i],l14[i],l15[i]) for i in range(0, len(l1))]
    
    return merged_list
#..............................................................................    

#..............................................................................
def Gen_LCPs_selected_nodes(Task_index,                               #1
                            path_layer_with_all_nodes,                #2
                            ID_field_nodes_layer,                     #3 
                            list_ID_nodes_as_text,                    #4
                            path_file_with_DEM,                       #5
                            path_file_with_Environmental_restriction, #6
                            path_PCD_BL_rasters,                      #7
                            location_to_save_layer_LCPs,              #8
                            location_to_save_temp_layers,             #9
                            location_to_save_stack_profiles,          #10
                            location_to_save_csv_files,               #11 
                            file_path_to_save_deltaH_values,          #12
                            file_path_to_save_EnvR_values,            #13
                            time_before_execution,                    #14
                            location_log_file):                       #15
    
    arcpy.AddMessage('///////////////////////////////////////////////////////')
    arcpy.AddMessage( r'Task # ' + str(Task_index +1) + r' | LCP Generation' ) 
    arcpy.AddMessage('///////////////////////////////////////////////////////')
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('/////////////////////////////////////////////////////////////////////////')
        log_file.write('\n')
        log_file.write(  r'Task # ' + str(Task_index +1) + r' started at:' + str(Current_date) + r' '+ str(Current_time))
        log_file.write('\n')
        log_file.write('/////////////////////////////////////////////////////////////////////////')

    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    node_number =1
    Number_of_nodes_current_task= len(list_ID_nodes_as_text)
    
    list_file_paths_layers_to_merge_current_task=[]
    
    for node in list_ID_nodes_as_text:
        
        ID_node_to_parse =str(node)
        
        # Generate the layer with the LCPs (one way):
        #======================================================================    
        generate_LCP_layer(Task_index,
                           path_layer_with_all_nodes,
                           ID_field_nodes_layer,
                           ID_node_to_parse,
                           path_PCD_BL_rasters,
                           location_to_save_temp_layers,
                           location_to_save_layer_LCPs,
                           time_before_execution)
        
        path_layer_with_LCPs = os.path.join(location_to_save_layer_LCPs,r'LCPs_node_' + ID_node_to_parse )
        
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        elapsed_time = (time.time() - time_before_execution)
        Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
        Fraction_of_hours, hours =math.modf(Seconds/3600)
            
        Current_date_time = str(datetime.datetime.now())
        Current_date = Current_date_time.split()[0]
        Current_time = Current_date_time.split()[1]

        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('...................................')
            log_file.write('\n')
            log_file.write(  r'LCPs for node '+ ID_node_to_parse + r' (one way) generated correctly, Node ' + str(node_number)+ r' out of ' +str(Number_of_nodes_current_task) + ' | Task # ' + str(Task_index +1) + ' | ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r'| '+ str(Current_date) + r' '+ str(Current_time) )
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        
        # Process the layer with the LCPs one way:
        arcpy.AddMessage(  ' Processing LCPS for node ' + ID_node_to_parse + r' one way | Task # ' + str(Task_index +1)) 

        process_LCP_layer(Task_index,
                          ID_node_to_parse,
                          path_layer_with_LCPs,
                          path_layer_with_all_nodes,
                          path_file_with_DEM,
                          path_file_with_Environmental_restriction,
                          ID_field_nodes_layer,
                          location_to_save_temp_layers, 
                          location_to_save_stack_profiles,
                          location_to_save_csv_files,
                          file_path_to_save_deltaH_values,
                          file_path_to_save_EnvR_values,
                          time_before_execution,
                          location_log_file)
        
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        elapsed_time = (time.time() - time_before_execution)
        Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
        Fraction_of_hours, hours =math.modf(Seconds/3600)
            
        Current_date_time = str(datetime.datetime.now())
        Current_date = Current_date_time.split()[0]
        Current_time = Current_date_time.split()[1]
        
        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('...................................')
            log_file.write('\n')
            log_file.write(  r'LCPs (one way) for node '+ ID_node_to_parse + r' procecesed correctly, Node ' + str(node_number)+ r' out of ' +str(Number_of_nodes_current_task) + '| Task # ' + str(Task_index +1) )
            log_file.write('\n')
            log_file.write(  'ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r'| '+ str(Current_date) + r' '+ str(Current_time) )
 
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        
        #======================================================================    
        
        # Generate the Layer with Inversed LCPs:
        #======================================================================
        
        path_layer_with_LCPs_one_way =os.path.join(location_to_save_layer_LCPs,r'LCPs_node_' + str(ID_node_to_parse))
        
        generate_return_LCP_layer (Task_index,
                                   path_layer_with_LCPs_one_way,
                                   ID_node_to_parse,
                                   location_to_save_temp_layers,
                                   location_to_save_layer_LCPs,
                                   time_before_execution)
        
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        elapsed_time = (time.time() - time_before_execution)
        Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
        Fraction_of_hours, hours =math.modf(Seconds/3600)
            
        Current_date_time = str(datetime.datetime.now())
        Current_date = Current_date_time.split()[0]
        Current_time = Current_date_time.split()[1]

        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('...................................')
            log_file.write('\n')
            log_file.write(  r'LCPs (return) for node '+ ID_node_to_parse + r' generated correctly, Node ' + str(node_number)+ r' out of ' +str(Number_of_nodes_current_task) + ' | Task # ' + str(Task_index +1) + ' | ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r'| '+ str(Current_date) + r' '+ str(Current_time) )
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        
        # Process the layer with the LCPs return:
        arcpy.AddMessage(  ' Processing LCPS for node ' + ID_node_to_parse + r' return | Task # ' + str(Task_index +1)) 
        
        path_layer_with_LCPs_return= os.path.join(location_to_save_layer_LCPs,r'LCPs_node_' + str(ID_node_to_parse) + r'_return')
        
        process_inverted_LCP_layer(Task_index,
                                   ID_node_to_parse,
                                   path_layer_with_LCPs_return,
                                   path_layer_with_all_nodes,
                                   path_file_with_DEM,
                                   path_file_with_Environmental_restriction,
                                   ID_field_nodes_layer,
                                   location_to_save_temp_layers, 
                                   location_to_save_stack_profiles,
                                   location_to_save_csv_files,
                                   file_path_to_save_deltaH_values,
                                   file_path_to_save_EnvR_values,
                                   time_before_execution,
                                   location_log_file)
    
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        elapsed_time = (time.time() - time_before_execution)
        Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
        Fraction_of_hours, hours =math.modf(Seconds/3600)
            
        Current_date_time = str(datetime.datetime.now())
        Current_date = Current_date_time.split()[0]
        Current_time = Current_date_time.split()[1]
        
        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('...................................')
            log_file.write('\n')
            log_file.write(r'LCPs (return) for node '+ ID_node_to_parse + r' procecesed correctly, Node ' + str(node_number)+ r' out of ' +str(Number_of_nodes_current_task) + '| Task # ' + str(Task_index +1) )
            log_file.write('\n')
            log_file.write('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r'| '+ str(Current_date) + r' '+ str(Current_time) )
 
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            
        #======================================================================
        
        # Add layer paths to lists to merge:
        #......................................................................
        
        LCP_layer_one_way_WA = os.path.join(location_to_save_layer_LCPs,r'LCPs_node_' + str(ID_node_to_parse) + r'_with_attributes')
        LCP_layer_return_WA = os.path.join(location_to_save_layer_LCPs, r'LCPs_node_' + str(ID_node_to_parse) + r'_return_with_attributes')
        
        list_file_paths_layers_to_merge_current_task.append(LCP_layer_one_way_WA)
        list_file_paths_layers_to_merge_current_task.append(LCP_layer_return_WA)

        #......................................................................
        node_number = node_number +1
        
    #..........................................................................        
    
    # Merge  all the LCPs of the current Task:
    #..........................................................................
    
    Field_to_identify_rows= r'PathDes'
    layer_results= os.path.join(location_to_save_layer_LCPs, r'all_LCPs_with_attributes')
    
    if (len(list_file_paths_layers_to_merge_current_task)>1):
        
        # Merge the first two layers 
        Merge = os.path.join(location_to_save_temp_layers, r'merged_layers') 
        
        loc_first_layer  = list_file_paths_layers_to_merge_current_task[0] 
        loc_second_layer = list_file_paths_layers_to_merge_current_task[1]   
          
        merge_2_layers(loc_first_layer,loc_second_layer,Field_to_identify_rows,location_to_save_temp_layers,Merge)
        
        # Delete the first two layers from the list of layers to merge
        list_file_paths_layers_to_merge_current_task.pop(0)
        list_file_paths_layers_to_merge_current_task.pop(0)

        if (len(list_file_paths_layers_to_merge_current_task)>0):
            
            for Path_layer in list_file_paths_layers_to_merge_current_task:
                
                New_Merge = os.path.join(location_to_save_temp_layers, r'New_merged_layers') 
            
                merge_2_layers(Merge,Path_layer,Field_to_identify_rows,location_to_save_temp_layers,New_Merge)
                
                arcpy.management.Delete(Merge)
                arcpy.CopyFeatures_management(New_Merge, Merge)
                arcpy.management.Delete(New_Merge)
                
                arcpy.AddMessage( r'Layer merged successfully : ' + str(Path_layer) + r' !!')
            
        arcpy.CopyFeatures_management(Merge, layer_results)
        
    else:
        loc_first_layer = list_file_paths_layers_to_merge_current_task[0]
        arcpy.CopyFeatures_management(loc_first_layer, layer_results)

    arcpy.AddMessage(r'All layers' + str(Task_index +1) + ' merged succesfully !!')

    #..........................................................................    
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write(  r'LCP generation Task # ' + str(Task_index +1) + r'completed successfully  at:' + str(Current_date) + r' '+ str(Current_time))
        log_file.write('\n')
        log_file.write(' LCPs task # ' + str(Task_index +1) + r' merged into layer: ' + layer_results)
        log_file.write('\n')
        log_file.write(  'ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds'  )

    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        

#..............................................................................
def main(p1,p2,p3,p4,p5,p6,p7):
    
    arcpy.AddMessage(r':::::::::::::::::::::::::::::::::::::::')
    arcpy.AddMessage(r':::::::::::::::::::::::::::::::::::::::')
    
    time_before_execution_main = time.time()
    
    #Definition of execution variables:
    #..........................................................................
    path_layer_with_all_nodes=p1
    ID_field_nodes_layer=[p2]
    path_file_with_cost_raster=p3
    path_file_with_DEM=p4
    path_file_with_Environmental_restriction=p5
    Root_folder_results=p6
    folder_name_results=p7
    #..........................................................................
    
    
    # Validation of inputs:
    #..........................................................................    
    
    arcpy.AddMessage(r'Veryfying that input node layer is the right type....')

    desc = arcpy.Describe(path_layer_with_all_nodes)
    if not (desc.shapeType == 'Point'):
        arcpy.AddMessage( r'ERROR 101: Input layer is not a Point layer !')
        arcpy.AddMessage( r'Please change the input node layer and try again...')
        sys.exit() 
        
    arcpy.AddMessage(r'Veryfying that the input node layer has the right atttribute fields....')
    
    # load the list of existing nodes:
    #..........................................................................
    List_of_field_names = [f.name for f in arcpy.ListFields(path_layer_with_all_nodes)]    
    List_of_field_names.remove('Shape')    
        
    NP_Array_nodes_attribute_table =  arcpy.da.FeatureClassToNumPyArray (path_layer_with_all_nodes,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_input_nodes = pd.DataFrame(NP_Array_nodes_attribute_table, columns = List_of_field_names)
    #..........................................................................
    
    list_of_required_Fields= ['OBJECTID','ID_CONN','ID_MCI','NODE','TYPE','STATUS','UTM_East','UTM_North','Elevation_M','NAME','Q_m3s']
    
    if not (set(list_of_required_Fields).issubset(List_of_field_names)):
        d = {j:i for i,j in enumerate(list_of_required_Fields)}
        missing_attributes = sorted(list((set(list_of_required_Fields) - set(List_of_field_names))), key = lambda x: d[x])
        arcpy.AddMessage( r'ERROR 101: Input layer does not have the right Fields !!')
        arcpy.AddMessage( r'Missing attribute fields: ' + str(missing_attributes))
        sys.exit() 
    
    #..........................................................................   
    
    list_ID_nodes=df_input_nodes[ID_field_nodes_layer[0]].tolist()
    list_ID_nodes_as_text = [str(ID) for ID in list_ID_nodes]

    Number_of_Nodes_to_process=len(list_ID_nodes_as_text)

    arcpy.AddMessage(r'Number of nodes to process : ' + str(Number_of_Nodes_to_process))

    
    # Create Folders and GDBs for results:
    #..........................................................................
    
    Folder_path_results = os.path.join(Root_folder_results,folder_name_results)
    
    # create output folder:  
    if not os.path.exists(Folder_path_results):
        os.makedirs(Folder_path_results)
        arcpy.AddMessage("Folder to save results did not exist and was created")
    
    
    #  create the Geo-databses to save the Global results:
    arcpy.management.CreateFileGDB(Folder_path_results, "Results", "CURRENT")
    
    Number_of_tasks= 1
    arcpy.AddMessage('Number of tasks (parallel instances):' + str(Number_of_tasks)  )
    
    # Creation of Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    # Creates a .TXT file to write the relevant details of the run :
    
    location_log_file = os.path.join(Folder_path_results,'00-Run-details.txt')
    if(os.path.exists(location_log_file)):
        os.remove(location_log_file) 
    
    open(location_log_file, 'a').close()
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write(r'Process started on the ' + str(Current_date) + r' '+ str(Current_time))
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::    
    
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('Tasks were Splitted in ' + str(Number_of_tasks) + r' cores ' )
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    excel_delta_H_current_task = r'delta_H.xlsx'
    excel_EnvR_current_task = r'EnvR_Task.xlsx'    
    
    path_delta_H_current_task = os.path.join(Folder_path_results,excel_delta_H_current_task)
    path_EnvR_current_task = os.path.join(Folder_path_results,excel_EnvR_current_task)
    
    arcpy.management.CreateFileGDB(Folder_path_results, "PCD_and_BL_rasters" , "CURRENT")
    arcpy.management.CreateFileGDB(Folder_path_results, "LCPs", "CURRENT")
    arcpy.management.CreateFileGDB(Folder_path_results, "stack_profiles", "CURRENT")
    arcpy.management.CreateFileGDB(Folder_path_results, "Temp", "CURRENT")
        
    Folder_csv_files_current_task = os.path.join(Folder_path_results, "stack_profiles_csv")
    os.mkdir(Folder_csv_files_current_task)
        
    PCD_BL_GDB_path = os.path.join(Folder_path_results,r'PCD_and_BL_rasters.gdb')
    LCPs_GDB_path = os.path.join(Folder_path_results,r'LCPs.gdb')
    STACKPs_GDB_path = os.path.join(Folder_path_results, r'stack_profiles.gdb')
    TEMP_GDB_path = os.path.join(Folder_path_results,r'Temp.gdb')
                
    # Create PCD and BL rasters:
    #..........................................................................
    Gen_PCD_rasters_and_BL_rasters_selected_nodes(0,                           #1
                                                  path_layer_with_all_nodes,   # 2
                                                  list_ID_nodes_as_text,       # 3
                                                  ID_field_nodes_layer,        # 4 
                                                  PCD_BL_GDB_path,             # 5
                                                  path_file_with_cost_raster,  # 6
                                                  path_file_with_DEM,          # 7 
                                                  TEMP_GDB_path,               # 8
                                                  time_before_execution_main,  # 9
                                                  location_log_file)           #10
  
    
    elapsed_time = (time.time() - time_before_execution_main)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage(r'All PCD Rasters generated successfully !!')
    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('........................................................................................')
        log_file.write('\n')
        log_file.write('All PCD Rasters and BL Rasters were created Sucessfully at: '+ str( Current_date) + r' ' + str(Current_time))
        log_file.write('\n')
        log_file.write('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
        log_file.write('\n')
        log_file.write('........................................................................................')

    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    #..........................................................................
    
    # Generate LCPs:
    #..........................................................................
    
    arcpy.AddMessage('Generating LCPs, this may take several minutes please wait....')
    
    
    Gen_LCPs_selected_nodes(0,                                        #1
                            path_layer_with_all_nodes,                #2
                            ID_field_nodes_layer,                     #3 
                            list_ID_nodes_as_text,                    #4
                            path_file_with_DEM,                       #5
                            path_file_with_Environmental_restriction, #6
                            PCD_BL_GDB_path,                          #7
                            LCPs_GDB_path,                            #8
                            TEMP_GDB_path,                            #9
                            STACKPs_GDB_path,                         #10
                            Folder_csv_files_current_task,            #11 
                            path_delta_H_current_task,                #12
                            path_EnvR_current_task,                   #13
                            time_before_execution_main,               #14
                            location_log_file)                        #15
    
    
    elapsed_time = (time.time() - time_before_execution_main)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage(r'All LCPs were generated successfully at  '+ str( Current_date) + r' ' + str(Current_time))
    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('........................................................................................')
        log_file.write('\n')
        log_file.write('All LCPs were generated successfully at:' + str( Current_date) + r' ' + str(Current_time) )
        log_file.write('........................................................................................')
        log_file.write('\n')
        log_file.write('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
        log_file.write('........................................................................................')


    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        
#..............................................................................

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Creation of functions
###############################################################################

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)
p7 = arcpy.GetParameterAsText(6)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main(p1,p2,p3,p4,p5,p6,p7)

arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################

