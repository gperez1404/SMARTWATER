# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 13:56:52 2022

This script helps the user to filter a polyline layer with LCPs using a layer 
with a group of nodes as the filter criterea

This scripts creates a new LCP layer only with the LCPs (Paths) connecting 
the nodes introduced as parameters

This script also updates the attributes of the LCPs layer using the attributes 
of the nodes layer

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder/VS/PyCharm) 
# with the Python interpreter of an ArcGIS Pro virtual enviroment.

# The default location of the base python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 

###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#                                                     PACKAGES YOU NEED TO LOAD
###############################################################################
import os
import sys
import time
import math

import pandas as pd
import arcpy
from arcpy.sa import * # ignore this warning, package not supproted by IDEs
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^    EMD OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError # ignore this warning, package not supproted by IDEs
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError # ignore this warning, package not supproted by IDEs
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

description_p1 = r'Select the layer with input nodes to be used as a filter criteria:'
description_p2 = r'Id field of the nodes layer (No quotation marks):'
description_p3 = r'Select the layer with LCPs to filter:'
description_p4 = r'Id field of the LCPs layer (No quotation marks):'
description_p5 = r'Location to save the result layer with filtered LCPs:'
description_p6 = r'Name of the result layer with filtered LCPs:'

list_p_descriptions = [description_p1,description_p2,description_p3,description_p4,
                       description_p5,description_p6]

default_values_p1 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\Scenario_Huasco.gdb\Nodes_Huasco_Scenario'
default_values_p2 = r'ID_CONN'
default_values_p3 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\SMARTW_LCPs_for_236_nodes'
default_values_p4 = r'PathDes'
default_values_p5 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM_Scratch.gdb'
default_values_p6 = r'LCPs_nodes_Huasco_test_3_nodes_layer'

list_of_keys =['p1','p2','p3','p4','p5','p6']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                          Definition of Main() 
###############################################################################    

#..............................................................................

def main_function(p1,p2,p3,p4,p5,p6):

    time_before_execution = time.time()
    
    #Debugging:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # p1 = default_values_p1
    # p2 = default_values_p2
    # p3 = default_values_p3
    # p4 = default_values_p4
    # p5 = default_values_p5
    # p6 = default_values_p6
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    arcpy.AddMessage(r'p1 =' + str(p1))
    arcpy.AddMessage(r'p2 =' + str(p2))
    arcpy.AddMessage(r'p3 =' + str(p3))
    arcpy.AddMessage(r'p4 =' + str(p4))
    arcpy.AddMessage(r'p5 =' + str(p5))
    arcpy.AddMessage(r'p6 =' + str(p6))
    
    # Define function global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    layer_nodes=p1
    ID_Field_nodes=[p2]
    layer_LCPs=p3
    ID_field_LCPs=[p4]
    location_results=p5
    results_name_file =p6
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    
    # load the list of Nodes:
    #..........................................................................
    List_of_field_names_nodes_layer = [f.name for f in arcpy.ListFields(layer_nodes)]    
    List_of_field_names_nodes_layer.remove('Shape')   
    
    NP_Array_nodes_attribute_table =  arcpy.da.FeatureClassToNumPyArray (layer_nodes,List_of_field_names_nodes_layer,skip_nulls=False,null_value=-99999)
    df_input_nodes = pd.DataFrame(NP_Array_nodes_attribute_table, columns = List_of_field_names_nodes_layer)
    list_of_nodes_IDs = df_input_nodes[ID_Field_nodes[0]].tolist()
    Number_of_nodes=len(list_of_nodes_IDs)    
    #..........................................................................
    
    arcpy.AddMessage(r'Creating list of LCPs to extract')
    
    # Generate the list of all the possible LCP descriptions 
    # assocaited with the input point layer:
    #..........................................................................
    list_of_LCPs = []
        
    for index_start_points in range(0,Number_of_nodes):
        
        starting_point= list_of_nodes_IDs[index_start_points]
        LCP_description_with_start = r'From-' + str(starting_point) 
        
        # Be careful to create new lists on each iteration otherwise you will delete form  "list_of_nodes_IDs"
        List_of_possible_destination_nodes =  df_input_nodes[ID_Field_nodes[0]].tolist()
        List_of_possible_destination_nodes.remove(starting_point)
        Number_of_ending_points= len(List_of_possible_destination_nodes)
            
        for index_ending_points in range(0,Number_of_ending_points):
            ending_point = List_of_possible_destination_nodes[index_ending_points]
            
            LCP_description = LCP_description_with_start + r'-to-' +str(ending_point)
            
            list_of_LCPs.append(LCP_description)
            
    number_of_LCPs_to_extract =len(list_of_LCPs)
    
    arcpy.AddMessage(r'The input nodes layer is assocaited with ' + str(number_of_LCPs_to_extract) + ' LCPs ')
    #..........................................................................  
    
    
    # load the list of IDS of the input LCPs layer:
    #..........................................................................
    List_of_field_names_LCPs_layer = [f.name for f in arcpy.ListFields(layer_LCPs)]    
    List_of_field_names_LCPs_layer.remove('Shape')   
    
    NP_Array_LCPs_attribute_table =  arcpy.da.FeatureClassToNumPyArray (layer_LCPs,List_of_field_names_LCPs_layer,skip_nulls=False,null_value=-99999)
    df_input_LCPs = pd.DataFrame(NP_Array_LCPs_attribute_table, columns = List_of_field_names_LCPs_layer)
    list_of_all_LCPs_IDs = df_input_LCPs[ID_field_LCPs[0]].tolist()
    Total_number_of_LCPs= len(list_of_all_LCPs_IDs)
    #..........................................................................
    
    LCPs_to_delete = list(set(list_of_all_LCPs_IDs).difference(list_of_LCPs))
    
    arcpy.AddMessage(r'Creating copy of input LCPs layer, please wait....' )
    
    # Make a copy of the input layer to save the resutls of this script:
    #..........................................................................
    file_path_result_layer = os.path.join(location_results, results_name_file)
    arcpy.CopyFeatures_management(layer_LCPs, file_path_result_layer)
    #..........................................................................
    
    arcpy.AddMessage(r'File to save results created sucessfully !' )

    arcpy.AddMessage(r'Extracting ' + str(number_of_LCPs_to_extract)+ ' LCPs from input LCPs layer, please wait....')
    
    # Delete the rows that are not associated with the input nodes (filter LCPs):
    #..........................................................................
    count=0
    Number_of_rows_to_delete = Total_number_of_LCPs-number_of_LCPs_to_extract
    
    # These variables are defined for smart execution control 
    # Only 10 execution check points will be printed on console
    residual_for_progress = int(Number_of_rows_to_delete/10)
    
    if(residual_for_progress == 0):
        residual_for_progress=1
    
    with arcpy.da.UpdateCursor(file_path_result_layer, ID_field_LCPs) as cursor:
      for row in cursor:
          current_LCP = row[0]
          count=count+1
          if current_LCP in LCPs_to_delete:
              cursor.deleteRow()
              if(count%residual_for_progress == 0):
                  arcpy.AddMessage( r'Row ' + str(count) +  r' out of ' + str(Number_of_rows_to_delete)+' deleted')
                  elapsed_time = (time.time() - time_before_execution)
                  Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
                  Fraction_of_hours, hours =math.modf(Seconds/3600)
                  arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
          
    #..........................................................................
    
    
    # Update LCPs layer using the nodes layer:
    #--------------------------------------------------------------------------
        
    # You will update all the editable attributes using the cursor
        
    All_possible_fields_to_update = ['PathDes', 'O_MCI', 'O_Node', 'O_type', 'O_status', 'O_elev', 'O_name', 'O_Qm3s',
                                     'D_MCI', 'D_Node','D_type',  'D_status', 'D_elev', 'D_name', 'D_Qm3s']
    
    arcpy.AddMessage(r'These are the atttributes that will be updated based on the nodes layer:')
    
    for attribute_name in All_possible_fields_to_update:
        arcpy.AddMessage(attribute_name)
    
    LCPs_updated=1
    Number_of_LCPs_to_update = number_of_LCPs_to_extract
    
    # These variables are defined for smart execution control 
    # Only 10 execution check points will be printed on console
    residual_for_progress = int(Number_of_LCPs_to_update/10)
    
    if(residual_for_progress == 0):
        residual_for_progress=1
    
    with arcpy.da.UpdateCursor(file_path_result_layer, All_possible_fields_to_update) as cursor:
      
        for row in cursor:
            
            description_current_LCP = row[0]
            
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            # Update O attributes:
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            ID_O_node = int(description_current_LCP.split(r'-')[1])
               
            # Here you isolate the row with the attributes of origin node 
            # for the current LCP:  
            
            df_row_O = df_input_nodes.loc[ df_input_nodes[ID_Field_nodes[0]] == ID_O_node]
            
            O_MCI  = df_row_O[r'ID_MCI'].values[0]
            if (type(O_MCI) == str):
                row[1] = O_MCI
            
            O_Node  =df_row_O[r'NODE'].values[0]
            if (type(O_Node) == str):
                row[2] = O_Node          
           
            O_type  =df_row_O[r'TYPE'].values[0]
            if (type(O_type) == str):
                row[3] = O_type            
            
            O_status  =df_row_O[r'STATUS'].values[0]
            if (type(O_status) == str):
                row[4] = O_status 
            
            O_elev  =float(df_row_O[r'Elevation_M'].values[0])
            if not (math.isnan(O_elev)):
                row[5] = O_elev    
            
            O_name  =df_row_O[r'NAME'].values[0]
            if (type(O_name) == str):
                row[6] = O_name    
            
            O_Qm3s  =float(df_row_O[r'Q_m3s'].values[0])
            if not (math.isnan(O_Qm3s)):
                row[7] = O_Qm3s   
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                  
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            # Update D attributes:
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::      
            ID_D_node = int(description_current_LCP.split(r'-')[3])
                
            # Here you isolate the row with the attributes of origin node 
            # for the current LCP:             
            df_row_D = df_input_nodes.loc[ df_input_nodes[ID_Field_nodes[0]] == ID_D_node]
    
            D_MCI  = df_row_D[r'ID_MCI'].values[0]
            if (type(D_MCI) == str):
                row[8] = D_MCI
            
            D_Node  =df_row_D[r'NODE'].values[0]
            if (type(D_Node) == str):
                row[9] = D_Node          
           
            D_type  =df_row_D[r'TYPE'].values[0]
            if (type(D_type) == str):
                row[10] = D_type            
            
            D_status  =df_row_D[r'STATUS'].values[0]
            if (type(D_status) == str):
                row[11] = D_status 
            
            D_elev  =float(df_row_D[r'Elevation_M'].values[0])
            if not (math.isnan(D_elev)):
                row[12] = D_elev    
            
            D_name  =df_row_D[r'NAME'].values[0]
            if (type(D_name) == str):
                row[13] = D_name    
            
            D_Qm3s  =float(df_row_D[r'Q_m3s'].values[0])
            if not (math.isnan(D_Qm3s)):
                row[14] = D_Qm3s  
            
            if(LCPs_updated%residual_for_progress == 0):
                arcpy.AddMessage( r'Row ' + str(LCPs_updated) +  r' out of ' + str(Number_of_LCPs_to_update) + ' updated')
                elapsed_time = (time.time() - time_before_execution)
                Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
                Fraction_of_hours, hours =math.modf(Seconds/3600)
                arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
            LCPs_updated =LCPs_updated +1
            cursor.updateRow(row)
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                
    #--------------------------------------------------------------------------
    
    # Print location results:
    #--------------------------------------------------------------------------

    arcpy.AddMessage(r'Results layer located at: ' + file_path_result_layer)
    #-------------------------------------------------------------------------- 
    
#..............................................................................

###############################################################################
#      ^      ^      ^      ^      ^      ^      ^      ^  Definition of Main() 
###############################################################################   

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################

