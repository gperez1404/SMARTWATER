# -*- coding: utf-8 -*-
"""
Created on Mon Jul 4 11:47:59 2022

This script uses an excel file to update the attributes of a nodes layer 

These are the field names required in the input nodes layer:
    
    'ID_CONN'
    'ID_MCI'
    'NODE'
    'TYPE'
    'STATUS'
    'Elevation_M'
    'NAME'
    'Q_m3s'
           

WARNING 1: only nodes and attributes listed in the excel file will be updated. 
          All other nodes or attributes NOT listed in the input excel file
          WILL NOT be updated 

WARNING 2: the field names introduced in the GUI should coincide with the column
           names of the excel file, but can be different form the names of input 
           nodes layer. 
           
           If there are any attributes you don't want to update you can leave
           the input field as a blank

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
# %%                                                    PACKAGES YOU NEED TO LOAD
###############################################################################

import os
import sys
import time
import math

import openpyxl
from openpyxl import load_workbook, Workbook

import pandas as pd
import arcpy
from arcpy.sa import *
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^    EMD OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

description_p1  = r'Location of input layer with nodes (layer to be updated)'
description_p2  = r'Location of excel file to load new nodes attributes'
description_p3  = r'Name of the excel Sheet with the new attributes'
description_p4  = r'Name of the excel column with the values of NODE ID  (ID_CONN in the nodes layer | No quotation marks):'
description_p5  = r'Name of the excel column with the ID type (ID_MCI in the nodes layer | No quotation marks):'
description_p6  = r'Name of the excel column specifying if the node is D or S (NODE in the nodes  layer | No quotation marks):'
description_p7  = r'Name of the excel column with the type of node (TYPE in the nodes layer | No quotation marks):'
description_p8  = r'Name of the excel column with the Node status (STATUS in the nodes layer | No quotation marks):'
description_p9  = r'Name of the excel column with the Node elevation (Elevation_M in the nodes  layer | No quotation marks):'
description_p10 = r'Name of the excel column with the Node name (NAME in the nodes layer | No quotation marks):'
description_p11 = r'Name of the excel column with the new values of flow rate (Q_m3s in the nodes layer | No quotation marks):'
description_p12 = r'Location to save new Layer with updated node attributes'
description_p13 = r'Name of the new layer with updated nodes'

list_p_descriptions = [description_p1,description_p2,description_p3,
                       description_p4,description_p5,description_p6,
                       description_p7,description_p8,description_p9,
                       description_p10,description_p11,description_p12,
                       description_p13]

list_of_keys =['p1','p2','p3','p4','p5','p6','p7','p8','p9','p10','p11','p12','p13']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 


###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                       Definition of fucntions 
###############################################################################    

#..............................................................................

def main_function(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13):
    
    
    time_before_execution = time.time()
    
    # Define global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Nodes_layer                    = p1
    Excel_file_with_new_attributes = p2
    Excel_sheet_name               = p3
    ID_CONN                        = [p4]
    ID_MCI                         = [p5]
    NODE                           = [p6]  
    TYPE                           = [p7]
    STATUS                         = [p8]
    Elevation_M                    = [p9]
    NAME                           = [p10]
    Q_m3s                          = [p11]
    location_to_save_results       = p12
    name_results_layer             = p13
        
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # load the layer with nodes
    #--------------------------------------------------------------------------
    List_of_field_names_Nodes_layer = [f.name for f in arcpy.ListFields(Nodes_layer)]    
    List_of_field_names_Nodes_layer.remove('Shape')   
    List_of_field_names_Nodes_layer.remove('OBJECTID') 
    
    NP_Array_nodes_attribute_table =  arcpy.da.FeatureClassToNumPyArray (Nodes_layer,List_of_field_names_Nodes_layer,skip_nulls=False,null_value=-99999)
    df_input_Nodes = pd.DataFrame(NP_Array_nodes_attribute_table, columns = List_of_field_names_Nodes_layer)  
    
    list_of_Required_Field_Names             =  ['ID_CONN', 'ID_MCI', 'NODE', 'TYPE', 'STATUS', 'Elevation_M', 'NAME', 'Q_m3s']
    
    difference_in_attributes =    list(set(List_of_field_names_Nodes_layer).difference(list_of_Required_Field_Names))
    
    missing_attributes =[]
    
    for attribute_name in difference_in_attributes:
        if (attribute_name in list_of_Required_Field_Names):
            missing_attributes.append(attribute_name)

    
    if  (len(missing_attributes)> 0):
        arcpy.AddMessage( r'The field(s) {} are missing in the input nodes layer'.format(missing_attributes) ) 
        sys.exit() 
    
    
    #-------------------------------------------------------------------------- 
     
    # Load excel sheet as data-frame object:
    #..........................................................................
    try:
        df_excel_file = pd.read_excel(Excel_file_with_new_attributes, sheet_name=Excel_sheet_name)
    except ValueError:
        arcpy.AddMessage( r'Attempted file path: '  + Excel_file_with_new_attributes)
        arcpy.AddMessage( r'attempted Sheet name:'  + Excel_sheet_name)
        arcpy.AddMessage( r"Oops! ")
        arcpy.AddMessage( r'ERROR 101: you have introduced the wrong file location or the wrong Sheet name,  Try again...')
    #..........................................................................        
    
    
    # Verify that the names introduced in the GUI coincide with the excel file:
    #..........................................................................
    
    # Get the list of column names in the excel file:
    list_of_columns_names_excel_file = df_excel_file.columns.tolist()    
    
    # Get the list of Field names introduced in the GUI
    list_of_columns_names_introduced_in_GUI  =   ID_CONN + ID_MCI  + NODE  + TYPE  + STATUS  + Elevation_M  + NAME  + Q_m3s
    
    # Create a dictionary with the relation between excel names and layer names 
    dic_fields_for_translation = dict(zip(list_of_Required_Field_Names,list_of_columns_names_introduced_in_GUI)) 
    
    # Get the list of fields that won't be updated ('' or '-')
    
    list_of_fields_that_wont_be_updated = []
    
    for key in list_of_Required_Field_Names:
        
        field = dic_fields_for_translation.get(key)
        
        if (field == r'' or field == '-'):
            list_of_fields_that_wont_be_updated.append(key)
     
    # Get the list of fields/columns that should exist in the excel file:
        
    Fields_in_GUI_that_should_exist_in_excel = list(set(list_of_Required_Field_Names).difference(list_of_fields_that_wont_be_updated))
    
    # Get the list of Fields that should exist and DO NOT EXIST IN EXCEL:
        
    list_columns_that_should_exist_in_excel =[]

    for key in Fields_in_GUI_that_should_exist_in_excel:
        field = dic_fields_for_translation.get(key)
        list_columns_that_should_exist_in_excel.append(field)  
      
    # If the user introduces column names that do not exist in the excel file 
    # the script will NOT run
    # The Field names introduced in the GUI should coincide with the column names of the excel file
    
    for col_name in list_columns_that_should_exist_in_excel:
        
        if not (col_name in list_of_columns_names_excel_file):
            arcpy.AddMessage( r'ERRORE 101: One or multiple columns {} introduced in the GUI are missing in the input excel file'.format(list_columns_that_should_exist_in_excel) ) 
            sys.exit() 
            
    
    if( len(list_of_columns_names_excel_file) != len(list_of_columns_names_introduced_in_GUI)):
        arcpy.AddMessage( r'WARNING : the number of attributes to change is different thatn the numebr of columns in the input excel file !')
        arcpy.AddMessage( r'Make sure that the attributes you do not want to change are leave as blak spaces')
        
    
    # Get the list of nodes to update:
    
    list_of_nodes_to_update = df_excel_file[ID_CONN[0]].to_list()
    
    Number_of_nodes_to_update = len(list_of_nodes_to_update)
    
    #..........................................................................
    
    # Make a copy of the LCPs layer:
    #..........................................................................
    New_Nodes_layer  = os.path.join(location_to_save_results,name_results_layer)
    arcpy.CopyFeatures_management(Nodes_layer, New_Nodes_layer)
    #..........................................................................
    
        
    # Go look for rows with the nodes to update and replace the columns 
    #--------------------------------------------------------------------------
    
    Nodes_updated = 1
    
    residual_for_progress = int(Number_of_nodes_to_update/10)
    
    if(residual_for_progress == 0):
        residual_for_progress=1
    
    with arcpy.da.UpdateCursor(New_Nodes_layer, list_of_Required_Field_Names) as cursor:
        
        for row in cursor:
            
            current_node = row[0]
            
            if current_node in list_of_nodes_to_update:
                
                # Here you Get the row with new attributes of the node to replace
                
                df_row_new_node_attributes = df_excel_file.loc[df_excel_file[ID_CONN[0]] == current_node]
                
                # Update the values of MCI:
                excel_key = dic_fields_for_translation.get('ID_MCI')
                
                if not ( excel_key == r'' or field == '-'):
                    New_MCI = df_row_new_node_attributes[excel_key].values[0]
                    row[1] = New_MCI
                
                # Update the values of NODE:    
                excel_key = dic_fields_for_translation.get('NODE')
                
                if not ( excel_key == r'' or field == '-'):    
                    New_node = df_row_new_node_attributes[excel_key].values[0]
                    row[2] = New_node
                
                # Update the values of TYPE:  
                excel_key = dic_fields_for_translation.get('TYPE')
                
                if not ( excel_key == r'' or field == '-'):    
                    New_type = df_row_new_node_attributes[excel_key].values[0]
                    row[3] = New_type
            
                # Update the values of STATUS:  
                excel_key = dic_fields_for_translation.get('STATUS')
                
                if not ( excel_key == r'' or field == '-'):    
                    New_Status = df_row_new_node_attributes[excel_key].values[0]
                    row[4] = New_Status
                
                # Update the values of Elevation_M:  
                excel_key = dic_fields_for_translation.get('Elevation_M')
                
                if not ( excel_key == r'' or field == '-'):    
                    New_elevation = float(df_row_new_node_attributes[excel_key])
                    row[5] = New_elevation
                
                # Update the values of NAME:  
                excel_key = dic_fields_for_translation.get('NAME')
                
                if not ( excel_key == r'' or field == '-'):    
                    New_name = df_row_new_node_attributes[excel_key].values[0]
                    row[6] = New_name
                
                # Update the values of D_Qm3s:  
                excel_key = dic_fields_for_translation.get('Q_m3s')
                
                if not ( excel_key == r'' or field == '-'):    
                    New_Q = float(df_row_new_node_attributes[excel_key])
                    row[7] = New_Q
                
                if(Nodes_updated%residual_for_progress == 0):
                    arcpy.AddMessage( r'Row ' + str(Nodes_updated) +  r' out of ' + str(Number_of_nodes_to_update) + ' updated')
                    elapsed_time = (time.time() - time_before_execution)
                    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
                    Fraction_of_hours, hours =math.modf(Seconds/3600)
                    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
                
                Nodes_updated = Nodes_updated + 1
                cursor.updateRow(row) 
    
    #--------------------------------------------------------------------------            
                
    arcpy.AddMessage(r'Layer with updated nodes located at: ' + New_Nodes_layer)
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
            

###############################################################################
#                                                       Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)
p7 = arcpy.GetParameterAsText(6)
p8 = arcpy.GetParameterAsText(7)
p9 = arcpy.GetParameterAsText(8)
p10 = arcpy.GetParameterAsText(9)
p11 = arcpy.GetParameterAsText(10)
p12 = arcpy.GetParameterAsText(11)
p13 = arcpy.GetParameterAsText(12)

#Debugging:
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# p1  = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Scratch.gdb\CRB_nodes_with_updated_Q_values'
# p2  = r'R:\03_GISdata\data_Gabriel\02-Others\New_values_for_CRB_nodes.xlsx'
# p3  = r'New_values_CRB_nodes_2'
# p4  = r'ID_node'
# p5  = r'Type_ID'
# p6  = r'D_or_S'
# p7  = r'Type'
# p8  = r'Status'
# p9  = r'Elevation'
# p10 = r'Node_name' 
# p11 = r'Q'
# p12 = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Scratch.gdb'
# p13 = r'Nodes_with_updated_values'
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

###############################################################################
#     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################







