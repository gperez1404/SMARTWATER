# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 13:06:06 2022

This script launch a GUI to receive inputs from user and run the spatial 
optimisation process for selected nodes using parallel-processing

The range of nodes to process should be indicated as a vector of node IDs.

This script has the following sequence of steps:
    
Split tasks in cores >> 
       Generate PCD and BL rasters >> 
                            Generate LCPs >> 
                                  Process the LCPs >> 
                                           Merge all new LCPs in a single layer 

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""

###############################################################################
#                        PACKAGES YOU NEED TO LOAD
###############################################################################

import os
import glob
import sys
import shutil
import warnings
import string
import math
import traceback
import re                                 

import openpyxl
from openpyxl import load_workbook, Workbook

import itertools
from itertools import permutations  

import arcpy
from arcpy.sa import *

import numpy as np
import pandas as pd

from decimal import Decimal

import datetime
import time 

from functools import partial
from functools import reduce

from multiprocessing import Process, Queue, Pool, cpu_count, current_process, Manager,freeze_support

import tkinter as tk
import tkinter.filedialog as FDiag
from tkinter import *
from tkinter import filedialog as fd

###############################################################################
#    ^    ^    ^    ^PACKAGES YOU NEED TO LOAD    ^    ^    ^    ^    ^    ^    ^
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################


###############################################################################
#                                                                List of inputs
###############################################################################

# Description of inputs:
#..............................................................................
description_p1 = r'Layer with all nodes'
description_p2 = r'Name of ID field for nodes layer (No quotation marks)'
description_p3 = r'List of node IDs to process [node1,node2, ....] or type all / All to process all the nodes in the Layer (no quotation marks)'
description_p4 = r'Location of the Cost raster file (ArcGID format)'
description_p5 = r'Location of the surface raster (DEM in ArcGID format)'
description_p6 = r'Location of the Environmental Restriction raster (ArcGID format) '
description_p7 = r'Location to create a new folder to save all the results (Folder)'
description_p8 = r'Folder name to save all the results (No spaces)'
description_p9 = r'Number of cores to use in multi-processing (Maximum recommended: 4)'
#..............................................................................

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Default Values to help user introduce inputs faster:
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
p1  = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY.gdb\Scenario_41_nodes'
p2  = r'ID_CONN'
p3  = r'[267,268,269,270,271,272,273,274,275,276,277]'
p4  = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY.gdb\Input_Cost_raster_SMI_C1TTTSY'
p5  = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY.gdb\DEM_30m_SMI_C1TTTSY'
p6  = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY.gdb\Input_EvR_raster_SMI_C1TTTSY'
p7  = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY'
p8  = r'Res_NODES_31_to_41_Scenario_41_nodes'
p9  = r'2'
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

list_p_descriptions = [description_p1,description_p2,description_p3,description_p4,
                       description_p5,description_p6,description_p7,description_p8,
                       description_p9]

default_values= [p1,p2,p3,p4,p5,p6,p7,p8,p9]

list_of_keys =['p1','p2','p3','p4','p5','p6','p7','p8','p9']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

# to consult the meaning of a paramter: dict_parameters.get('pX')

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                         Creation of functions
###############################################################################

#..............................................................................

def arcgis_table_to_df(in_fc, input_fields=None, query=""):
    """Function will convert an arcgis table into a pandas dataframe with an object ID index, and the selected
    input fields using an arcpy.da.SearchCursor.
    :param - in_fc - input feature class or table to convert
    :param - input_fields - fields to input to do a search cursor for retrieval
    :param - query - SQL query to grab appropriate values
    :returns - pandas.DataFrame"""
    OIDFieldName = arcpy.Describe(in_fc).OIDFieldName
    if input_fields:
        final_fields = [OIDFieldName] + input_fields
    else:
        final_fields = [field.name for field in arcpy.ListFields(in_fc)]
    data = [row for row in arcpy.da.SearchCursor(in_fc,final_fields,where_clause=query)]
    fc_dataframe = pd.DataFrame(data,columns=final_fields)
    fc_dataframe = fc_dataframe.set_index(OIDFieldName,drop=True)
    return fc_dataframe


#..............................................................................

#..............................................................................

def rename_fields(table, out_table, new_name_by_old_name):
    """ Renames specified fields in input feature class/table
    :table:                 input table (fc, table, layer, etc)
    :out_table:             output table (fc, table, layer, etc)
    :new_name_by_old_name:  {'old_field_name':'new_field_name',...}
    ->  out_table
    """
    existing_field_names = [field.name for field in arcpy.ListFields(table)]

    field_mappings = arcpy.FieldMappings()
    field_mappings.addTable(table)

    for old_field_name, new_field_name in new_name_by_old_name.items():
        if old_field_name not in existing_field_names:
            message = "Field: {0} not in {1}".format(old_field_name, table)
            raise Exception(message)

        mapping_index = field_mappings.findFieldMapIndex(old_field_name)
        field_map = field_mappings.fieldMappings[mapping_index]
        output_field = field_map.outputField
        output_field.name = new_field_name
        output_field.aliasName = new_field_name
        field_map.outputField = output_field
        field_mappings.replaceFieldMap(mapping_index, field_map)

    # use merge with single input just to use new field_mappings
    arcpy.Merge_management(table, out_table, field_mappings)
    return out_table

#..............................................................................

#..............................................................................
def create_new_numeric_field (inFeatures,N_field_Name,N_field_Alias,N_field_type,N_field_Precision,N_field_Scale,N_field_is_nullable):
    
    arcpy.AddField_management(in_table=inFeatures,
                              field_name=N_field_Name,
                              field_type=N_field_type,
                              field_precision=N_field_Precision,
                              field_scale=N_field_Scale,
                              field_alias=N_field_Alias,
                              field_is_nullable=N_field_is_nullable)
    
#..............................................................................

#..............................................................................
def create_new_text_field (inFeatures,N_field_Name,N_field_Alias,N_field_type,FieldLength,N_field_is_nullable):
    
    arcpy.AddField_management(in_table=inFeatures,
                              field_name=N_field_Name,
                              field_type=N_field_type,
                              field_length=FieldLength,
                              field_alias=N_field_Alias,
                              field_is_nullable=N_field_is_nullable)


#..............................................................................

#..............................................................................

def merge_2_layers(Layer_1,Layer_2,Field_to_identify_rows,Location_Temp_results,Result_layer):
    
    # Get the list of IDs Layer 1:
    #..............................................................................
    List_of_field_names = [f.name for f in arcpy.ListFields(Layer_1)]    
    List_of_field_names.remove('Shape')
        
    NP_Array_L1 =  arcpy.da.FeatureClassToNumPyArray (Layer_1,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_L1= pd.DataFrame(NP_Array_L1, columns = List_of_field_names)

    list_IDs_L1 = df_L1[Field_to_identify_rows].tolist()

    # Get the list of IDs Layer 2:
    #..............................................................................

    List_of_field_names = [f.name for f in arcpy.ListFields(Layer_2)]    
    List_of_field_names.remove('Shape')

    NP_Array_L2 =  arcpy.da.FeatureClassToNumPyArray (Layer_2,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_L2 = pd.DataFrame(NP_Array_L2, columns = List_of_field_names)

    list_IDs_L2 = df_L2[Field_to_identify_rows].tolist()

    # make a copy of L1:
    Temp_copy = os.path.join(Location_Temp_results, r'temp_copy_LCPs')    
    arcpy.CopyFeatures_management(Layer_1, Temp_copy)
     
    # Delete the rows that are repeated:
    list_Ids_repeated = list(set(list_IDs_L1) & set(list_IDs_L2))
    
    if (len(list_Ids_repeated)>0):    
    
        with arcpy.da.UpdateCursor(Temp_copy, [Field_to_identify_rows]) as cursor:
          for row in cursor:
              current_LCP = row[0]
              if current_LCP in list_Ids_repeated:
                  arcpy.AddMessage( r'Row deleted: ' + current_LCP)
                  cursor.deleteRow()

    # Merge the New LCPs to the copy:
    arcpy.management.Merge([Temp_copy,Layer_2],Result_layer)
    arcpy.AddMessage( r'Layer  : ' + str(Layer_1) + r' merged to: ' + str(Layer_2)+ r' !!')

#..............................................................................


# Merge list of layers:
#..............................................................................

def merge_list_of_layers(list_layers_to_merge,Field_to_identify_rows,location_to_save_temp_layers,Result_layer):

    if (len(list_layers_to_merge)>1):
        
        # Merge the first two layers 
        Merge = os.path.join(location_to_save_temp_layers, r'merged_layers') 
        
        loc_first_layer  = list_layers_to_merge[0] 
        loc_second_layer = list_layers_to_merge[1]   
          
        merge_2_layers(loc_first_layer,loc_second_layer,Field_to_identify_rows,location_to_save_temp_layers,Merge)
        
        # Delete the first two layers from the list of layers to merge
        list_layers_to_merge.pop(0)
        list_layers_to_merge.pop(0)
    
        if (len(list_layers_to_merge)>0):
            
            for Path_layer in list_layers_to_merge:
                
                New_Merge = os.path.join(location_to_save_temp_layers, r'New_merged_layers') 
            
                merge_2_layers(Merge,Path_layer,Field_to_identify_rows,location_to_save_temp_layers,New_Merge)
                
                arcpy.management.Delete(Merge)
                arcpy.CopyFeatures_management(New_Merge, Merge)
                arcpy.management.Delete(New_Merge)
                
                arcpy.AddMessage( r'Layer merged successfully : ' + str(Path_layer) + r' !!')
            
        arcpy.CopyFeatures_management(Merge, Result_layer)
        
    else:
        loc_first_layer = list_layers_to_merge[0]
        arcpy.CopyFeatures_management(loc_first_layer, Result_layer)
    
    arcpy.AddMessage(r'All layers merged succesfully !!')

#..........................................................................   
    
#..............................................................................
def return_tuple_inputs_PCD_BL_gen(l1,l2,l3,l4,l5,l6,l7,l8,l9,l10):
    
    merged_list = [(l1[i],l2[i],l3[i],l4[i],l5[i],l6[i],l7[i],l8[i],l9[i],l10[i]) for i in range(0, len(l1))]
    
    return merged_list
#..............................................................................    

#..............................................................................

def Gen_PCD_rasters_and_BL_rasters_selected_nodes(Task_index,                # 1
                                                  path_layer_with_all_nodes, # 2
                                                  list_ID_nodes_as_text,     # 3
                                                  ID_field_nodes,            # 4 
                                                  location_PCD_BL_rasters,   # 5
                                                  path_file_with_cost_raster,# 6
                                                  path_file_with_DEM,        # 7 
                                                  location_temp_layers,      # 8
                                                  time_before_execution,     # 9
                                                  location_log_file):        #10
    
    arcpy.AddMessage('.......................................................')
    arcpy.AddMessage( r'Task # ' + str(Task_index +1) ) 
    arcpy.AddMessage( r'PCD and BL raster Generation' ) 
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write(  r'PCD and BL raster generation Task # ' + str(Task_index +1) + r' started at:' + str(Current_date) + r' '+ str(Current_time))
    
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    Number_of_nodes_current_task =len(list_ID_nodes_as_text)
    count_node=1
    for node in list_ID_nodes_as_text:
        
        ID_node_to_parse = node
        
        arcpy.AddMessage("Generating rasters for node with ID =" + str(ID_node_to_parse) )
        arcpy.AddMessage("Please wait....... ")
        
                            
        # Use the ID to select by attribute
    
        SQL_expression  = r'"'+ str(ID_field_nodes[0]) + r'"= ' +  str(ID_node_to_parse)
    
        # Create a new TEMP layer to save the selection
        layer_with_one_object = arcpy.MakeFeatureLayer_management(path_layer_with_all_nodes, r"node_" + str(ID_node_to_parse), SQL_expression)
        
        # save the TEMP layer in hard drive: 
        source_node_name = r'node_' + str(ID_node_to_parse)
        source_node_path = os.path.join(location_temp_layers,source_node_name)
        
        arcpy.CopyFeatures_management(layer_with_one_object, source_node_path)
        arcpy.AddMessage("Temp Layer for node with ID = "+ str(ID_node_to_parse) + " was created successfully !")
        del(layer_with_one_object)
            
        # Create inputs to execute the PathDistance() tool 
        
        Backlink_file_name= r'Backlink_to_node_' + str(ID_node_to_parse)
        Backlink_raster_path = os.path.join(location_PCD_BL_rasters,Backlink_file_name)
        
        PCD_raster_file_name= r'PCD_to_node_' + str(ID_node_to_parse)
        PCD_raster_path =os.path.join(location_PCD_BL_rasters,PCD_raster_file_name)
                    
        arcpy.AddMessage( "Generating PCD raster and Backlink raster ....")
        arcpy.AddMessage( "this takes several minutes, please wait.......")
        
        PCD_raster = arcpy.sa.PathDistance(in_source_data=source_node_path,
                                           in_cost_raster=path_file_with_cost_raster,
                                           in_surface_raster=path_file_with_DEM,
                                           in_horizontal_raster="",
                                           horizontal_factor="BINARY 1 45",
                                           in_vertical_raster="",
                                           vertical_factor="BINARY 1 -30 30",
                                           maximum_distance=None,
                                           out_backlink_raster=Backlink_raster_path,
                                           source_cost_multiplier="",
                                           source_start_cost="",
                                           source_resistance_rate="",
                                           source_capacity="",
                                           source_direction="")
        PCD_raster.save(PCD_raster_path)
        
        arcpy.AddMessage(" PCD raster and Backlink raster for node with ID = "+ str(ID_node_to_parse) + " created successfully !")
        del(PCD_raster)
        
        elapsed_time = (time.time() - time_before_execution)
        Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
        Fraction_of_hours, hours =math.modf(Seconds/3600)
          
        arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
        
        arcpy.AddMessage('...........................')
        
        Current_date_time = str(datetime.datetime.now())
        Current_date = Current_date_time.split()[0]
        Current_time = Current_date_time.split()[1]
        
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('...........................')
            log_file.write('\n')
            log_file.write(r'PCD raster and Backlink raster for node with ID = ' + str(ID_node_to_parse) + r' (Task ' + str(Task_index +1) + r', node # ' + str(count_node) + r' out of ' + str(Number_of_nodes_current_task)+ r') '+ r'created at: ' + str(Current_date) + r' '+ str(Current_time))
            log_file.write('\n')
            log_file.write('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
            log_file.write('\n')
            log_file.write('...........................')
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        count_node = count_node+1
    
#..............................................................................    

#..............................................................................

def generate_LCP_layer(Task_index,
                       path_layer_with_all_nodes,
                       ID_field_nodes,
                       ID_node_to_parse,
                       location_PCD_BL_rasters,
                       location_temp_layers,
                       location_to_save_layer_LCPs,
                       time_before_execution_task):
    
    arcpy.AddMessage('...................................')
    arcpy.AddMessage( r'Task # ' + str(Task_index +1) + ' LCPs node ' + str(ID_node_to_parse)) 
    
    
    # Use the ID to select by attribute

    SQL_expression  = r'"'+ str(ID_field_nodes[0]) + r'"= ' +  str(ID_node_to_parse)

    # Create a new TEMP layer to save the selection
    layer_with_one_object = arcpy.MakeFeatureLayer_management(path_layer_with_all_nodes, r"node_" + str(ID_node_to_parse), SQL_expression)
    
    # save the TEMP layer 
    source_node_name = r'node_' + str(ID_node_to_parse)
    source_node_path = os.path.join(location_temp_layers,source_node_name)
    
    arcpy.CopyFeatures_management(layer_with_one_object, source_node_path)

    arcpy.AddMessage("Temp Layer for node with ID = "+ str(ID_node_to_parse) + " was created successfully !" + r' | Task ' + str(Task_index +1))
                
    # Create inputs to execute the PathDistance() tool 
    
    Backlink_file_name= r'Backlink_to_node_' + str(ID_node_to_parse)
    Backlink_raster_path = os.path.join(location_PCD_BL_rasters,Backlink_file_name)
    
    PCD_raster_file_name= r'PCD_to_node_' + str(ID_node_to_parse)
    PCD_raster_path =os.path.join(location_PCD_BL_rasters,PCD_raster_file_name)
    
    # create a temp layer with all the other nodes except for the source node:
            
    tempLayer_all_other_nodes= r"all_other_nodes_except_for_" + str(ID_node_to_parse)
    tempLayer_all_other_nodes_path=os.path.join(location_temp_layers,tempLayer_all_other_nodes)
    
    arcpy.CopyFeatures_management(path_layer_with_all_nodes, tempLayer_all_other_nodes_path)
            
    # Delete the source point from TEMP layer
    with arcpy.da.UpdateCursor(tempLayer_all_other_nodes_path, ID_field_nodes) as cursor:
        for point in cursor:
            if point[0] == int(ID_node_to_parse):
                cursor.deleteRow()
            
           
    # Here you execute the CostPathAsPolyline() tool to create
    # the file with Least Cost Polylines of the current node
    
    LCP_name = r'LCPs_source_node_' + str(ID_node_to_parse)
    LCP_path = os.path.join(location_temp_layers,LCP_name) 
    
    LCP = r'LCPs_node_' + str(ID_node_to_parse) 
    New_LCP_path= os.path.join(location_to_save_layer_LCPs,LCP)
    
    PathType = "EACH_ZONE" 

    # The  least cost polyline layer (LCP) has the following attributes:

    # OBJECT ID
    # PathCost 
    # DestID ->  WARNING !! This is not the ID of the end point of the line. This can be confusing becasue it is the opposite of how the line was drawn
    # Shape_Length 
    
    arcpy.AddMessage(r" Generating LCP polylines for node with ID = "+ str(ID_node_to_parse) + r' | Task ' + str(Task_index +1) )
    
    arcpy.sa.CostPathAsPolyline(in_destination_data= tempLayer_all_other_nodes_path,
                                in_cost_distance_raster= PCD_raster_path,
                                in_cost_backlink_raster= Backlink_raster_path,
                                out_polyline_features= LCP_path,
                                path_type= PathType, 
                                destination_field= str(ID_field_nodes[0]),
                                force_flow_direction_convention= "INPUT_RANGE")
    
     
    # Here you rename the attribute 'DestID' -> 'OriginID'
    
    dict_old_names_new_names = {}
    
    old_name = r'DestID'
    new_name = r'OriginID'
    
    dict_old_names_new_names[old_name] = new_name
    
    LCP = r'LCPs_node_' + str(ID_node_to_parse) 
    New_LCP_path= os.path.join(location_to_save_layer_LCPs,LCP)
    
    rename_fields(LCP_path, New_LCP_path, dict_old_names_new_names)
    
    #delte the Temp file:
    arcpy.management.Delete(LCP_path)

    LCP_path = New_LCP_path
                        
    # Here you add an attribute with the ID of the Source Node
    # to all the paths. The source node is the Destination node 
    # of each line
                        
    inFeatures = LCP_path
    fieldName  = "DestinID"
    fieldAlias = fieldName
    field_type = "SHORT"
    fieldPrecision = 12
    fieldScale = 0
    
    #  AddField 
    arcpy.AddField_management(in_table=inFeatures,
                              field_name=fieldName,
                              field_type=field_type,
                              field_precision=fieldPrecision,
                              field_scale=fieldScale,
                              field_alias=fieldAlias,
                              field_is_nullable="NULLABLE")
                    
    # Populate the new field DestinID' 
            
    ID_source_node = ID_node_to_parse
    field_to_modify = [fieldName]
    
    with arcpy.da.UpdateCursor(LCP_path, field_to_modify) as cursor:
        for row in cursor:
            row[0] = ID_source_node
            cursor.updateRow(row)
            
    # Here you add an attribute with the Path description to all
    # LCPs
    # 'PathDes' = 'From-xxxx-to-xxxx'
    
    # The start point of the line is the DestID and the end of the line
    # is the SourceID. This sounds counterintuitive but if you don't 
    # describe the line in this way the stack profiles will be 
    # created wrong (inverted)
    
    inFeatures = LCP_path
    fieldName  = "PathDes"
    fieldAlias = fieldName
    field_type = "TEXT"
    fieldLength = 20
    
    #  AddField 
    arcpy.AddField_management(in_table=inFeatures,
                              field_name=fieldName,
                              field_type=field_type,
                              field_length=fieldLength,
                              field_alias=fieldAlias,
                              field_is_nullable="NULLABLE")
                    
    # Populate the new field
    
    fields_to_use = ['OriginID','DestinID','PathDes']
    
    with arcpy.da.UpdateCursor(LCP_path, fields_to_use) as cursor:
        for row in cursor:
            ID_start_node= row[0]
            ID_end_node  = row[1]
            
            row[2]= str(r'From-' + str( ID_start_node ) + r'-to-'+ str(ID_end_node))
            cursor.updateRow(row)
    
    # Get the number of polylines and print it on screen 
    
    NP_Array_LCPs_attribute_table =  arcpy.da.FeatureClassToNumPyArray (LCP_path,["PathDes"],skip_nulls=False,null_value=-99999)
    df_LCPs_desciption = pd.DataFrame(NP_Array_LCPs_attribute_table, columns = ["PathDes"])
    list_of_existing_LCPs = df_LCPs_desciption['PathDes'].tolist()
    Number_of_LCPs=len(list_of_existing_LCPs)    
    
    
    arcpy.AddMessage(r"LCP polylines (one way) for node with ID = "+ str(ID_node_to_parse) + " generated successfully" + r' | Task ' + str(Task_index +1) )
    arcpy.AddMessage(r'Number of LCPs : ' + str(Number_of_LCPs) + r' | Task ' + str(Task_index +1))

    elapsed_time = (time.time() - time_before_execution_task)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
        
    arcpy.AddMessage('Elapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task ' + str(Task_index +1))
    arcpy.AddMessage('...................................')
    
#..............................................................................    

#..............................................................................

def generate_return_LCP_layer (Task_index,
                               path_layer_with_LCPs_one_way,
                               ID_key_layer,
                               location_temp_layers,
                               location_to_save_layer_LCPs,
                               time_before_execution):
    
    # Debugging:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    #path_layer_with_LCPs_one_way =r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_RESULTS_ADDING_2_NEW_NODES\Results_Task_1\LCPs_task_1.gdb\LCPs_node_237'
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # Load the attribute table of the LCP layer as df:
    #..........................................................................
    List_of_field_names_LCPs = [f.name for f in arcpy.ListFields(path_layer_with_LCPs_one_way)]    
    List_of_field_names_LCPs.remove('Shape')
    
    OIDField_LCPs = arcpy.Describe(path_layer_with_LCPs_one_way).OIDFieldName

    NP_Array_LCPs=  arcpy.da.FeatureClassToNumPyArray (path_layer_with_LCPs_one_way,List_of_field_names_LCPs,skip_nulls=False,null_value=-99999)
    df_LCPs = pd.DataFrame(NP_Array_LCPs, columns = List_of_field_names_LCPs)

    list_of_LCP_descriptions_one_way = df_LCPs['PathDes'].tolist()
    list_of_LCP_OBID_one_way = df_LCPs[OIDField_LCPs].tolist()
    
    Number_of_LCPs_one_way=len(list_of_LCP_OBID_one_way)
    
    #..........................................................................

    # Generate the list of LCP descriptions in the opposite way:
    #..........................................................................
    list_of_LCP_descriptions_return = list_of_LCP_descriptions_one_way.copy()
    list_of_LCP_descriptions_return = [r'From-' + ((s.strip('From-')).replace(r'-to-',r'-')).split(r'-')[1] + r'-to-' + ((s.strip('From-')).replace(r'-to-',r'-')).split(r'-')[0] for s in list_of_LCP_descriptions_return]
    #..........................................................................
    
    # Make the lists of inverted Origin-Destination IDs
    #..........................................................................
    list_of_Origins_return = df_LCPs['DestinID'].tolist()
    list_of_Destinations_return = df_LCPs['OriginID'].tolist()
    #..........................................................................
    
    # Make the list of Object IDs return LCPs:
    #..........................................................................
    Last_OID_one_way = list_of_LCP_OBID_one_way[Number_of_LCPs_one_way-1]
    list_of_LCP_OBID_return = []
    
    for i in range((Last_OID_one_way+1),(Last_OID_one_way+Number_of_LCPs_one_way)+1):
        list_of_LCP_OBID_return.append(i)
    #..........................................................................
    
    # Make df for return LCPs:
    #..........................................................................
    df_LCPs_return = df_LCPs.copy()
    df_LCPs_return.drop([OIDField_LCPs,'DestinID', 'OriginID','PathDes'], axis=1)
    
    df_LCPs_return[OIDField_LCPs] = list_of_LCP_OBID_return
    df_LCPs_return['OriginID'] = list_of_Origins_return
    df_LCPs_return['DestinID'] = list_of_Destinations_return
    df_LCPs_return['PathDes'] = list_of_LCP_descriptions_return
    #..........................................................................
    
    # Make a copy of the LCPs layer:
    #..........................................................................
    name_return_layer =r'LCPs_node_' + str(ID_key_layer) + r'_return'
    path_layer_return_LCPs = os.path.join(location_to_save_layer_LCPs,name_return_layer)
    arcpy.CopyFeatures_management(path_layer_with_LCPs_one_way, path_layer_return_LCPs)
    #..........................................................................
    
    # Replace values of copy layer:
    #..........................................................................
    
    # Replace the respective fields in the layer :

    fields_to_modify = [OIDField_LCPs,
                        'DestinID',
                        'OriginID',
                        'PathDes']

    row_count=0

    with arcpy.da.UpdateCursor(path_layer_return_LCPs, fields_to_modify) as cursor:
      
        for row in cursor:
            row[0]  = df_LCPs_return[OIDField_LCPs][row_count]
            row[1]  = df_LCPs_return['DestinID'][row_count]
            row[2]  = df_LCPs_return['OriginID'][row_count]
            row[3]  = df_LCPs_return['PathDes'][row_count]
            cursor.updateRow(row)
            row_count=row_count+1
    
    
    arcpy.AddMessage(r"Layer with return LCPs for node with ID = "+ str(ID_key_layer) + " generated successfully" + r' | Task ' + str(Task_index +1) )
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
        
    arcpy.AddMessage('Elapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task ' + str(Task_index +1))
    arcpy.AddMessage('...................................')
    #..........................................................................

#..............................................................................

#..............................................................................
def return_tuple_inputs_Process_LCPs_no_excel(l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13):
    
    merged_list = [(l1[i],l2[i],l3[i],l4[i],l5[i],l6[i],l7[i],l8[i],l9[i],l10[i],l11[i],l12[i],l13[i]) for i in range(0, len(l1))]
    
    return merged_list
#..............................................................................    


#..............................................................................    

# This is the function to be run in parallel instances: 
    
def process_selected_rows_of_LCPs_layer_no_excel(Type_of_LCPs,                            # p1
                                                 Task_index,                              # p2
                                                 start_index_task,                        # p3
                                                 end_index_task,                          # p4
                                                 path_layer_with_LCPs,                    # p5
                                                 path_layer_with_all_nodes,               # p6
                                                 path_file_with_DEM,                      # p7
                                                 path_file_with_Environmental_restriction,# p8
                                                 ID_field_nodes_layer,                    # p9
                                                 location_to_save_temp_layers,            # p10
                                                 location_to_save_stack_profiles,         # p11
                                                 time_before_execution_task,              # p12
                                                 location_log_file):                      # p13
    
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # #Debugging:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # Type_of_LCPs= 'one_way'  # 'return'
    # Task_index=0
    # start_index_task=2994
    # end_index_task=3994                            
    # path_layer_with_LCPs= r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM_Regen_LCPs.gdb\all_LCPs_V3'
    # path_layer_with_all_nodes=parameter_3                       
    # path_file_with_DEM= parameter_6                       
    # path_file_with_Environmental_restriction=parameter_16                     
    # ID_field_nodes_layer=parameter_4[0]                   
    # location_to_save_temp_layers=r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM_Result_multi_processing\Temp_single_core\Temp_layers.gdb'
    # location_to_save_stack_profiles=r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM_Result_multi_processing\Temp_single_core\stack_profiles.gdb' 
    # location_to_save_csv_files=r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM_Result_multi_processing\Temp_single_core\stack_profiles_csv' 
    # file_path_to_save_deltaH_values=parameter_22                    
    # file_path_to_save_EnvR_values=parameter_23                   
    # time_before_execution_task= time.time()
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    

    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    # Creates a log file to write the relevant details of the run :
    
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('.......................................................')
        log_file.write('\n')
        log_file.write(  r'Task # ' + str(Task_index +1) + r' LCP processing '+ str(Type_of_LCPs.replace(r'_', r' ')) +' | started at:' + str(Current_date) + r' '+ str(Current_time))
        log_file.write('\n')
        log_file.write( r'Task # ' + str(Task_index +1) + r',  from row ' + str(start_index_task) + r' to row ' + str(end_index_task))
        log_file.write('\n')
        log_file.write('.......................................................')

    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    arcpy.AddMessage('.......................................................')
    arcpy.AddMessage('.......................................................')
    arcpy.AddMessage( r'Task # ' + str(Task_index +1) + r' LCP processing (' +str(Type_of_LCPs.replace(r'_', r' ')) + r') |  row ' + str(start_index_task) + r' to row ' + str(end_index_task) + r'| ' + r'Task # ' + str(Task_index +1) + r' started at:' + str(Current_date) + r' '+ str(Current_time)) 
    arcpy.AddMessage('.......................................................')
    arcpy.AddMessage('.......................................................')


    # Existing Fields LCP layer:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        
    Field_PathCost= r'PathCost'
    Field_description= r'PathDes'
    Existing_field_with_ID_origin_point = r'OriginID'
    Existing_field_with_ID_destination_point = r'DestinID'
    Field_PathLenght = r'Shape_Length'
    
    Field_to_match_tables=Field_description
    
    OIDField_LCPs = arcpy.Describe(path_layer_with_LCPs).OIDFieldName
    
    Result_layer = os.path.join(location_to_save_temp_layers, r'LCPs_with_attributes_' + str(Type_of_LCPs) + '_task_' + str(Task_index+1))
        
    # Get attributes nodes:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    ID_field_nodes_layer=[ID_field_nodes_layer]
        
    # List of Node attributes to load
    list_node_attributes_to_load = [r'ID_CONN',r'ID_MCI', r'TYPE',r'NODE',r'Elevation_M', r'STATUS','NAME',r'Q_m3s']
    
    # Get a list of all the existing fields of the Nodes layer:
    #List_of_field_names_nodes_layer = [f.name for f in arcpy.ListFields(path_layer_with_all_nodes)]    
    
    NP_Array_Nodes_layer =  arcpy.da.FeatureClassToNumPyArray (path_layer_with_all_nodes,list_node_attributes_to_load,skip_nulls=False,null_value=-99999)
    df_Node_attributes = pd.DataFrame(NP_Array_Nodes_layer, columns = list_node_attributes_to_load)
    
    # New Fields LCP layer    
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    # New Field 1 = 'EnvRes' | NUMERIC: 2 Decimals
    New_field_Environmental_restriction = r'EnvRes'  
    N_field_1_Name  =  New_field_Environmental_restriction
    N_field_1_Alias =  New_field_Environmental_restriction
    N_field_1_type = "DOUBLE"
    N_field_1_Precision = 12
    N_field_1_Scale = 2
    N_field_1_is_nullable= "NULLABLE"
    
    # New Field 2 = 'Delta_H' | NUMERIC: 2 Decimals
    New_field_Delta_H = r'Delta_H'  
    N_field_2_Name  = New_field_Delta_H 
    N_field_2_Alias = New_field_Delta_H 
    N_field_2_type = "DOUBLE"
    N_field_2_Precision = 12
    N_field_2_Scale = 2
    N_field_2_is_nullable= "NULLABLE"

    # Attributes Origin nodes:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    # New Field 3 =  'O_MCI' | TEXT: 10 Characters
    New_field_with_origin_MCI_ID = r'O_MCI'    
    N_field_3_Name  = New_field_with_origin_MCI_ID 
    N_field_3_Alias = New_field_with_origin_MCI_ID 
    N_field_3_type = "TEXT"
    N_field_3_Length  = 10
    N_field_3_is_nullable= "NULLABLE"
    
    # New Field 4 =  'O_type' | TEXT: 40 Characters
    New_filed_with_origin_type = r'O_type'   
    N_field_4_Name  = New_filed_with_origin_type 
    N_field_4_Alias = New_filed_with_origin_type 
    N_field_4_type = "TEXT"
    N_field_4_Length  = 40
    N_field_4_is_nullable= "NULLABLE"
    
    # New Field 5 = 'O_Node' | TEXT: 5 Characters
    New_Field_with_origin_description = r'O_Node'   
    N_field_5_Name  = New_Field_with_origin_description 
    N_field_5_Alias = New_Field_with_origin_description 
    N_field_5_type = "TEXT"
    N_field_5_Length  = 5
    N_field_5_is_nullable= "NULLABLE"
    
    # New Field 6 = 'O_elev' |  NUMERIC: 2 Decimals
    New_Field_with_origin_elevation  = r'O_elev'   
    N_field_6_Name  = New_Field_with_origin_elevation
    N_field_6_Alias = New_Field_with_origin_elevation
    N_field_6_type = "DOUBLE"
    N_field_6_Precision = 12
    N_field_6_Scale = 2
    N_field_6_is_nullable= "NULLABLE"
    
    # New Field 7 = 'O_status' | TEXT: 10 Characters
    New_Field_with_origin_status  = r'O_status' 
    N_field_7_Name  = New_Field_with_origin_status 
    N_field_7_Alias = New_Field_with_origin_status 
    N_field_7_type = "TEXT"
    N_field_7_Length  = 15
    N_field_7_is_nullable= "NULLABLE"
    
    # New Field 8 = 'O_name' | TEXT: 80 Characters
    New_Field_with_origin_name = r'O_name'  
    N_field_8_Name  = New_Field_with_origin_name 
    N_field_8_Alias = New_Field_with_origin_name 
    N_field_8_type = "TEXT"
    N_field_8_Length  = 80
    N_field_8_is_nullable= "NULLABLE"
    
    # New Field 9 = O_Qm3s'  |  NUMERIC: 6 Decimals
    New_Field_with_origin_Q = r'O_Qm3s'   
    N_field_9_Name  = New_Field_with_origin_Q
    N_field_9_Alias = New_Field_with_origin_Q
    N_field_9_type = "DOUBLE"
    N_field_9_Precision = 12
    N_field_9_Scale = 6
    N_field_9_is_nullable= "NULLABLE"
    
    # Attributes Destination nodes:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    # New Field 10 = 'D_MCI' | TEXT: 10 Characters
    New_field_with_destination_MCI_ID  = r'D_MCI'    
    N_field_10_Name  = New_field_with_destination_MCI_ID 
    N_field_10_Alias = New_field_with_destination_MCI_ID 
    N_field_10_type = "TEXT"
    N_field_10_Length  = 10
    N_field_10_is_nullable= "NULLABLE"
    
    # New Field 11 = 'D_type' | TEXT: 40 Characters
    New_filed_with_destination_type = r'D_type'  
    N_field_11_Name  = New_filed_with_destination_type 
    N_field_11_Alias = New_filed_with_destination_type 
    N_field_11_type = "TEXT"
    N_field_11_Length  = 40
    N_field_11_is_nullable= "NULLABLE"
    
    # New Field 12 = | TEXT: 5 Characters
    New_Field_with_destination_description= r'D_Node'   
    N_field_12_Name  = New_Field_with_destination_description 
    N_field_12_Alias = New_Field_with_destination_description 
    N_field_12_type = "TEXT"
    N_field_12_Length  = 5
    N_field_12_is_nullable= "NULLABLE"
    
    # New Field 13 = 'D_elev' |  NUMERIC: 2 Decimals
    New_Field_with_destination_elevation  = r'D_elev'   
    N_field_13_Name  = New_Field_with_destination_elevation
    N_field_13_Alias = New_Field_with_destination_elevation
    N_field_13_type = "DOUBLE"
    N_field_13_Precision = 12
    N_field_13_Scale = 2
    N_field_13_is_nullable= "NULLABLE"
    
    # New Field 14 = 'D_status' | TEXT: 10 Characters
    New_filed_with_destination_status = r'D_status' 
    N_field_14_Name  = New_filed_with_destination_status 
    N_field_14_Alias = New_filed_with_destination_status 
    N_field_14_type = "TEXT"
    N_field_14_Length  = 15
    N_field_14_is_nullable= "NULLABLE"
    
    # New Field 15 = 'D_name' | TEXT: 80 Characters
    New_filed_with_destination_name = r'D_name'   
    N_field_15_Name  = New_filed_with_destination_name 
    N_field_15_Alias = New_filed_with_destination_name 
    N_field_15_type = "TEXT"
    N_field_15_Length  = 80
    N_field_15_is_nullable= "NULLABLE"
    
    # New Field 16 ='D_Qm3s' |  NUMERIC: 6 Decimals
    New_filed_with_destination_Q = r'D_Qm3s'   
    N_field_16_Name  = New_filed_with_destination_Q
    N_field_16_Alias = New_filed_with_destination_Q
    N_field_16_type = "DOUBLE"
    N_field_16_Precision = 12
    N_field_16_Scale = 6
    N_field_16_is_nullable= "NULLABLE"
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    # Create a copy of the input LCPs to subset current task
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

    # Make a copy of the layer with LCPs 
    # Delete the rows you don't need -> creAte the subset for current task
    
    LCPs_current_task = os.path.join(location_to_save_temp_layers, r'LCPs_task_' + str(Task_index+1))
        
    #arcpy.management.Delete(LCPs_current_task)
    arcpy.CopyFeatures_management(path_layer_with_LCPs, LCPs_current_task)
    
    # Delete the rows you don't need in this task:
    
    with arcpy.da.UpdateCursor(LCPs_current_task, [OIDField_LCPs]) as cursor:
      for row in cursor:
          if row[0] < start_index_task or row[0] > end_index_task:
              cursor.deleteRow()
    
    # Define the indexes of this task:
    #..........................................................................
    OIDField_LCPs_current_task = arcpy.Describe(LCPs_current_task).OIDFieldName

    NP_Array_LCPs_current_task =  arcpy.da.FeatureClassToNumPyArray (LCPs_current_task,[OIDField_LCPs_current_task,Field_description],skip_nulls=False,null_value=-99999)
    df_LCPs_desciption_current_task = pd.DataFrame(NP_Array_LCPs_current_task, columns = [OIDField_LCPs_current_task,Field_description])
    List_of_LCP_number_IDs_current_task   = df_LCPs_desciption_current_task[OIDField_LCPs_current_task].tolist()
    #..........................................................................
 
    # Generate df with attributes of LCPs: 
    #..........................................................................
    List_of_field_names_LCPs_current_task = [f.name for f in arcpy.ListFields(LCPs_current_task)]    
    List_of_field_names_LCPs_current_task.remove('Shape')

    NP_Array_LCPs_current_task =  arcpy.da.FeatureClassToNumPyArray (LCPs_current_task,List_of_field_names_LCPs_current_task,skip_nulls=False,null_value=-99999)
    df_LCPs_this_task = pd.DataFrame(NP_Array_LCPs_current_task, columns = List_of_field_names_LCPs_current_task)

    list_LCPs_descriptions_current_task = df_LCPs_this_task[Field_description].tolist()
    
    Number_of_LCPs_current_task=len(list_LCPs_descriptions_current_task) 
    #..........................................................................
    
    
    #Calcaulte DeltaH and Env Restrictions for all LCPS current task
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

    List_of_LCP_descriptions = []
    List_of_Delta_H = []
    List_of_Envir_Res =[]
    
    # Field positions              0                    |                  1                     |        2       
    fields_to_use = [Existing_field_with_ID_origin_point,Existing_field_with_ID_destination_point,Field_description]
    
    LCP_count=1
        
    with arcpy.da.UpdateCursor(LCPs_current_task, fields_to_use) as cursor:
        
        # Loop trough all the LCPs to create the stack profiles 

        for row in cursor:
            
            # Each row represent a LCP
            Description_current_row= str(row[2])
            
            arcpy.AddMessage("Extracting Stack profile for LCP going " + Description_current_row.replace(r'-', r' ' ) )
            arcpy.AddMessage("Profile " + str(LCP_count) + r" out of " + str(Number_of_LCPs_current_task) + r' | Task # ' + str(Task_index +1) )
            
            # Create a Temp layer with just 1 LCP using select by attribute
            
            SQL_expression = "PathDes= '{}'".format(Description_current_row)

            one_LCP= arcpy.MakeFeatureLayer_management(LCPs_current_task, "Temp_LCP", SQL_expression)
            
            # save the TEMP layer 
            Temp_LCP_name = r'One_LCP'
            Temp_LCP_path = os.path.join(location_to_save_temp_layers,Temp_LCP_name)
            arcpy.CopyFeatures_management(one_LCP, Temp_LCP_path)

            H = 0
            # LCP processing: 
            #[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
            try:
                
                # Generate Stack profile (ArcGIS Table):
                #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    
                name_stack_profile_table = r'Stack_profile_' + Description_current_row.replace(r'-', r'_')
                Stack_profile_path = os.path.join(location_to_save_stack_profiles,name_stack_profile_table)
                
                # Create a stack profile (dbf file/table)
                arcpy.AddMessage(" Creating Stack profile for LCP going " + Description_current_row )
                
                arcpy.ddd.StackProfile(Temp_LCP_path,path_file_with_DEM,Stack_profile_path,None)
                    
                arcpy.AddMessage("Stack profile for LCP going " + Description_current_row + r' created successfully !')
                #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    
                    
                # here you calcualte the Delta H:
                #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

                try:
                    df = arcgis_table_to_df(Stack_profile_path)
                    n = len(df.index)
                     
                    # Calculate the difference in elevation only for the path sections that
                    # are going against gravity (from lower to higher elevation)
                    
                    if(Type_of_LCPs == 'one_way'):
                        
                        for i in range(1,n):
                            A = df.FIRST_Z[i+1]-df.FIRST_Z[i]
                            
                            if A < 0:
                                A = 0
                                H = H + A
                            else:
                                H = H + A
                        
                    elif(Type_of_LCPs == 'return'):
                        
                        for i in range(1,n-1):
                            A = df.FIRST_Z[i]-df.FIRST_Z[i+1]
                            if A < 0:
                                A = 0
                                H = H + A
                            else:
                                H = H + A

                except IndexError:
                    pass
                arcpy.AddMessage("Delta H for LCP going " + Description_current_row + r' : ' + str(H))
                #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                    
            except IndexError:
                
                print('Error Generating Stack profile for path going ' + Description_current_row.replace(r'-', r' ' ) )
                print('Delta H not calcualted')
                print('Stack profile files not generated')
                
                arcpy.AddMessage('Error Generating Stack profile for path going ' + Description_current_row.replace(r'-', r' ' ) )
                arcpy.AddMessage('Delta H not calcualted')
                pass
            
            # Add values for current LCP:
            List_of_LCP_descriptions.append(Description_current_row)
            List_of_Delta_H.append(H)
                
            # Here you extract the Environmental restriction raster for the current LCP:
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            Ouput_table_name_ZE= r'Total_EvR_LCP_' + Description_current_row.replace(r'-', r'_' )
            Ouput_table_ZE=  os.path.join(location_to_save_temp_layers,Ouput_table_name_ZE)
            StatisticType = "SUM"
            
            arcpy.AddMessage( r'Calculating Zonal Stats for LCP ' + Description_current_row.replace(r'-', r' ' ) )
            
            arcpy.ia.ZonalStatisticsAsTable(Temp_LCP_path,
                                            OIDField_LCPs,
                                            path_file_with_Environmental_restriction,
                                            Ouput_table_ZE,
                                            "DATA",
                                            StatisticType,
                                            "CURRENT_SLICE",
                                            90,
                                            "AUTO_DETECT")
            
                
            # here you extract the ZE value and add it to the master df  
            array = arcpy.da.TableToNumPyArray(Ouput_table_ZE, [StatisticType], skip_nulls=True)
            SUM_Evr = round(array[0].tolist()[0],3) # get the number out of the table
            List_of_Envir_Res.append(SUM_Evr)
            
            arcpy.AddMessage( r' LCP ' + str(LCP_count) + r' out of ' + str(Number_of_LCPs_current_task) + r' was processed susscefully !' + r' | Task # ' + str(Task_index +1))
            LCP_count=LCP_count+1
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                
            elapsed_time = (time.time() - time_before_execution_task)
            Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
            Fraction_of_hours, hours =math.modf(Seconds/3600)
            arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1))
            arcpy.AddMessage( r' Loop for Delta h and EnvR finished sucessfully ' + r' | Task # ' + str(Task_index +1))
            arcpy.AddMessage('.............')
            
            
            #[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

        
    
    arcpy.AddMessage(r'Number of LCPs current task: ' +  str(len(List_of_LCP_number_IDs_current_task)) + r' | Task # ' + str(Task_index +1))
    arcpy.AddMessage(r'Number of LCP descriptions current task: ' +  str(len(List_of_LCP_descriptions)) + r' | Task # ' + str(Task_index +1)) 
    arcpy.AddMessage(r'Number of Delta H values current task: ' +  str(len(List_of_Delta_H)) + r' | Task # ' + str(Task_index +1)) 
    arcpy.AddMessage(r'Number of EnvR values current task: ' +  str(len(List_of_Envir_Res)) + r' | Task # ' + str(Task_index +1)) 
    
    # Create DataFrame with all the  Delta H values :
    #..........................................................................
    data_DeltaH_current_task = {OIDField_LCPs:List_of_LCP_number_IDs_current_task, 'PathDes':List_of_LCP_descriptions, 'Delta_H':List_of_Delta_H}
    df_delta_H = pd.DataFrame(data_DeltaH_current_task)
    #..........................................................................
    

    # Create DataFrame with all  the  Environmental Restriction summatory along the paths:
    #......................................................................

    data_EnvR_current_task = {OIDField_LCPs:List_of_LCP_number_IDs_current_task,'PathDes':List_of_LCP_descriptions,'EnvRes':List_of_Envir_Res}
    df_EnvR= pd.DataFrame(data_EnvR_current_task)
    #......................................................................    
    
    
    # Create a new df with the attributes to add 
    # This is the same order in which the attributes will be added to the layer:
    #..............................................................................
   
    df_New_attribute_values = pd.merge(left=df_EnvR, right=df_delta_H, how='left', left_on=Field_to_match_tables, right_on=Field_to_match_tables)
    
    # WARNING !
    # The object ID fields are arbitrary and meaningless when creating layers 
    # using parallel computing. These numnbers depend of the order in which 
    # each row was created. when doing parallel processing it is impossible to 
    # guarantee that the Object ID of features is unique (layers are split)
    
    # DO NOT RELATE TABLES USING OBJECT IDS !
    
    # It is better to merge tables using the description field, 
    # so let's delEte the OBJECT ID fields from both tables 
    
    df_LCPs_this_task.drop(['OBJECTID'], axis=1, inplace=True)    
    df_New_attribute_values.drop(['OBJECTID_x'], axis=1, inplace=True)    
    df_New_attribute_values.drop(['OBJECTID_y'], axis=1, inplace=True)    
    
    
    df_New_attributes_LCP_layer = pd.merge(left=df_LCPs_this_task, right=df_New_attribute_values, how='left', left_on=Field_to_match_tables, right_on=Field_to_match_tables)

    # Here you re-order the df so it coincides with the way the attributes 
    # are created in the new layer:
        
    new_order =[Field_description,                       # PathDes
                Field_PathLenght,                        # Shape_Length
                Existing_field_with_ID_origin_point,     # OriginID
                Existing_field_with_ID_destination_point,# DestinID 
                Field_PathCost,                          # PathCost
                New_field_Environmental_restriction,     # EnvRes
                New_field_Delta_H]                       # Delta_H 
    
    df_New_attributes_LCP_layer = df_New_attributes_LCP_layer.reindex(columns=new_order)
    
       
    # Here you merge the 7 attributes of the Origin Node to the df:
    df_New_attributes_LCP_layer=pd.merge(left=df_New_attributes_LCP_layer, right=df_Node_attributes, how='left', left_on=Existing_field_with_ID_origin_point, right_on=ID_field_nodes_layer[0])
    
    # Rename Columns of the Origin node attributes:
    df_New_attributes_LCP_layer = df_New_attributes_LCP_layer.rename(columns={r'ID_MCI':New_field_with_origin_MCI_ID,
                                                                              r'TYPE':New_filed_with_origin_type,
                                                                              r'NODE':New_Field_with_origin_description,
                                                                              r'Elevation_M':New_Field_with_origin_elevation,
                                                                              r'STATUS':New_Field_with_origin_status,
                                                                              r'NAME':New_Field_with_origin_name,
                                                                              r'Q_m3s':New_Field_with_origin_Q}) 
    
    
    # Here you merge the 7 attributes of the Destination node to the df:
    df_New_attributes_LCP_layer=pd.merge(left=df_New_attributes_LCP_layer, right=df_Node_attributes, how='left', left_on=Existing_field_with_ID_destination_point, right_on=ID_field_nodes_layer[0])
    
    # Rename Columns
    df_New_attributes_LCP_layer = df_New_attributes_LCP_layer.rename(columns={r'ID_MCI':New_field_with_destination_MCI_ID,
                                                                              r'TYPE':New_filed_with_destination_type,
                                                                              r'NODE':New_Field_with_destination_description,
                                                                              r'Elevation_M':New_Field_with_destination_elevation,
                                                                              r'STATUS':New_filed_with_destination_status,
                                                                              r'NAME':New_filed_with_destination_name,
                                                                              r'Q_m3s':New_filed_with_destination_Q})
    

    # Delete attributes you are not going to use after  merging:
    df_New_attributes_LCP_layer.drop(r'ID_CONN_x', axis=1, inplace=True)   
    df_New_attributes_LCP_layer.drop(r'ID_CONN_y', axis=1, inplace=True)    
        
    #Create a copy of the LCP layer to save the results
    #...............................................................................
    
    arcpy.CopyFeatures_management(LCPs_current_task, Result_layer)
    
    List_of_field_names_LCPs_current_task = [f.name for f in arcpy.ListFields(LCPs_current_task)]    

    # Delete  fields of the copy layer except for :
    Fields_to_keep= [OIDField_LCPs,
                     r'Shape',
                     Field_description,
                     'Shape_Length']
    
    Fields_to_delete = np.setdiff1d(List_of_field_names_LCPs_current_task,Fields_to_keep)
    
    Fields_to_delete=Fields_to_delete.tolist()
    
    arcpy.DeleteField_management(Result_layer, Fields_to_delete)
    
    
    # Add the new attributes to the output LCP layer:
    #..............................................................................
    
    elapsed_time = (time.time() - time_before_execution_task)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1))
    
    arcpy.AddMessage(r'Creating new fields in LCP layer |  Task # ' +  str(Task_index +1)+ r', please wait....')

    # here you create the path to the attribute table:
        
    Result_layer_filename, Result_layer_extension = os.path.splitext(Result_layer)
    
    if (Result_layer_extension == r'.shp'):
        inFeatures= Result_layer_filename + r'.dbf' # if resutl layer is a shapefile
    else:
        inFeatures = Result_layer # if result layer is inside a Geo-database
    
    # Catalog of new fields:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    # N_field_1  = Environmental_restriction =  r'EnvRes'  
    # N_field_2  = Delta_H =                    r'Delta_H'  
    # N_field_3  = origin_MCI_ID =              r'O_MCI'    
    # N_field_4  = origin_type =                r'O_type'  
    # N_field_5  = origin_description =         r'O_Node'   
    # N_field_6  = origin_elevation  =          r'O_elev'   
    # N_field_7  = origin_status =              r'O_status' 
    # N_field_8  = origin_name =                r'O_name'   
    # N_field_9  = origin_Q =                   r'O_Qm3s'   
    # N_field_10 = destination_MCI_ID  =        r'D_MCI'    
    # N_field_11 = destination_type =           r'D_type'  
    # N_field_12 = destination_description=     r'D_Node'   
    # N_field_13 = destination_elevation  =     r'D_elev'   
    # N_field_14 = destination_status =         r'D_status' 
    # N_field_15 = destination_name =           r'D_name'   
    # N_field_16 = destination_Q =              r'D_Qm3s'
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    # Add Field  NUMERIC -> OriginID
    arcpy.AddField_management(inFeatures, Existing_field_with_ID_origin_point, "SHORT", 10,field_alias=Existing_field_with_ID_origin_point, field_is_nullable="NULLABLE")
    # Add Field  NUMERIC -> DestinID
    arcpy.AddField_management(inFeatures, Existing_field_with_ID_destination_point, "SHORT", 10,field_alias=Existing_field_with_ID_destination_point, field_is_nullable="NULLABLE")
    # Add Field  DOUBLE -> PathCost
    arcpy.AddField_management(in_table=inFeatures,field_name=Field_PathCost,field_type="DOUBLE",field_precision=12,field_scale=2,field_alias=Field_PathCost,field_is_nullable="NULLABLE")

    # Field 1: NUMERIC
    create_new_numeric_field(inFeatures,N_field_1_Name,N_field_1_Alias,N_field_1_type,N_field_1_Precision,N_field_1_Scale,N_field_1_is_nullable)
    
    # Field 2: NUMERIC
    create_new_numeric_field(inFeatures,N_field_2_Name,N_field_2_Alias,N_field_2_type,N_field_2_Precision,N_field_2_Scale,N_field_2_is_nullable)
    
    # Field 3 TEXT
    create_new_text_field (inFeatures,N_field_3_Name,N_field_3_Alias,N_field_3_type,N_field_3_Length,N_field_3_is_nullable)
    
    # Field 4: TEXT
    create_new_text_field (inFeatures,N_field_4_Name,N_field_4_Alias,N_field_4_type,N_field_4_Length,N_field_4_is_nullable)
    
    # Field 5: TEXT
    create_new_text_field (inFeatures,N_field_5_Name,N_field_5_Alias,N_field_5_type,N_field_5_Length,N_field_5_is_nullable)
    
    # Field 6: NUMERIC
    create_new_numeric_field(inFeatures,N_field_6_Name,N_field_6_Alias,N_field_6_type,N_field_6_Precision,N_field_6_Scale,N_field_6_is_nullable)
    
    # Field 07: TEXT
    create_new_text_field (inFeatures,N_field_7_Name,N_field_7_Alias,N_field_7_type,N_field_7_Length,N_field_7_is_nullable)
   
    # Field 08: TEXT
    create_new_text_field (inFeatures,N_field_8_Name,N_field_8_Alias,N_field_8_type,N_field_8_Length,N_field_8_is_nullable)
    
    # Field 09: NUMERIC
    create_new_numeric_field(inFeatures,N_field_9_Name,N_field_9_Alias,N_field_9_type,N_field_9_Precision,N_field_9_Scale,N_field_9_is_nullable)
    
    # Field 10: TEXT
    create_new_text_field (inFeatures,N_field_10_Name,N_field_10_Alias,N_field_10_type,N_field_10_Length,N_field_10_is_nullable)
    
    # Field 11: TEXT
    create_new_text_field (inFeatures,N_field_11_Name,N_field_11_Alias,N_field_11_type,N_field_11_Length,N_field_11_is_nullable)
    
    # Field 12: TEXT
    create_new_text_field (inFeatures,N_field_12_Name,N_field_12_Alias,N_field_12_type,N_field_12_Length,N_field_12_is_nullable)
    
    # Field 13: NUMERIC
    create_new_numeric_field(inFeatures,N_field_13_Name,N_field_13_Alias,N_field_13_type,N_field_13_Precision,N_field_13_Scale,N_field_13_is_nullable)
    
    # Field 14: TEXT
    create_new_text_field (inFeatures,N_field_14_Name,N_field_14_Alias,N_field_14_type,N_field_14_Length,N_field_14_is_nullable)
    
    # Field 15: TEXT
    create_new_text_field (inFeatures,N_field_15_Name,N_field_15_Alias,N_field_15_type,N_field_15_Length,N_field_15_is_nullable)
    
    # Field 16: NUMERIC
    create_new_numeric_field(inFeatures,N_field_16_Name,N_field_16_Alias,N_field_16_type,N_field_16_Precision,N_field_16_Scale,N_field_16_is_nullable)
    #..............................................................................
    
    elapsed_time = (time.time() - time_before_execution_task)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1))
    
    # Modify attributes:
    #..............................................................................
    
    arcpy.AddMessage(r'Assigning new attributes to polylines, please wait....' + r' | Task # ' + str(Task_index +1))
    
    # Here you make sure the dataframe you will use to assign values to the GIS layer
    # has the same order that the polylines: 
    
    Layer_order =  df_LCPs_this_task[Field_to_match_tables].tolist()
    
    df_New_attributes_LCP_layer= df_New_attributes_LCP_layer.iloc[list(map(df_New_attributes_LCP_layer[Field_to_match_tables].tolist().index, Layer_order))]
    
    fields_to_modify = [Existing_field_with_ID_origin_point,
                        Existing_field_with_ID_destination_point,
                        Field_PathCost,
                        N_field_1_Name,N_field_2_Name,N_field_3_Name,N_field_4_Name,
                        N_field_5_Name,N_field_6_Name,N_field_7_Name,N_field_8_Name,
                        N_field_9_Name,N_field_10_Name,N_field_11_Name,N_field_12_Name,
                        N_field_13_Name,N_field_14_Name,N_field_15_Name,N_field_16_Name]
    
    row_count=0
    
    with arcpy.da.UpdateCursor(inFeatures, fields_to_modify) as cursor:
      
        for row in cursor:
          
          row[0]  =int(df_New_attributes_LCP_layer[Existing_field_with_ID_origin_point][row_count])      # NUMERIC Integer : 'OriginID' 
          row[1]  =int(df_New_attributes_LCP_layer[Existing_field_with_ID_destination_point][row_count]) # NUMERIC Integer : 'OriginID' 
          row[2]  =round(df_New_attributes_LCP_layer[Field_PathCost][row_count],2)                       # NUMERIC 2 decimals : 'PathCost' 
          
          row[3]  = round(df_New_attributes_LCP_layer[N_field_1_Name][row_count],2)   # New Field 1  : NUMERIC 2 decimals : 'EnvRes' 
          row[4]  = round(df_New_attributes_LCP_layer[N_field_2_Name][row_count],2)   # New Field 2  : NUMERIC 2 decimals : 'Delta_H'
          row[5]  = df_New_attributes_LCP_layer[N_field_3_Name][row_count]            # New Field 3  : TEXT               : 'O_MCI'  
          row[6]  = df_New_attributes_LCP_layer[N_field_4_Name][row_count]            # New Field 4  : TEXT               : 'O_type' 
          row[7]  = df_New_attributes_LCP_layer[N_field_5_Name][row_count]            # New Field 5  : TEXT               : 'O_Node'
          row[8]  = round(df_New_attributes_LCP_layer[N_field_6_Name][row_count],2)   # New Field 6  : NUMERIC 2 decimals : 'O_elev'
          row[9]  = df_New_attributes_LCP_layer[N_field_7_Name][row_count]            # New Field 7  : TEXT               : 'O_status' 
          row[10] = df_New_attributes_LCP_layer[N_field_8_Name][row_count]            # New Field 8  : TEXT               : 'O_name'  
          row[11] = round(df_New_attributes_LCP_layer[N_field_9_Name][row_count],6)   # New Field 9  : NUMERIC 6 decimals : 'O_Qm3s'
          row[12] = df_New_attributes_LCP_layer[N_field_10_Name][row_count]           # New Field 10 : TEXT               : 'D_MCI' 
          row[13] = df_New_attributes_LCP_layer[N_field_11_Name][row_count]           # New Field 11 : TEXT               : 'D_type'
          row[14] = df_New_attributes_LCP_layer[N_field_12_Name][row_count]           # New Field 12 : TEXT               : 'D_Node' 
          row[15] = round(df_New_attributes_LCP_layer[N_field_13_Name][row_count],2)  # New Field 13 : NUMERIC 2 decimals : 'D_elev'  
          row[16] = df_New_attributes_LCP_layer[N_field_14_Name][row_count]           # New Field 14 : TEX                : 'D_status' 
          row[17] = df_New_attributes_LCP_layer[N_field_15_Name][row_count]           # New Field 15 : TEXT               : 'D_name' 
          row[18] = round(df_New_attributes_LCP_layer[N_field_16_Name][row_count],6)  # New Field 16 : NUMERIC 6 decimals : 'D_Qm3s'
          
          # Replace -9999 values for Null if the field is nullable
          if(np.logical_and(row[3] == -99999, N_field_1_is_nullable == "NULLABLE")):
              row[3] = None
          if(np.logical_and(row[4] == -99999, N_field_2_is_nullable == "NULLABLE")):
              row[4] = None
          if(np.logical_and(row[8] == -99999, N_field_6_is_nullable == "NULLABLE")):
              row[8] = None
          if(np.logical_and(row[11] == -99999, N_field_9_is_nullable == "NULLABLE")):
              row[11] = None
          if(np.logical_and(row[15] == -99999, N_field_13_is_nullable == "NULLABLE")):
              row[15] = None
          if (np.logical_and(row[18] == -99999, N_field_16_is_nullable == "NULLABLE")):
              row[18] = None
          
          row_count=row_count+1
          cursor.updateRow(row)
          
    elapsed_time = (time.time() - time_before_execution_task)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    arcpy.AddMessage('All fields populated succesfully !' + r' | Task # ' + str(Task_index +1) + r'| LCP processing ' + str(Type_of_LCPs.replace(r'_', r' ')))    
    arcpy.AddMessage(r'Results' + r' Task # ' + str(Task_index +1) + ' loated at : ' + inFeatures)
    arcpy.AddMessage('.......................................................')
    arcpy.AddMessage('.......................................................')
    
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('.......................................................')
        log_file.write('\n')
        log_file.write(r'Layer with proccesed LCPs ('+ str(Type_of_LCPs.replace(r'_', r' ')) +') for Task #' + str(Task_index +1)+ r' Located at: ' + str(inFeatures) )
        log_file.write('\n')
        log_file.write(  r'Task # ' + str(Task_index +1) + r' LCP processing (' + str(Type_of_LCPs.replace(r'_', r' ')) + ') Ended at:' + str(Current_date) + r' '+ str(Current_time))
        log_file.write('\n')
        log_file.write(  'ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r' | Task # ' + str(Task_index +1) )
        log_file.write('\n')
        log_file.write('.......................................................')

    
#..............................................................................

#..............................................................................
def return_tuple_inputs_LCPs_gen(l1,l2,l3,l4,l5,l6,l7,l8,l9):
    
    merged_list = [(l1[i],l2[i],l3[i],l4[i],l5[i],l6[i],l7[i],l8[i],l9[i]) for i in range(0, len(l1))]
    
    return merged_list
#..............................................................................    

#..............................................................................
def Gen_LCPs_selected_nodes(Task_index,                               #1
                            path_layer_with_all_nodes,                #2
                            ID_field_nodes_layer,                     #3 
                            list_ID_nodes_as_text,                    #4
                            path_PCD_BL_rasters,                      #5
                            location_to_save_layer_LCPs,              #6
                            location_to_save_temp_layers,             #7
                            time_before_execution,                    #8
                            location_log_file):                       #9
    
    arcpy.AddMessage('///////////////////////////////////////////////////////')
    arcpy.AddMessage( r'LCP Generation | Task # ' + str(Task_index +1)  ) 
    arcpy.AddMessage('///////////////////////////////////////////////////////')
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('/////////////////////////////////////////////////////////////////////////')
        log_file.write('\n')
        log_file.write(  r'LCP Generation | Task # ' + str(Task_index +1) + r' started at:' + str(Current_date) + r' '+ str(Current_time))
        log_file.write('\n')
        log_file.write('/////////////////////////////////////////////////////////////////////////')

    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    node_number =1
    Number_of_nodes_current_task= len(list_ID_nodes_as_text)
    
    
    for node in list_ID_nodes_as_text:
        
        ID_node_to_parse =str(node)
        
        # Generate the layer with the LCPs (one way):
        #======================================================================    
        generate_LCP_layer(Task_index,
                           path_layer_with_all_nodes,
                           ID_field_nodes_layer,
                           ID_node_to_parse,
                           path_PCD_BL_rasters,
                           location_to_save_temp_layers,
                           location_to_save_layer_LCPs,
                           time_before_execution)
        
        
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        elapsed_time = (time.time() - time_before_execution)
        Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
        Fraction_of_hours, hours =math.modf(Seconds/3600)
            
        Current_date_time = str(datetime.datetime.now())
        Current_date = Current_date_time.split()[0]
        Current_time = Current_date_time.split()[1]

        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('...................................')
            log_file.write('\n')
            log_file.write(  r'LCPs for node '+ ID_node_to_parse + r' (one way) generated correctly, Node ' + str(node_number)+ r' out of ' +str(Number_of_nodes_current_task) + ' | Task # ' + str(Task_index +1) + ' | ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r'| '+ str(Current_date) + r' '+ str(Current_time) )
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        #======================================================================    
        
        # Generate the Layer with Inversed LCPs:
        #======================================================================
        path_layer_with_LCPs_one_way =os.path.join(location_to_save_layer_LCPs,r'LCPs_node_' + str(ID_node_to_parse))
        
        generate_return_LCP_layer (Task_index,
                                   path_layer_with_LCPs_one_way,
                                   ID_node_to_parse,
                                   location_to_save_temp_layers,
                                   location_to_save_layer_LCPs,
                                   time_before_execution)
        
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        elapsed_time = (time.time() - time_before_execution)
        Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
        Fraction_of_hours, hours =math.modf(Seconds/3600)
            
        Current_date_time = str(datetime.datetime.now())
        Current_date = Current_date_time.split()[0]
        Current_time = Current_date_time.split()[1]

        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('...................................')
            log_file.write('\n')
            log_file.write(  r'LCPs (return) for node '+ ID_node_to_parse + r' generated correctly, Node ' + str(node_number)+ r' out of ' +str(Number_of_nodes_current_task) + ' | Task # ' + str(Task_index +1) + ' | ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' + r'| '+ str(Current_date) + r' '+ str(Current_time) )
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        #======================================================================
        node_number = node_number +1
        
    #..........................................................................        
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write(  r'LCP generation Task # ' + str(Task_index +1) + r'completed successfully  at:' + str(Current_date) + r' '+ str(Current_time))
        log_file.write('\n')
        log_file.write(  'ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds'  )

    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
      
#..............................................................................        
#                                                                          Main
#..............................................................................
def main(p1,p2,p3,p4,p5,p6,p7,p8,p9):
    
    arcpy.AddMessage(r':::::::::::::::::::::::::::::::::::::::')
    arcpy.AddMessage(r':::::::::::::::::::::::::::::::::::::::')
    
    time_before_execution_main = time.time()
    
    #Definition of execution variables:
    #..........................................................................
    path_layer_with_all_nodes=p1
    ID_field_nodes_layer=[p2]
    
    if(p3 == 'all' or p3 == r'All' or p3 =='ALL' or p3== 'aLl' or p3== 'alL' or p3 == r'[all]' or p3 == r'[ALL]' or p3 == r'[ALl]' or p3 == r'[]' or p3 == r''):
        
        # load layer with all nodes and convert it to a list of strings:
            
        List_of_field_names = [f.name for f in arcpy.ListFields(path_layer_with_all_nodes)]    
        List_of_field_names.remove('Shape')
        
        NP_Array_nodes =  arcpy.da.FeatureClassToNumPyArray (path_layer_with_all_nodes,List_of_field_names,skip_nulls=False,null_value=-99999)
        df_nodes = pd.DataFrame(NP_Array_nodes, columns = List_of_field_names)
        List_of_nodes_IDs  = df_nodes[p2].tolist()
        
        list_ID_nodes_as_text = [str(i) for i in List_of_nodes_IDs]
        print(r'All nodes will be processed: ' + str(len(list_ID_nodes_as_text)) + r' nodes')
        print(r'WARNING !!  Estimated Execution Time: ' + str( int((10*(len(list_ID_nodes_as_text)))/60) )  + r' hours ' + str( (10*(len(list_ID_nodes_as_text)))%60 ) +  ' minutes (4 cores or more)')

    else:
        list_ID_nodes_as_text=(((p3.replace(r' ', r'')).strip(r'[')).strip(r']')).split(r',')
        if (int(p9) >= 4):
            print(r'Estimated Execution Time: ' + str( int((10*(len(list_ID_nodes_as_text)))/60) )  + r' hours ' + str( (10*(len(list_ID_nodes_as_text)))%60 ) +  ' minutes (4 cores or more)')
        elif (int(p9) < 4):
            print(r'Estimated Execution Time: ' + str( 2*int((10*(len(list_ID_nodes_as_text)))/60) )  + r' hours ' + str( (20*(len(list_ID_nodes_as_text)))%60 ) +  ' minutes (3 cores or less)')

    path_file_with_cost_raster=p4
    path_file_with_DEM=p5
    path_file_with_Environmental_restriction=p6
    Root_folder_results=p7
    folder_name_results=p8
    number_of_proccessors_to_use=int(p9)
    
    Number_of_Nodes_to_process=len(list_ID_nodes_as_text)
    
    #..........................................................................

    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # Validation of inputs:
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!    
    
    arcpy.AddMessage(r'Veryfying computing resources....')

    #get the number of cores of your computer:
    Total_number_of_threads=os.cpu_count() 
    Total_number_of_processesors=Total_number_of_threads/2

    if(number_of_proccessors_to_use>= (Total_number_of_processesors)):
        arcpy.AddMessage('ERROR 101: you should not use that many processors, your computer may crash !')
        arcpy.AddMessage('Total number of processors available on your machine: ' + str(Total_number_of_processesors))
        arcpy.AddMessage('Recommended number of processors to use: ' + str(Total_number_of_processesors-1))
        sys.exit() 
    
    arcpy.AddMessage(r'Veryfying that input node layer is the right type....')

    desc = arcpy.Describe(path_layer_with_all_nodes)
    if not (desc.shapeType == 'Point'):
        arcpy.AddMessage( r'ERROR 101: Input layer is not a Point layer !')
        arcpy.AddMessage( r'Please change the input node layer and try again...')
        sys.exit() 
        
    arcpy.AddMessage(r'Veryfying that the input node layer has the right atttribute fields....')
    
    # Check the list of fields in the nodes layer:
    #..........................................................................
    List_of_field_names = [f.name for f in arcpy.ListFields(path_layer_with_all_nodes)]    
    List_of_field_names.remove('Shape')    
    
    list_of_required_Fields= ['OBJECTID','ID_CONN','ID_MCI','NODE','TYPE','STATUS','UTM_East','UTM_North','Elevation_M','NAME','Q_m3s']
    
    if not (set(list_of_required_Fields).issubset(List_of_field_names)):
        d = {j:i for i,j in enumerate(list_of_required_Fields)}
        missing_attributes = sorted(list((set(list_of_required_Fields) - set(List_of_field_names))), key = lambda x: d[x])
        arcpy.AddMessage( r'ERROR 101: Input layer does not have the right Fields !!')
        arcpy.AddMessage( r'Missing attribute fields: ' + str(missing_attributes))
        sys.exit() 
    
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   
    #     ^     ^     ^     ^     ^     ^     ^     ^     ^     ^     ^     ^ 
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!    
    
    
    #&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    # Create Folders and GDBs for results:
    #&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    
    Main_folder_path_results  = os.path.join(Root_folder_results,folder_name_results)
    
    # create the main output folder:  
    if not os.path.exists(Main_folder_path_results):
        os.makedirs(Main_folder_path_results)
        arcpy.AddMessage("Root folder to save results did not exist and was created: " + Main_folder_path_results)
    
    Folder_path_raster_results = os.path.join(Main_folder_path_results,r'Results_parallel_processing_rasters')
    Folder_path_vector_results = os.path.join(Main_folder_path_results,r'Results_parallel_processing_vector')
    Folder_path_excel_results  = os.path.join(Main_folder_path_results,r'Results_excel_files')
    
    # create the folder to save raster results:  
    #..........................................................................
    if os.path.isdir(Folder_path_raster_results):
        #  check if the folder already exisit delete it to avoid errors

        try:
            shutil.rmtree(Folder_path_raster_results)
            arcpy.AddMessage(r' Folder to save raster results already existed and was deleted')
        except ValueError:
            warnings.warn(r'Folder to save raster results could not be deleted !')
            pass
     
        # create the foder again
        os.mkdir(Folder_path_raster_results)
    else:
           os.makedirs(Folder_path_raster_results)
           arcpy.AddMessage(r'Folder to save raster results did not exist and was created' )
    #..........................................................................
    
    # create the folder to save vector results:
    #..........................................................................
    if os.path.isdir(Folder_path_vector_results):
        #  check if the folder already exisit delete it to avoid errors

        try:
            shutil.rmtree(Folder_path_vector_results)
            arcpy.AddMessage(r' Folder to save vector results already existed and was deleted')
        except ValueError:
            warnings.warn(r'Folder to save vector results could not be deleted !')
            pass
     
        # create the foder again
        os.mkdir(Folder_path_vector_results)
    else:
           os.makedirs(Folder_path_vector_results)
           arcpy.AddMessage("Folder to save vector results did not exist and was created")
    #..........................................................................
    
    # create the folder to save excel files:  
    #..........................................................................
    if os.path.isdir(Folder_path_excel_results):
        #  check if the folder already exisit delete it to avoid errors

        try:
            shutil.rmtree(Folder_path_excel_results)
            arcpy.AddMessage(r' Folder to save excel results already existed and was deleted')
        except ValueError:
            warnings.warn(r'Folder to save excel results could not be deleted !')
            pass
     
        # create the foder again
        os.mkdir(Folder_path_excel_results)
    else:
           os.makedirs(Folder_path_excel_results)
           arcpy.AddMessage("Folder to save excel results did not exist and was created")
    #..........................................................................
    
    #  create the Global Geo-database to save the final results:
    arcpy.management.CreateFileGDB(Main_folder_path_results, "Results", "CURRENT")
    path_GDB_results = os.path.join(Main_folder_path_results,r'Results.gdb')
    
    # Create the log-file
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    # Creates a .TXT file to write the relevant details of the run :
    
    location_log_file = os.path.join(Main_folder_path_results,'00-Run-details.txt')
    if(os.path.exists(location_log_file)):
        os.remove(location_log_file) 
    
    open(location_log_file, 'a').close()
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write(r'Process started on the ' + str(Current_date) + r' '+ str(Current_time))
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::    
    
        
    #--------------------------------------------------------------------------
    # Split tasks for PCD & BL Raster processing:
    #--------------------------------------------------------------------------
             
    arcpy.AddMessage('Splitting tasks for Raster processing, please wait...' )
    
    if(Number_of_Nodes_to_process==1):
        list_task_indices_raster_processing=[0]
    elif (Number_of_Nodes_to_process <= number_of_proccessors_to_use):    
        list_task_indices_raster_processing = [item for item in range(0, Number_of_Nodes_to_process)]
    else:
        list_task_indices_raster_processing = [item for item in range(0, number_of_proccessors_to_use)]
    
    Number_of_tasks_raster_processing= len(list_task_indices_raster_processing)
    arcpy.AddMessage('Number of tasks (parallel instances) to split raster processing: ' + str(Number_of_tasks_raster_processing)  )
    
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('Raster processing tasks were Splitted in ' + str(Number_of_tasks_raster_processing) + r' cores ' )
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    Iterations_per_task= int(Number_of_Nodes_to_process/Number_of_tasks_raster_processing)
    residual_last_core=Number_of_Nodes_to_process % Number_of_tasks_raster_processing
    
    # This indices make reference to the list with nodes:
    #..........................................................................   
    Start_index=0
    End_index =len(list_ID_nodes_as_text)-1
    #..........................................................................
    
    list_path_layer_with_all_nodes_RASTER_PROCESSING=[]
    
    list_start_indices_tasks_RASTER_PROCESSING=[]
    list_end_indices_tasks_RASTER_PROCESSING =[]
    
    list_GDBs_locs_TEMP_raster_results_tasks= []
        
    for i in range (0, Number_of_tasks_raster_processing):
        
        # Fill the lists with the indices to split the list of nodes:
        #......................................................................
        
        if(i==0):
            currrent_start_index =  Start_index
        elif(i>0):
            currrent_start_index= list_end_indices_tasks_RASTER_PROCESSING[i-1]+1
            
        list_start_indices_tasks_RASTER_PROCESSING.append(currrent_start_index)
        
        currrent_end_index = currrent_start_index + Iterations_per_task -1
        list_end_indices_tasks_RASTER_PROCESSING.append(currrent_end_index)
        #......................................................................
        
        #  create the Geo-databases to save the results of each task
        arcpy.management.CreateFileGDB(Folder_path_raster_results, "Temp_raster_processing_task_" + str(i+1), "CURRENT")
        TEMP_GDB_path = os.path.join(Folder_path_raster_results,"Temp_raster_processing_task_" + str(i+1)+ r'.gdb')
        list_GDBs_locs_TEMP_raster_results_tasks.append(TEMP_GDB_path)
        
        # Make a copy of the input layer with all the nodes in the new Temp GDB
        Temp_copy_nodes_layer = os.path.join(TEMP_GDB_path,r'copy_input_layer_all_nodes_T_' +str(i+1))
        arcpy.CopyFeatures_management(path_layer_with_all_nodes, Temp_copy_nodes_layer)
        list_path_layer_with_all_nodes_RASTER_PROCESSING.append(Temp_copy_nodes_layer)
        
    if(residual_last_core>0):
        list_end_indices_tasks_RASTER_PROCESSING[Number_of_tasks_raster_processing-1]=End_index
    
    # Here you print in console the description of each task:
    #..........................................................................    
    Number_of_nodes_to_process_according_to_task_dsitribution = 0
    for task in list_task_indices_raster_processing:
        
        start_i =  list_start_indices_tasks_RASTER_PROCESSING[task]
        end_i   =  list_end_indices_tasks_RASTER_PROCESSING[task]
        
        number_of_nodes_i = (end_i-start_i) +1
        Number_of_nodes_to_process_according_to_task_dsitribution = Number_of_nodes_to_process_according_to_task_dsitribution+number_of_nodes_i
        arcpy.AddMessage('PCD/BL raster generation Task #' + str(task+1) + r': Node: ' + list_ID_nodes_as_text[start_i] + r' to Node: ' + list_ID_nodes_as_text[end_i] + r' :::: ' +  r' Number of nodes = '+ str(number_of_nodes_i))
        
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('PCD/BL raster generation Task #' + str(task+1) + r': Node: ' + list_ID_nodes_as_text[start_i] + r' to Node:' + list_ID_nodes_as_text[end_i] + r'::::' +  r'Number of nodes = '+ str(number_of_nodes_i))
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    if not (Number_of_nodes_to_process_according_to_task_dsitribution == Number_of_Nodes_to_process):
        arcpy.AddMessage(r'ERROR 101: There was a problem distributting raster processing tasks among the cores, reduce number of processors to use or contact Gabriel Perez Murillo (uqgpere2@uq.edu.au)')
    
    arcpy.AddMessage(r'Total Number of Nodes to process: ' + str(Number_of_nodes_to_process_according_to_task_dsitribution))   
    arcpy.AddMessage(r':::::::::::::::::::::::::::::::::::::::')
    arcpy.AddMessage(r':::::::::::::::::::::::::::::::::::::::')
    #..........................................................................
    
    #--------------------------------------------------------------------------
    #    ^      ^     ^      ^     ^ Split tasks for PCD & BL Raster processing 
    #--------------------------------------------------------------------------
    
    #--------------------------------------------------------------------------
    # Split tasks for LCP Generation:
    #--------------------------------------------------------------------------
    
    arcpy.AddMessage('Splitting tasks for LCP generation, please wait...' )
    
    if(Number_of_Nodes_to_process==1):
        list_task_indices_LCP_Gen=[0]
    elif (Number_of_Nodes_to_process <= number_of_proccessors_to_use):    
        list_task_indices_LCP_Gen = [item for item in range(0, Number_of_Nodes_to_process)]
    else:
        list_task_indices_LCP_Gen = [item for item in range(0, number_of_proccessors_to_use)]
    
    Number_of_tasks_LCP_Gen= len(list_task_indices_LCP_Gen)
    arcpy.AddMessage('Number of tasks (parallel instances) to split LCP Generation: ' + str(Number_of_tasks_LCP_Gen)  )
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('LCP Generation tasks were splitted in ' + str(Number_of_tasks_LCP_Gen) + r' cores ' )
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    
    Iterations_per_task= int(Number_of_Nodes_to_process/Number_of_tasks_LCP_Gen)
    residual_last_core=Number_of_Nodes_to_process % Number_of_tasks_LCP_Gen
    
    # This indices make reference to the list with nodes:
    #..........................................................................   
    Start_index=0
    End_index =len(list_ID_nodes_as_text)-1
    #..........................................................................
    
    list_path_layer_with_all_nodes_LCP_Gen=[]
    
    list_start_indices_tasks_LCP_Gen=[]
    list_end_indices_tasks_LCP_Gen =[]
    
    list_GDBs_locs_LCP_Gen_per_tasks = []
    list_GDBs_locs_Temp_results_LCP_Gen_per_tasks = []
    
    for i in range (0, Number_of_tasks_LCP_Gen):
        
        # Fill the lists with the indices to split the list of nodes:
        #......................................................................
        if(i==0):
            currrent_start_index =  Start_index
        elif(i>0):
            currrent_start_index= list_end_indices_tasks_LCP_Gen[i-1]+1
            
        list_start_indices_tasks_LCP_Gen.append(currrent_start_index)
        
        currrent_end_index = currrent_start_index + Iterations_per_task -1
        list_end_indices_tasks_LCP_Gen.append(currrent_end_index)
        #......................................................................
        
        #  create the Geo-databses to save the results of each task
        arcpy.management.CreateFileGDB(Folder_path_vector_results, "LCPs_gen_task_" + str(i+1), "CURRENT")
        arcpy.management.CreateFileGDB(Folder_path_vector_results, "Temp_LCP_gen_task_" + str(i+1), "CURRENT")
        
        LCPs_GDB_path = os.path.join(Folder_path_vector_results,"LCPs_gen_task_" + str(i+1)+ r'.gdb')
        TEMP_GDB_path = os.path.join(Folder_path_vector_results,"Temp_LCP_gen_task_" + str(i+1)+ r'.gdb')
                
        list_GDBs_locs_LCP_Gen_per_tasks.append(LCPs_GDB_path)
        list_GDBs_locs_Temp_results_LCP_Gen_per_tasks.append(TEMP_GDB_path)
        
        # Make a copy of the input layer with all the nodes in the new Temp GDB
        Temp_copy_nodes_layer = os.path.join(TEMP_GDB_path,r'copy_input_layer_all_nodes_T_' +str(i+1))
        arcpy.CopyFeatures_management(path_layer_with_all_nodes, Temp_copy_nodes_layer)
        list_path_layer_with_all_nodes_LCP_Gen.append(Temp_copy_nodes_layer)
        
    if(residual_last_core>0):
        list_end_indices_tasks_LCP_Gen[Number_of_tasks_LCP_Gen-1]=End_index
        
    # Here you print in console the description of each task:
    #..........................................................................    
    Number_of_nodes_to_process_according_to_task_dsitribution = 0
    for task in list_task_indices_LCP_Gen:
        
        start_i =  list_start_indices_tasks_LCP_Gen[task]
        end_i   =  list_end_indices_tasks_LCP_Gen[task]
        
        number_of_nodes_i = (end_i-start_i) +1
        Number_of_nodes_to_process_according_to_task_dsitribution=Number_of_nodes_to_process_according_to_task_dsitribution+number_of_nodes_i
        arcpy.AddMessage('LCP Generation Task #' + str(task+1) + r': Node: ' + list_ID_nodes_as_text[start_i] + r' to Node: ' + list_ID_nodes_as_text[end_i] + r' :::: ' +  r' Number of nodes = '+ str(number_of_nodes_i))
        
        # Log-file:
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('LCP Generation Task #' + str(task+1) + r': Node: ' + list_ID_nodes_as_text[start_i] + r' to Node:' + list_ID_nodes_as_text[end_i] + r'::::' +  r'Number of nodes = '+ str(number_of_nodes_i))
        #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    if not (Number_of_nodes_to_process_according_to_task_dsitribution == Number_of_Nodes_to_process):
        arcpy.AddMessage(r'ERROR 101: There was a problem distributting the tasks to generate LCPs among the cores, reduce number of processors to use or contact Gabriel Perez Murillo (uqgpere2@uq.edu.au)')
    
    arcpy.AddMessage(r'Total Number of Nodes to process: ' + str(Number_of_nodes_to_process_according_to_task_dsitribution))   
        
    #--------------------------------------------------------------------------
    #    ^      ^     ^      ^     ^     ^       Split tasks for LCP Generation
    #--------------------------------------------------------------------------
    
    
    #&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    #  ^  ^  ^  ^  ^  ^  ^  ^  ^    Create folders and GDBs to save the results
    #&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    # Create PCD and BL rasters:
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    
    list_of_lists_ID_nodes_as_text = []

    for task in list_task_indices_raster_processing:
        
        current_list=list_ID_nodes_as_text[list_start_indices_tasks_RASTER_PROCESSING[task]:(list_end_indices_tasks_RASTER_PROCESSING[task]+1)]
        list_of_lists_ID_nodes_as_text.append(current_list)
    
    arcpy.management.CreateFileGDB(Folder_path_raster_results, r'PCD_and_BL_rasters', "CURRENT")
    PCD_BL_GDB_path = os.path.join(Folder_path_raster_results, r'PCD_and_BL_rasters.gdb')

    list_ID_field_nodes= [ID_field_nodes_layer]*Number_of_tasks_raster_processing
    list_path_file_with_cost_raster = [path_file_with_cost_raster] * Number_of_tasks_raster_processing
    list_path_file_with_DEM = [path_file_with_DEM] *Number_of_tasks_raster_processing
    list_time_before_execution_main = [time_before_execution_main] * Number_of_tasks_raster_processing 
    list_log_file = [location_log_file] *Number_of_tasks_raster_processing 
    
    Inputs_Gen_PCD_BL = return_tuple_inputs_PCD_BL_gen(list_task_indices_raster_processing,             #1
                                                       list_path_layer_with_all_nodes_RASTER_PROCESSING,#2
                                                       list_of_lists_ID_nodes_as_text,                  #3
                                                       list_ID_field_nodes,                             #4
                                                       list_GDBs_locs_TEMP_raster_results_tasks,        #5
                                                       list_path_file_with_cost_raster,                 #6 
                                                       list_path_file_with_DEM,                         #7
                                                       list_GDBs_locs_TEMP_raster_results_tasks,        #8 
                                                       list_time_before_execution_main,                 #9
                                                       list_log_file)                                  #10         
    
    
    elapsed_time = (time.time() - time_before_execution_main)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
      
    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )    
    arcpy.AddMessage(r':::::::::::::::::::::::::::::::::::::::')
    arcpy.AddMessage(r':::::::::::::::::::::::::::::::::::::::')
    
    arcpy.AddMessage(r'Generating PCD and BL rasters ')
    arcpy.AddMessage(r'Running ' + str(Number_of_tasks_raster_processing) + r' tasks in parallel (multi-processing), this may take several minutes please wait....')
    
    # This is the instruction to run all the tasks in parallel according to the
    # number of cores the user defined as an input:
    # || || || || || || || || || || || || || || || || || || || || || || || || ||

    freeze_support()
    with Pool(Number_of_tasks_raster_processing) as pool:
        pool.starmap(Gen_PCD_rasters_and_BL_rasters_selected_nodes, Inputs_Gen_PCD_BL)
    
    # || || || || || || || || || || || || || || || || || || || || || || || || ||
    
    elapsed_time = (time.time() - time_before_execution_main)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage(r'All PCD Rasters generated successfully !!')
    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    
    # Copy all the PCD rasters and BL rasters to the results GDB:
    #..........................................................................
    arcpy.AddMessage(r'Moving all PCD and BL Rasters from temp location to: ' +  PCD_BL_GDB_path)
    
    count_task=0
    for GDB in list_GDBs_locs_TEMP_raster_results_tasks:
        
        # Each GDB respresents a task and has multiple PCD and BL rasters
        # You need a second loop to extract the PCDs for each task:
        current_list_of_nodes = list_of_lists_ID_nodes_as_text[count_task]
           
        for node in current_list_of_nodes:
            
            #Copy the PCD raster:
            PCD_raster = os.path.join(GDB,r'PCD_to_node_' + str(node) )
            Copy_PCD_raster =os.path.join(PCD_BL_GDB_path,r'PCD_to_node_' + str(node) )
            arcpy.management.CopyRaster(PCD_raster, Copy_PCD_raster, '', None, "3.4e+38", "NONE", "NONE", '', "NONE", "NONE", "GRID", "NONE", "CURRENT_SLICE", "NO_TRANSPOSE")    
            
            # Copy the BL raster:
            BL_raster =os.path.join(GDB,r'Backlink_to_node_' + str(node) )
            Copy_BL_raster=os.path.join(PCD_BL_GDB_path,r'Backlink_to_node_' + str(node) )
            arcpy.management.CopyRaster(BL_raster, Copy_BL_raster, '', None, "3.4e+38", "NONE", "NONE", '', "NONE", "NONE", "GRID", "NONE", "CURRENT_SLICE", "NO_TRANSPOSE")    
            arcpy.AddMessage(r'Rasters for node ' +  str(node) + r' copied sucessfully !')
        
        count_task = count_task+1
    #..........................................................................
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('........................................................................................')
        log_file.write('\n')
        log_file.write('All PCD Rasters and BL Rasters were created Sucessfully at: '+ str( Current_date) + r' ' + str(Current_time))
        log_file.write('\n')
        log_file.write('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
        log_file.write('\n')
        log_file.write('........................................................................................')
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    #     ^     ^     ^     ^     ^     ^     ^     ^     ^     ^     ^     ^
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp

    
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    # Generate the LCP layers
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    
    list_of_lists_ID_nodes_as_text = []

    for task in list_task_indices_LCP_Gen:
        
        current_list=list_ID_nodes_as_text[list_start_indices_tasks_LCP_Gen[task]:(list_end_indices_tasks_LCP_Gen[task]+1)]
        list_of_lists_ID_nodes_as_text.append(current_list)
    
    
    list_ID_field_nodes= [ID_field_nodes_layer]*Number_of_tasks_LCP_Gen
    list_GDB_raster_results = [PCD_BL_GDB_path] * Number_of_tasks_LCP_Gen
    list_time_before_execution_main = [time_before_execution_main] * Number_of_tasks_LCP_Gen 
    list_log_file = [location_log_file] *Number_of_tasks_LCP_Gen 
    
    Inputs_Gen_LCPs = return_tuple_inputs_LCPs_gen(list_task_indices_LCP_Gen,                     #1
                                                   list_path_layer_with_all_nodes_LCP_Gen,        #2
                                                   list_ID_field_nodes,                           #3  
                                                   list_of_lists_ID_nodes_as_text,                #4
                                                   list_GDB_raster_results,                       #5
                                                   list_GDBs_locs_LCP_Gen_per_tasks,              #6
                                                   list_GDBs_locs_Temp_results_LCP_Gen_per_tasks, #7
                                                   list_time_before_execution_main,               #8
                                                   list_log_file)                                 #9 
    
    
    elapsed_time = (time.time() - time_before_execution_main)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
      
    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )    
    arcpy.AddMessage('Generating LCPs, this may take several minutes please wait....')
    
    # This is the instruction to generate the LCPs in parallel:
    # || || || || || || || || || || || || || || || || || || || || || || || || ||

    with Pool(Number_of_tasks_LCP_Gen) as pool:
        pool.starmap(Gen_LCPs_selected_nodes, Inputs_Gen_LCPs)
    
    # || || || || || || || || || || || || || || || || || || || || || || || || ||
    
    elapsed_time = (time.time() - time_before_execution_main)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage(r'All LCPs were generated successfully at  '+ str( Current_date) + r' ' + str(Current_time))
    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write('........................................................................................')
        log_file.write('\n')
        log_file.write('All LCPs were generated successfully at:' + str( Current_date) + r' ' + str(Current_time) )
        log_file.write('\n')
        log_file.write('........................................................................................')
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    #     ^     ^     ^     ^     ^     ^     ^         Generate the LCP layers
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    
    # Create Geodtabases to save the LCP results in each direction:
    #.......................................................................... 
    arcpy.management.CreateFileGDB(Folder_path_vector_results, "LCPs_one_way", "CURRENT")
    path_GDB_LCPs_one_Way = os.path.join(Folder_path_vector_results,r'LCPs_one_way.gdb') 
    
    arcpy.management.CreateFileGDB(Folder_path_vector_results, "LCPs_return", "CURRENT")
    path_GDB_LCPs_return = os.path.join(Folder_path_vector_results,r'LCPs_return.gdb') 
    #..........................................................................
    
    # Merge all the LCPs going in one way
    #..........................................................................
    list_file_paths_layers_to_merge_LCPs_one_ways=[]
    count_task=0
    for GDB in list_GDBs_locs_LCP_Gen_per_tasks:
        
        # Each GDB respresents a taskof the Gen LCPs process and has multiple layers with LCPs
        # You need a second loop to extract the nodes for each task:
        current_list_of_nodes = list_of_lists_ID_nodes_as_text[count_task]
           
        for node in current_list_of_nodes:
            
            LCP_layer_one_way = os.path.join(GDB,r'LCPs_node_' + str(node))
            list_file_paths_layers_to_merge_LCPs_one_ways.append(LCP_layer_one_way)
            
        count_task = count_task+1

    layer_results_one_way= os.path.join(path_GDB_LCPs_one_Way, r'LCPs_one_ways')
    Field_to_identify_rows= r'PathDes'
    Location_Temp_results= list_GDBs_locs_Temp_results_LCP_Gen_per_tasks[0] # Random temp location
    merge_list_of_layers(list_file_paths_layers_to_merge_LCPs_one_ways,Field_to_identify_rows,Location_Temp_results,layer_results_one_way)
    
    # Delete repeated rows:
    #..........................................................................
    seen_rows = set()
    Number_of_rows_deleted = 0
    
    with arcpy.da.UpdateCursor(layer_results_one_way, Field_to_identify_rows) as cursor:
        
        for row in cursor:
          
          current_LCP = row[0]
          
          if current_LCP in seen_rows:
              cursor.deleteRow()
              Number_of_rows_deleted= Number_of_rows_deleted + 1
          
          seen_rows.add(current_LCP)
    arcpy.AddMessage(r'Number of repeated rows: ' + Number_of_rows_deleted)
    #..........................................................................    
    
    
    #  Merge the LCPs return:
    #..........................................................................
    list_file_paths_layers_to_merge_return =[]
    
    count_task=0
    for GDB in list_GDBs_locs_LCP_Gen_per_tasks:
        
        # Each GDB respresents a task of the Gen LCPs process and has multiple layers with LCPs
        # You need a second loop to extract the nodes for each task:
        current_list_of_nodes = list_of_lists_ID_nodes_as_text[count_task]
           
        for node in current_list_of_nodes:
            
            LCP_layer_return = os.path.join(GDB,r'LCPs_node_' + str(node) + r'_return')
            list_file_paths_layers_to_merge_return.append(LCP_layer_return)
            
        count_task = count_task+1

    layer_results_return= os.path.join(path_GDB_LCPs_return, r'LCPs_return')
    Field_to_identify_rows= r'PathDes'
    
    Location_Temp_results= list_GDBs_locs_Temp_results_LCP_Gen_per_tasks[0] # Random temp location

    # Delete Temp layers from previous merge operation:
    arcpy.management.Delete(os.path.join(Location_Temp_results, r'merged_layers') )
    arcpy.management.Delete(os.path.join(Location_Temp_results, r'New_merged_layers'))

    merge_list_of_layers(list_file_paths_layers_to_merge_return,Field_to_identify_rows,Location_Temp_results,layer_results_return)
    #..........................................................................
    
    # Delete repeated rows:
    #..........................................................................
    seen_rows = set()
    Number_of_rows_deleted = 0
    
    with arcpy.da.UpdateCursor(layer_results_return, Field_to_identify_rows) as cursor:
        
        for row in cursor:
          
          current_LCP = row[0]
          
          if current_LCP in seen_rows:
              cursor.deleteRow()
              Number_of_rows_deleted= Number_of_rows_deleted + 1
          
          seen_rows.add(current_LCP)
    arcpy.AddMessage(r'Number of repeated rows: ' + Number_of_rows_deleted)
    #..........................................................................    
    
    
    # Merge all LCPs:
    #...........................................................................
    layer_all_LCPs= os.path.join(path_GDB_results, r'All_LCPs')
    arcpy.management.Merge([layer_results_one_way,layer_results_return],layer_all_LCPs)
    #...........................................................................
    
    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    Current_date_time = str(datetime.datetime.now())
    Current_date = Current_date_time.split()[0]
    Current_time = Current_date_time.split()[1]
    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write(r'All LCPs in one way merged at:' + str(Current_date) + r' '+ str(Current_time) + r' | ' + layer_results_one_way)
        log_file.write('\n')
        log_file.write(r'All LCPs return  merged at:' + str(Current_date) + r' '+ str(Current_time) + r' | ' + layer_results_return)
        log_file.write('\n')
        log_file.write('ELapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds'  )
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
    #--------------------------------------------------------------------------
    # Split tasks for LCP processing:
    #--------------------------------------------------------------------------
    
    arcpy.AddMessage('Splitting tasks for LCP processing, please wait...' )
    
    list_task_indices_LCP_Processing = [item for item in range(0, number_of_proccessors_to_use)]
    
    Number_of_tasks_LCP_Processing= len(list_task_indices_LCP_Processing)
    arcpy.AddMessage('Number of tasks (parallel instances) to split LCP processing: ' + str(Number_of_tasks_LCP_Processing)  )
    
    # Count the number of LCP layers you want to process in each direction:
    #..........................................................................    
    OIDField_LCPs_to_process = arcpy.Describe(layer_results_one_way).OIDFieldName

    NP_Array_LCPs_to_process =  arcpy.da.FeatureClassToNumPyArray (layer_results_one_way,[OIDField_LCPs_to_process],skip_nulls=False,null_value=-99999)
    df_LCPs_to_process = pd.DataFrame(NP_Array_LCPs_to_process, columns = [OIDField_LCPs_to_process])
    List_of_LCP_number_IDs  = df_LCPs_to_process[OIDField_LCPs_to_process].tolist()

    Number_of_LCPs_to_process_in_each_direction= len(List_of_LCP_number_IDs)
    #..........................................................................
    
    list_start_indices= []
    list_end_indices =[]
    
    list_GDBs_locs_Temp_results_LCP_processing = []
    list_GDBs_loc_Stack_Profiles = []
    
    Start_index= 0   
    End_index= Number_of_LCPs_to_process_in_each_direction
    
    Iterations_to_run_each_way  = Number_of_LCPs_to_process_in_each_direction
    Number_of_iterations_per_Core= int(Iterations_to_run_each_way/number_of_proccessors_to_use)
    residual_last_core=Iterations_to_run_each_way % number_of_proccessors_to_use
    
    for i in range (0, Number_of_tasks_LCP_Processing):
        
        if(i==0):
            currrent_start_index =  Start_index
        elif(i>0):
            currrent_start_index= list_end_indices[i-1]+1
            
        list_start_indices.append(currrent_start_index)
        
        currrent_end_index = currrent_start_index + Number_of_iterations_per_Core -1
        list_end_indices.append(currrent_end_index)
        
        # create the Geo-databases to save the results of each task
        #......................................................................
            
        temp_GDB_name = r'Temp_LCP_processing_task_' + str (i+1) + r'.gdb'
        temp_GDB_path = os.path.join(Folder_path_vector_results,temp_GDB_name)
        temp_GDB_name_no_extension= r'Temp_LCP_processing_task_' + str (i+1)
        if not os.path.exists(temp_GDB_path):
            print(r' Filepath TEMP resutls does not exsits')
            arcpy.management.CreateFileGDB(Folder_path_vector_results, temp_GDB_name_no_extension, "CURRENT")
        
        stack_profile_GDB_name = r'Stack_profiles_task_' + str (i+1) + r'.gdb'
        stack_profile_GDB_name_no_extension =r'Stack_profiles_task_' + str (i+1)
        StackProfile_GDB_path = os.path.join(Folder_path_vector_results,stack_profile_GDB_name)
        if not os.path.exists(StackProfile_GDB_path):
            print(r' Filepath StackProfiles does not exsits')
            arcpy.management.CreateFileGDB(Folder_path_vector_results, stack_profile_GDB_name_no_extension, "CURRENT")
        #......................................................................
        
        list_GDBs_locs_Temp_results_LCP_processing.append(temp_GDB_path)
        list_GDBs_loc_Stack_Profiles.append(StackProfile_GDB_path)
        
    # Here you make sure you process all the rows     
    list_end_indices[Number_of_tasks_LCP_Processing-1]= End_index
    
    
    # save log :
    #..........................................................................    
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write(r'::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::')
        log_file.write('\n')
        log_file.write(r'::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::')
        log_file.write('\n')
        log_file.write(r'Description of tasks for LCP processing (each way):')
        log_file.write('\n')
        log_file.write(r'::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::')
        log_file.write('\n')
        log_file.write(r'::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::')
    #..........................................................................
    
    
    # Here you print in console the description of each task:
    #..........................................................................    
    
    Total_number_of_LCPs=0    
    for task in list_task_indices_LCP_Processing:
        
        start_i =  list_start_indices[task]
        end_i   =  list_end_indices[task]
        
        number_of_LCPs_i =end_i-start_i +1
        Total_number_of_LCPs=Total_number_of_LCPs+number_of_LCPs_i
        arcpy.AddMessage('Task #' + str(task+1) + r': row index from ' + str(start_i) + r' to ' + str(end_i) + r':::' + 'Number of LCPs = '+ str(number_of_LCPs_i))
        
        # save log:
        #......................................................................
        with open(location_log_file, 'a') as log_file:
            log_file.write('\n')
            log_file.write('Task #' + str(task+1) + r': row index from ' + str(start_i) + r' to ' + str(end_i) + r':::' +  r'Number of LCPs = '+ str(number_of_LCPs_i))
        #......................................................................
    #..........................................................................
    
    
    # save log :
    #.......................................................................... 
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write(r'::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::')
        log_file.write('\n')
        log_file.write(r'::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::')
    #..........................................................................
    #--------------------------------------------------------------------------
    #    ^      ^     ^      ^     ^     ^       Split tasks for LCP processing
    #--------------------------------------------------------------------------    
    
    
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    # LCP Processing (one way)
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    
    
    # Create the lists of inputs for each call of the  process_selected_rows_of_LCPs_layer_no_excel() function:
    #..........................................................................    
    list_type_of_LCPs= ['one_way']*Number_of_tasks_LCP_Processing  # 'return'
    list_path_layer_with_LCPs =[layer_results_one_way]*Number_of_tasks_LCP_Processing
    list_path_layer_with_all_nodes=[path_layer_with_all_nodes]*Number_of_tasks_LCP_Processing
    list_path_file_with_DEM = [path_file_with_DEM] *Number_of_tasks_LCP_Processing
    list_path_file_with_Environmental_restriction= [path_file_with_Environmental_restriction]*Number_of_tasks_LCP_Processing
    list_ID_field_nodes= [ID_field_nodes_layer]*Number_of_tasks_LCP_Processing
    list_time_before_execution_main = [time_before_execution_main] * Number_of_tasks_LCP_Processing 
    list_log_file = [location_log_file] *Number_of_tasks_LCP_Processing 
    #..........................................................................
    
    Inputs_LCPs_one_way_processing = return_tuple_inputs_Process_LCPs_no_excel(list_type_of_LCPs,                             # p1
                                                                               list_task_indices_LCP_Processing,              # p2
                                                                               list_start_indices,                            # p3
                                                                               list_end_indices,                              # p4
                                                                               list_path_layer_with_LCPs,                     # p5
                                                                               list_path_layer_with_all_nodes,                # p6
                                                                               list_path_file_with_DEM,                       # p7
                                                                               list_path_file_with_Environmental_restriction ,# p8
                                                                               list_ID_field_nodes,                           # p9
                                                                               list_GDBs_locs_Temp_results_LCP_processing,    # p10
                                                                               list_GDBs_loc_Stack_Profiles,                  # p11
                                                                               list_time_before_execution_main,               # p12
                                                                               list_log_file)                                 # p13
              

    # This is the instruction to generate the LCPs in parallel:
    # || || || || || || || || || || || || || || || || || || || || || || || || ||
    
    arcpy.AddMessage(r'Processing LCPs (one way), please wait...' )

    with Pool(Number_of_tasks_LCP_Processing) as pool:
        pool.starmap(process_selected_rows_of_LCPs_layer_no_excel,Inputs_LCPs_one_way_processing )
    
    # || || || || || || || || || || || || || || || || || || || || || || || || ||
    
    # Merge results of each task:
    #..........................................................................
    list_LCP_layer_to_merge_one_way=[]
    count_task=0
    
    for GDB in list_GDBs_locs_Temp_results_LCP_processing:
        
        LCP_one_way = os.path.join(GDB, r'LCPs_with_attributes_one_way_task_' + str(count_task+1))        
        list_LCP_layer_to_merge_one_way.append(LCP_one_way)
        count_task = count_task +1

    layer_results_one_way= os.path.join(path_GDB_LCPs_one_Way, r'All_LCPs_with_attributes_one_way')
    arcpy.management.Merge(list_LCP_layer_to_merge_one_way,layer_results_one_way)
    
    arcpy.AddMessage(r'All LCPs with attributes (one way) were merged into this layer: ' +  layer_results_one_way)
    
    #..........................................................................
    
    # mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    #      ^     ^     ^     ^     ^     ^     ^       LCP Processing (one way)
    # mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    
    
    # mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    # Process all the the LCP return
    # mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    
    list_type_of_LCPs= ['return']*Number_of_tasks_LCP_Processing  
    list_path_layer_with_LCPs =[layer_results_return]*Number_of_tasks_LCP_Processing
     
    
    Inputs_LCPs_return_processing = return_tuple_inputs_Process_LCPs_no_excel(list_type_of_LCPs,                             # p1
                                                                              list_task_indices_LCP_Processing,              # p2
                                                                              list_start_indices,                            # p3
                                                                              list_end_indices,                              # p4
                                                                              list_path_layer_with_LCPs,                     # p5
                                                                              list_path_layer_with_all_nodes,                # p6
                                                                              list_path_file_with_DEM,                       # p7
                                                                              list_path_file_with_Environmental_restriction ,# p8
                                                                              list_ID_field_nodes,                           # p9
                                                                              list_GDBs_locs_Temp_results_LCP_processing,    # p10
                                                                              list_GDBs_loc_Stack_Profiles,                  # p11
                                                                              list_time_before_execution_main,               # p12
                                                                              list_log_file)                                 # p13
    
    # This is the instruction to generate the LCPs in parallel:
    # || || || || || || || || || || || || || || || || || || || || || || || || ||
    
    arcpy.AddMessage(r'Processing return LCPs, please wait...' )

    with Pool(Number_of_tasks_LCP_Processing) as pool:
        pool.starmap(process_selected_rows_of_LCPs_layer_no_excel,Inputs_LCPs_return_processing )
    
    # || || || || || || || || || || || || || || || || || || || || || || || || ||
    
    # Merge results of each task:
    #..........................................................................
    list_LCP_layer_to_merge_return=[]
    count_task=0
    
    for GDB in list_GDBs_locs_Temp_results_LCP_processing:
        
        LCP_return  = os.path.join(GDB, r'LCPs_with_attributes_return_task_'  + str(count_task+1))
        
        list_LCP_layer_to_merge_return.append(LCP_return)
        count_task = count_task +1
    
    layer_results_return= os.path.join(path_GDB_LCPs_return, r'All_LCPs_with_attributes_return')
    arcpy.management.Merge(list_LCP_layer_to_merge_return,layer_results_return)
    
    arcpy.AddMessage(r'All LCPs with attributes ( return ) were merged into this layer: ' +  layer_results_return)

    #..........................................................................
    
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    #     ^     ^     ^     ^     ^     ^     ^  Process all the the LCP return
    #mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp-mp
    
    arcpy.AddMessage(r'Merging all LCPs, please wait...' )
    
    # Merge the processed LCP layers:
    #..........................................................................

    layer_results= os.path.join(path_GDB_results, r'All_LCPs_with_attributes')
    arcpy.management.Merge([layer_results_one_way,layer_results_return],layer_results)

    #..........................................................................
    
    arcpy.AddMessage(r'All LCPs with attributes merged in this layer: ' + layer_results )
    
    
    # Delete all the TEMP folders and GDBs that are not neccesary 
    # (delete the intermediate results):
    #..........................................................................
    
    for TEMP_location in list_GDBs_locs_TEMP_raster_results_tasks:
        
        try:
            shutil.rmtree(TEMP_location)
            arcpy.AddMessage(r' Folder : ' + TEMP_location  + ' was deleted')
        except ValueError:
            warnings.warn( r' Folder : ' + TEMP_location  + r'could not be deleted !')
            pass
    
    
    for TEMP_location in list_GDBs_locs_Temp_results_LCP_Gen_per_tasks:
        
        try:
            shutil.rmtree(TEMP_location)
            arcpy.AddMessage(r' Folder : ' + TEMP_location  + ' was deleted')
        except ValueError:
            warnings.warn( r' Folder : ' + TEMP_location  + r'could not be deleted !')
            pass
    
    for TEMP_location in list_GDBs_locs_LCP_Gen_per_tasks:
        
        try:
            shutil.rmtree(TEMP_location)
            arcpy.AddMessage(r' Folder : ' + TEMP_location  + ' was deleted')
        except ValueError:
            warnings.warn( r' Folder : ' + TEMP_location  + r'could not be deleted !')
            pass
    
    for TEMP_location in list_GDBs_locs_Temp_results_LCP_processing:
        
        try:
            shutil.rmtree(TEMP_location)
            arcpy.AddMessage(r' Folder : ' + TEMP_location  + ' was deleted')
        except ValueError:
            warnings.warn( r' Folder : ' + TEMP_location  + r'could not be deleted !')
            pass
    

    for TEMP_location in list_GDBs_loc_Stack_Profiles:
        
        try:
            shutil.rmtree(TEMP_location)
            arcpy.AddMessage(r' Folder : ' + TEMP_location  + ' was deleted')
        except ValueError:
            warnings.warn( r' Folder : ' + TEMP_location  + r'could not be deleted !')
            pass
        
    #..........................................................................
    
    elapsed_time = (time.time() - time_before_execution_main)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )

    # Log-file:
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    with open(location_log_file, 'a') as log_file:
        log_file.write('\n')
        log_file.write(' All LCPs merged into file: ' + layer_results) 
        log_file.write('\n')
        log_file.write('........................................................................................')
        log_file.write('\n')
        log_file.write('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
        log_file.write('\n')
        log_file.write('........................................................................................')
    #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    arcpy.AddMessage(r' You can click "Quit" now !')

#..............................................................................
#                                                                          Main
#..............................................................................

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Creation of functions
###############################################################################

###############################################################################
#                                          Definition of functions to build GUI
###############################################################################

#..............................................................................
def End_program(root):
    root.destroy
#..............................................................................
  
def fetch(entries):
    for entry in entries:
        field = entry[0]
        text  = entry[1].get()
        print('%s: "%s"' % (field, text)) 
#..............................................................................
   
def print_parameters(parameters):
    for parameter in parameters:
        print(parameter)

#..............................................................................

def makeGUI(root, fields):
    entries = []
    entry_num=0
    for field in fields:
        row = tk.Frame(root)
        
        lab = tk.Label(row, width=90, text=field, anchor='w')
        ent = tk.Entry(row, width=110)
        ent.insert(tk.END, default_values[entry_num])
        entry_num=entry_num+1
        
        row.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        lab.pack(side=tk.LEFT)
        ent.pack(side=tk.RIGHT, expand=tk.YES, fill=tk.X)
        entries.append((field, ent))
    return entries
#..............................................................................
    
def Run(root,entries):
    
    #Create a dictionary with inputs introduced by the user:
    parameters ={}
        
    for entry in entries:
        field = entry[0]
        text  = entry[1].get()
        parameters.update({field: text})
        print('%s: "%s"' % (field, text)) 
    
    # Get Parameters introduce by user     
    p1  = parameters[description_p1]
    p2  = parameters[description_p2]
    p3  = parameters[description_p3]
    p4  = parameters[description_p4]
    p5  = parameters[description_p5]
    p6  = parameters[description_p6]
    p7  = parameters[description_p7]
    p8  = parameters[description_p8]
    p9  = parameters[description_p9]
    
    # This is the call to the main fucntion that does the Spatial Optimisation
    main(p1,p2,p3,p4,p5,p6,p7,p8,p9)
    
    root.destroy

#..............................................................................

#..............................................................................
class App(tk.Tk):
    
    def __init__(self):
        super().__init__()
        self.title('Run Spatial Optimisation for selected nodes (V4.0)')
        
        # define the labels as tuple to keep the order    
        Interface_labels = (description_p1,
                            description_p2,
                            description_p3,
                            description_p4,
                            description_p5,
                            description_p6,
                            description_p7,
                            description_p8,
                            description_p9)
        
        entries = makeGUI(self, Interface_labels)
        #get the entry values:
        self.bind('<Return>', (lambda event, e=entries: fetch(e)))   

        b1 = tk.Button(self, text='Run', command=(lambda e=entries: Run(self,e)))
        b1.pack(side=tk.LEFT, padx=5, pady=5)

        b2 = tk.Button(self, text='Quit', command=self.destroy)
        b2.pack(side=tk.LEFT, padx=5, pady=5)
#..............................................................................

###############################################################################
#   ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   End of fucntions to build GUI
###############################################################################
 
###############################################################################
#                                                                   Strart  GUI
###############################################################################
if __name__ == "__main__":
    app = App()
    app.mainloop()
###############################################################################
#%% ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^     End  GUI
###############################################################################