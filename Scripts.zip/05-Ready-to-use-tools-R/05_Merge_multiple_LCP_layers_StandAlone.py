# -*- coding: utf-8 -*-
"""
Created on Tue Aug  2 17:40:31 2022

@author: uqgpere2
"""
###############################################################################
#%%                                                    PACKAGES YOU NEED TO LOAD
###############################################################################

import os
import sys
import time
import math
import collections


import openpyxl
from openpyxl import load_workbook, Workbook

import pandas as pd
import arcpy
from arcpy.sa import *
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^   END OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

description_p1  = r'List of LCP layers to merge:'
description_p2  = r'Field to identify the LCPs (no quotation marks):'
description_p3  = r'Location to save TEMP results'
description_p4  = r'Location to save results'
description_p5  = r'Name of result layer (No extension required):'

p1  = [r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\Res_NODES_1_to_10_Scenario_41_nodes\Results_nodes_1_to_10.gdb\LCPs_node_1_to_10',
       r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\Res_NODES_11_to_20_Scenario_41_nodes\Results_nodes_11_to_20.gdb\LCPs_node_11_to_20',
       r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\Res_NODES_21_to_30_Scenario_41_nodes\Results._nodes_21_to_30.gdb\LCPs_node_21_to_30',
       r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\Res_NODES_31_to_41_Scenario_41_nodes\Results_nodes_31_to_41.gdb\LCPs_node_31_to_41']
p2 = r'PathDes'
p3 = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Temp.gdb'
p4 = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\Scenario_41_nodes.gdb'
p5 = r'LCPs_41_nodes'

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   List of inputs
###############################################################################


###############################################################################
#                                                          Definition of Main() 
###############################################################################    

#..............................................................................

def merge_2_layers(Layer_1,Layer_2,Field_to_identify_rows,Location_Temp_results,Result_layer):
    
    # Get the list of IDs Layer 1:
    #..............................................................................
    List_of_field_names = [f.name for f in arcpy.ListFields(Layer_1)]    
    List_of_field_names.remove('Shape')
        
    NP_Array_L1 =  arcpy.da.FeatureClassToNumPyArray (Layer_1,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_L1= pd.DataFrame(NP_Array_L1, columns = List_of_field_names)

    list_IDs_L1 = df_L1[Field_to_identify_rows].tolist()

    # Get the list of IDs Layer 2:
    #..............................................................................

    List_of_field_names = [f.name for f in arcpy.ListFields(Layer_2)]    
    List_of_field_names.remove('Shape')

    NP_Array_L2 =  arcpy.da.FeatureClassToNumPyArray (Layer_2,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_L2 = pd.DataFrame(NP_Array_L2, columns = List_of_field_names)

    list_IDs_L2 = df_L2[Field_to_identify_rows].tolist()

    # make a copy of L1:
    Temp_copy = os.path.join(Location_Temp_results, r'temp_copy_LCPs')    
    arcpy.CopyFeatures_management(Layer_1, Temp_copy)
     
    # Delete the rows that are repeated:
    list_Ids_repeated = list(set(list_IDs_L1) & set(list_IDs_L2))
    
    if (len(list_Ids_repeated)>0):    
    
        with arcpy.da.UpdateCursor(Temp_copy, [Field_to_identify_rows]) as cursor:
          for row in cursor:
              current_LCP = row[0]
              if current_LCP in list_Ids_repeated:
                  arcpy.AddMessage( r'Row deleted: ' + current_LCP)
                  cursor.deleteRow()

    # Merge the New LCPs to the copy:
    arcpy.management.Merge([Temp_copy,Layer_2],Result_layer)
    arcpy.AddMessage( r'Layer  : ' + str(Layer_1) + r' merged to: ' + str(Layer_2)+ r' !!')

#..............................................................................

# Merge list of layers:
#..............................................................................

def merge_list_of_layers(list_layers_to_merge,Field_to_identify_rows,location_to_save_temp_layers,Result_layer):

    if (len(list_layers_to_merge)>1):
        
        # Merge the first two layers 
        Merge = os.path.join(location_to_save_temp_layers, r'merged_layers') 
        
        loc_first_layer  = list_layers_to_merge[0] 
        loc_second_layer = list_layers_to_merge[1]   
          
        merge_2_layers(loc_first_layer,loc_second_layer,Field_to_identify_rows,location_to_save_temp_layers,Merge)
        
        # Delete the first two layers from the list of layers to merge
        list_layers_to_merge.pop(0)
        list_layers_to_merge.pop(0)
    
        if (len(list_layers_to_merge)>0):
            
            for Path_layer in list_layers_to_merge:
                
                New_Merge = os.path.join(location_to_save_temp_layers, r'New_merged_layers') 
            
                merge_2_layers(Merge,Path_layer,Field_to_identify_rows,location_to_save_temp_layers,New_Merge)
                
                arcpy.management.Delete(Merge)
                arcpy.CopyFeatures_management(New_Merge, Merge)
                arcpy.management.Delete(New_Merge)
                
                arcpy.AddMessage( r'Layer merged successfully : ' + str(Path_layer) + r' !!')
            
        arcpy.CopyFeatures_management(Merge, Result_layer)
        
    else:
        loc_first_layer = list_layers_to_merge[0]
        arcpy.CopyFeatures_management(loc_first_layer, Result_layer)
    
    arcpy.AddMessage(r'All layers merged succesfully !!')

#..............................................................................   
   
#%%

#..............................................................................

def main(p1,p2,p3,p4,p5):
    #%%
    time_before_execution = time.time()
    
    print(r'p1 =' + str(p1))
    print(r'p2 =' + str(p2))
    print(r'p3 =' + str(p3))
    print(r'p4 =' + str(p4))
    print(r'p5 =' + str(p5))
    
    # Define function global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    list_layers_to_merge   = p1
    Field_to_identify_rows = p2    
    GDB_Temp_results       = p3
    layer_with_results     = os.path.join(p4,p5)
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    
    # Clean the temporal GDB before starting:
    #..........................................................................
    arcpy.AddMessage(r'Cleaning Temp GDB, pelase wait... ')

    arcpy.env.workspace = GDB_Temp_results

    fc_list = arcpy.ListFeatureClasses()
    tables = arcpy.ListTables()
    ds_list = arcpy.ListDatasets()
    rasters_list = arcpy.ListRasters("*", "GRID")    

    #feature classes
    for fc in fc_list:
        arcpy.Delete_management(fc)
    
    #tables
    for table in tables:
        arcpy.Delete_management(table)
    
    #data sets
    for ds in ds_list:
        arcpy.Delete_management(ds)
    
    #rasters:
    for raster in rasters_list:
        arcpy.Delete_management(raster)    
    arcpy.AddMessage(r'GDB, cleaned succesfully !!')
    #..........................................................................
    
    # Here you merge all the layers:
    
    merge_list_of_layers(list_layers_to_merge,Field_to_identify_rows,GDB_Temp_results,layer_with_results)
    
    # Here you delete any rows that are repeated:
    #..........................................................................
    List_of_field_names_LCPs = [f.name for f in arcpy.ListFields(layer_with_results)]    
    List_of_field_names_LCPs.remove('Shape')
    
    OIDField_LCPs = arcpy.Describe(layer_with_results).OIDFieldName

    NP_Array_LCPs=  arcpy.da.FeatureClassToNumPyArray (layer_with_results,List_of_field_names_LCPs,skip_nulls=False,null_value=-99999)
    df_LCPs = pd.DataFrame(NP_Array_LCPs, columns = List_of_field_names_LCPs)

    list_of_LCPs_unique_IDs = df_LCPs[Field_to_identify_rows].tolist()
    
    seen_rows = set()
    Number_of_rows_deleted = 0
    
    with arcpy.da.UpdateCursor(layer_with_results, Field_to_identify_rows) as cursor:
        
        for row in cursor:
          
          current_LCP = row[0]
          
          if current_LCP in seen_rows:
              cursor.deleteRow()
              
              Number_of_rows_deleted= Number_of_rows_deleted + 1
              arcpy.AddMessage( r'Row ' + str(Number_of_rows_deleted) +  ' deleted')
              elapsed_time = (time.time() - time_before_execution)
              Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
              Fraction_of_hours, hours =math.modf(Seconds/3600)
              arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
          seen_rows.add(current_LCP)
    #..........................................................................
      
###############################################################################
#                                                                         Start
###############################################################################

if __name__ == "__main__":
    main(p1,p2,p3,p4,p5)
    print("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################