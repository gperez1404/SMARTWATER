# -*- coding: utf-8 -*-
"""
Created on Mon Jul 4 11:47:59 2022

This script uses an excel file to update the Q values of a nodes layer 

These are the field names required in the input nodes layer:
    
    'ID_CONN'
    'Q_m3s'
           
WARNING 1: only nodes and Q values listed in the excel file will be updated. 
           All the nodes or Q values NOT listed in the input excel file WILL NOT be updated 

WARNING 2: the field names introduced in the GUI should coincide with the column
           names of the excel file. However, these excel names can be different 
           form the names of input nodes layer. 
           

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
# %%                                                    PACKAGES YOU NEED TO LOAD
###############################################################################

import os
import sys
import time
import math

import openpyxl
from openpyxl import load_workbook, Workbook

import pandas as pd
import arcpy
from arcpy.sa import *
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^    EMD OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

description_p1 = r'Location of input layer with nodes (layer to be updated)'
description_p2 = r'Location of excel file to load new nodes attributes:'
description_p3 = r'Name of the excel Sheet with the new attributes:'
description_p4 = r'Name of the excel column with the IDs values (ID_CONN in the nodes layer | No quotation marks):'
description_p5 = r'Name of the excel column with the Q values (Q_m3s in the nodes layer | No quotation marks):'
description_p6 = r'Location to save new Layer with updated Q values attributes'
description_p7 = r'Name of the new layer with updated nodes'

list_p_descriptions = [description_p1,description_p2,description_p3,
                       description_p4,description_p5,description_p6,
                       description_p7]

list_of_keys =['p1','p2','p3','p4','p5','p6','p7']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                       Definition of fucntions 
###############################################################################    

#..............................................................................

def main_function(p1,p2,p3,p4,p5,p6,p7):
    
    
    time_before_execution = time.time()
    
    # Define global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Nodes_layer                    = p1
    Excel_file_with_new_attributes = p2
    Excel_sheet_name               = p3
    ID_CONN                        = [p4]
    Q_m3s                          = [p5]
    location_to_save_results       = p6
    name_results_layer             = p7
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # load the layer with nodes
    #--------------------------------------------------------------------------
    List_of_field_names_Nodes_layer = [f.name for f in arcpy.ListFields(Nodes_layer)]    
    List_of_field_names_Nodes_layer.remove('Shape')   
    List_of_field_names_Nodes_layer.remove('OBJECTID') 
    
    NP_Array_nodes_attribute_table =  arcpy.da.FeatureClassToNumPyArray (Nodes_layer,List_of_field_names_Nodes_layer,skip_nulls=False,null_value=-99999)
    df_input_Nodes = pd.DataFrame(NP_Array_nodes_attribute_table, columns = List_of_field_names_Nodes_layer)  
    
    list_of_Required_Field_Names  =  ['ID_CONN', 'Q_m3s']
    
    difference_in_attributes =    list(set(List_of_field_names_Nodes_layer).difference(list_of_Required_Field_Names))
    
    missing_attributes =[]
    
    for attribute_name in difference_in_attributes:
        if (attribute_name in list_of_Required_Field_Names):
            missing_attributes.append(attribute_name)

    
    if  (len(missing_attributes)> 0):
        arcpy.AddMessage( r'The field(s) {} are missing in the input nodes layer'.format(missing_attributes) ) 
        sys.exit() 
    
    
    #-------------------------------------------------------------------------- 
     
    # Load excel sheet as data-frame object:
    #..........................................................................
    try:
        df_excel_file = pd.read_excel(Excel_file_with_new_attributes, sheet_name=Excel_sheet_name)
    except ValueError:
        arcpy.AddMessage( r'Attempted file path: '  + Excel_file_with_new_attributes)
        arcpy.AddMessage( r'attempted Sheet name:'  + Excel_sheet_name)
        arcpy.AddMessage( r"Oops! ")
        arcpy.AddMessage( r'ERROR 101: you have introduced the wrong file location or the wrong Sheet name,  Try again...')
    #..........................................................................        
    
    
    # Verify that the names introduced in the GUI coincide with the excel file:
    #..........................................................................
    
    # Get the list of column names in the excel file:
    list_of_columns_names_excel_file = df_excel_file.columns.tolist()    
    
    # Get the list of Field names introduced in the GUI
    list_of_columns_names_introduced_in_GUI  =   ID_CONN + Q_m3s
    
    # Create a dictionary with the relation between excel names and layer names 
    dic_fields_for_translation = dict(zip(list_of_Required_Field_Names,list_of_columns_names_introduced_in_GUI)) 
    
    # Get the list of fields that won't be updated ('' or '-')
    
    list_of_fields_that_wont_be_updated = []
    
    for key in list_of_Required_Field_Names:
        
        field = dic_fields_for_translation.get(key)
        
        if (field == r'' or field == '-'):
            list_of_fields_that_wont_be_updated.append(key)
     
    # Get the list of fields/columns that should exist in the excel file:
        
    Fields_in_GUI_that_should_exist_in_excel = list(set(list_of_Required_Field_Names).difference(list_of_fields_that_wont_be_updated))
    
    # Get the list of Fields that should exist and DO NOT EXIST IN EXCEL:
        
    list_columns_that_should_exist_in_excel =[]

    for key in Fields_in_GUI_that_should_exist_in_excel:
        field = dic_fields_for_translation.get(key)
        list_columns_that_should_exist_in_excel.append(field)  
      
    # If the user introduces column names that do not exist in the excel file 
    # the script will NOT run
    # The Field names introduced in the GUI should coincide with the column names of the excel file
    
    for col_name in list_columns_that_should_exist_in_excel:
        
        if not (col_name in list_of_columns_names_excel_file):
            arcpy.AddMessage( r'ERRORE 101: One or multiple columns {} introduced in the GUI are missing in the input excel file'.format(list_columns_that_should_exist_in_excel) ) 
            sys.exit() 
    
    # Get the list of nodes to update:
    
    list_of_nodes_to_update = df_excel_file[ID_CONN[0]].to_list()
    
    Number_of_nodes_to_update = len(list_of_nodes_to_update)
    
    #..........................................................................
    
    # Make a copy of the LCPs layer:
    #..........................................................................
    New_Nodes_layer  = os.path.join(location_to_save_results,name_results_layer)
    arcpy.CopyFeatures_management(Nodes_layer, New_Nodes_layer)
    #..........................................................................
    
        
    # Go look for rows with the nodes to update and replace the columns 
    #--------------------------------------------------------------------------
    
    Nodes_updated = 1
    
    residual_for_progress = int(Number_of_nodes_to_update/10)
    
    if(residual_for_progress == 0):
        residual_for_progress=1
    
    with arcpy.da.UpdateCursor(New_Nodes_layer, list_of_Required_Field_Names) as cursor:
        
        for row in cursor:
            
            current_node = row[0]
            
            if current_node in list_of_nodes_to_update:
                
                # Here you Get the row with new attributes of the node to replace
                
                df_row_new_node_attributes = df_excel_file.loc[df_excel_file[ID_CONN[0]] == current_node]
                
                # Update the values of Qm3s:  
                excel_key = dic_fields_for_translation.get('Q_m3s')
                
                if not ( excel_key == r'' or field == '-'):    
                    New_Q = float(df_row_new_node_attributes[excel_key])
                    row[1] = New_Q
                
                if(Nodes_updated%residual_for_progress == 0):
                    arcpy.AddMessage( r'Row ' + str(Nodes_updated) +  r' out of ' + str(Number_of_nodes_to_update) + ' updated')
                    elapsed_time = (time.time() - time_before_execution)
                    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
                    Fraction_of_hours, hours =math.modf(Seconds/3600)
                    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
                
                Nodes_updated = Nodes_updated + 1
                cursor.updateRow(row) 
    
    #--------------------------------------------------------------------------            
                
    arcpy.AddMessage(r'Layer with updated nodes located at: ' + New_Nodes_layer)
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
            

###############################################################################
#                                                       Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)
p7 = arcpy.GetParameterAsText(6)

###############################################################################
#     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6,p7)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################