# -*- coding: utf-8 -*-
"""
Created on Fri May 27 18:11:16 2022

This is a simple loop to export all ArcGIS  GRID files inside a GDB to TIFF
format

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""

###############################################################################
#                 IMPORTANT REMARKS BEFORE RUNNING THIS CODE
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run this as a stand-alone script outside ArcGIS 
# user interface you still need a license.

# The script has been written as a stand-alone script and can  be run
# using any Python IDE (e.g. Spyder, Note ++ or Visual Studio)  

# To run as a stand-alone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and implement the __main__ function

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with a Python interpreter of ArcGIS Pro.

# location of python interpreter with the right Spyder kernels:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\Name_of_Your_VENV\python.exe 

# Important notes: before execution
# ..............................................................................
# To export 1 big raster in ArcGIS "GRID" format (12212 x 16248 cells @ 30 m resolution)
# to TIFF format takes about 2 minutes on a relatively good computer !

# Therefore, it is better to move these rasters in grid format by copying the
# entire Geo-database that contains them instead of copying each raster one by one

###############################################################################
#   ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS CODE    ^    ^     ^
###############################################################################

###############################################################################
#                          PACKAGES YOU NEED TO LOAD
###############################################################################

# These are the packages you need to load files

import os
import sys
import math
import time
import arcpy

# Allow output to overwrite...
arcpy.env.overwriteOutput = True

# Check out the ArcGIS Spatial Analyst extension license
arcpy.CheckOutExtension("Spatial")

###############################################################################
# ^  ^  ^  ^  ^  ^  ^   PACKAGES YOU NEED TO LOAD       ^  ^  ^  ^  ^  ^  ^ 
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

# Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")
if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    sys.exit()

###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

# Description of inputs:

description_p1 = r'location of input Geo-Database with the rasters you wnt to copy'
description_p2 = r'location to save rasters in TIFF format'

list_p_descriptions = [description_p1, description_p2]

default_values_p1 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb'
default_values_p2 = r'R:\03_GISdata\data_Gabriel\04-Tools\02-Python-Scripts\06-SMARTWATER-PyCharm\Input_files'

# Build a dictionary of parameters

dictionary_pars = {'p1': description_p1, 'p2': description_p2}

# Debugging:
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# p1 = default_values_p1
# p2 = default_values_p2
# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

###############################################################################
#      ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   List of inputs
###############################################################################

###############################################################################
#                                                                        Main()
###############################################################################

def main_function(p1, p2):

    time_before_execution = time.time()

    # Define function global variables:
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    arcpy.env.workspace = p1
    input_GDB_path = p1
    output_raster_folder = p2
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    list_of_rasters = arcpy.ListRasters("*", "GRID")
    Number_of_rasters = len(list_of_rasters)

    arcpy.AddMessage(r'Exporting  ' + str(Number_of_rasters) + r' rasters, please wait ...')
    count=0
    for raster in list_of_rasters:

        arcpy.AddMessage(r'Exporting Raster ' + str(count +1) + r' out of ' + str(Number_of_rasters))
        arcpy.AddMessage(r'Please wait....')
        # Here you get the type of raster:

        input_ras_path = os.path.join(input_GDB_path, raster)

        output_ras_name = raster + r'.tif'
        output_ras_path = os.path.join(output_raster_folder, output_ras_name)

        pixel_depth = arcpy.management.GetRasterProperties(input_ras_path, property_type="VALUETYPE")
        pixel_value_key = int(pixel_depth.getOutput(0))

        if pixel_value_key == 0:         # 0 = 1-bit
            Pix_type = "1_BIT"
            No_data_value = 0
        elif pixel_value_key == 1:       # 1 = 2-bit
            Pix_type = "2_BIT"
            No_data_value = 3
        elif pixel_value_key == 2:       # 2 = 4-bit
            Pix_type = "4_BIT"
            No_data_value = 15
        elif pixel_value_key == 3:       # 3 = 8-bit unsigned integer
            Pix_type = "8_BIT_UNSIGNED"
            No_data_value = 255
        elif pixel_value_key == 4:       # 4 = 8-bit signed integer
            Pix_type = "8_BIT_SIGNED"
            No_data_value = 127
        elif pixel_value_key == 5:       # 5 = 16-bit unsigned integer
            Pix_type = "16_BIT_UNSIGNED"
            No_data_value = 65535
        elif pixel_value_key == 6:       # 6 = 16-bit signed integer
            Pix_type = "16_BIT_SIGNED"
            No_data_value = 32767
        elif pixel_value_key == 7:       # 7 = 32-bit unsigned integer
            Pix_type = "32_BIT_UNSIGNED"
            No_data_value = 4294967295
        elif pixel_value_key == 8:       # 8 = 32-bit signed integer
            Pix_type = "32_BIT_SIGNED"
            No_data_value = 2147483647
        elif pixel_value_key == 9:       # 9 = 32-bit floating point
            Pix_type = "32_BIT_FLOAT"
            No_data_value = 9999999999
        elif pixel_value_key == 10:      # 10 = 64-bit double precision
            Pix_type = "64_BIT"
            No_data_value = 9999999999
        else:
            arcpy.AddMessage("Error: Unknown data type, not possible to to save")
            arcpy.AddMessage("Value key:" + str(pixel_value_key))
            arcpy.AddMessage("Possible value types:" + r" 11 = 8-bit complex/ 12 = 16-bit complex / 13 = 32-bit complex / 14 = 64-bit complex" )
            sys.exit()

        try:
            # Copy raster from GDB to TIFF :
            arcpy.management.CopyRaster(input_ras_path, output_ras_path, '', None, No_data_value, "NONE",
                                        "NONE", Pix_type, "NONE", "NONE", "TIFF", "NONE",
                                        "CURRENT_SLICE", "NO_TRANSPOSE")
            arcpy.AddMessage(r'Raster exported successfully  !')
        except:
            arcpy.AddMessage("Copy Raster failed !")
            arcpy.AddMessage(arcpy.GetMessages())

        count = count + 1

        elapsed_time = (time.time() - time_before_execution)
        Fraction_of_Seconds, Seconds = math.modf(elapsed_time)
        Fraction_of_hours, hours = math.modf(Seconds / 3600)
        arcpy.AddMessage('Elapsed time: ' + str(round(hours)) + ' hours ' + str(round(Seconds / 60) % 60) + ' minutes ' + str(round(Seconds % 60)) + ' seconds')
        arcpy.AddMessage(r'.........................')

    # ..............................................................................
    
    arcpy.AddMessage('All rasters located at: ' + output_raster_folder)
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds = math.modf(elapsed_time)
    Fraction_of_hours, hours = math.modf(Seconds / 3600)

    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds / 60) % 60) + ' minutes ' + str(round(Seconds % 60)) + ' seconds')

#%%
###############################################################################
#      ^      ^      ^      ^      ^      ^      ^      ^  Definition of Main()
###############################################################################

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################
main_function(p1, p2)
arcpy.AddMessage("Script executed successfully... ")
###############################################################################
#     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  End
###############################################################################