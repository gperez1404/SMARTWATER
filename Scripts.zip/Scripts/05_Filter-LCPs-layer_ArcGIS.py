# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 8:00:00 2022

This script helps the user to filter a polyline layer with LCPs using different
filters :
    
    Filter 1: use a max Path lenght value as filter
    Filter 2: use a max PathCost value as filter
    Filter 3: use a max EnvR value as filter
    Filter 4: use a max Delta H value as filter   
    Filter 5: use a key to delete Paths according to Origin-Destination nodes type:   D-D       = Delete paths connecting Demand-Demand nodes 
                                                                                      S-S       = Delete paths connecting Supply-Supply nodes
                                                                                      D-D & S-S = Delete paths connecting Demand-Demand AND Supply-Supply nodes
                                                                                      D-S       = Delete paths connecting Demand-Supply nodes
                                                                                      None      = Do not delete anything 
    
    Filter 6: Use a key to filter Demand nodes according to Subtype:   
                                                                     Rural Potable Water
                                                                     Urban potable water
                                                                     Indigenous communities
                                                                     Mining
                                                                     Other industry
                                                                     
    Filter 7: Use a key to filter Supply nodes according to Subtype: 
                                                                     Surface water
                                                                     Groundwater
                                                                     Desalination Plant
                                                                     Reservoir
                                                                     
                                                                     
    Filter 8: using a polygon feature to select by location    
                                         Spatial realtions:  INTERSECT
                                                             CONTAINS
                                                             COMPLETELY_CONTAINS
                                                             WITHIN
                                                             COMPLETELY_WITHIN
                                                             None
                                                             
    
This scripts certes a new LCP layer only with the LCPs (Paths) connectecing 
the nodes introduced as parameters

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with the Python interpreter of ArcGIS Pro.

# location of python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 


###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#                                                     PACKAGES YOU NEED TO LOAD
###############################################################################
import os
import sys
import time
import math

import openpyxl
from openpyxl import load_workbook, Workbook

import pandas as pd
import arcpy
from arcpy.sa import *
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^    EMD OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

#%%
###############################################################################
#                                                                List of inputs
###############################################################################

description_p1   = r'Location of input layer with LCPs'
description_p2   = r'Filter for maximum Path lenght value (leave blank if not to be used as filter):'                            # Filter 1 
description_p3   = r'Filter for maximum PathCost value (leave blank if not to be used as filter):'                               # Filter 2
description_p4   = r'Filter for maximum EnvR value (leave blank if not to be used as filter):'                                   # Filter 3
description_p5   = r'Filter for maximum Delta H value (leave blank if not to be used as filter):'                                # Filter 4
description_p6   = r'Type of connections to delete (D-D/S-S/D-D_&_S-S/D-S/None)'                                                 # Filter 5
description_p7   = r'Type of Demand nodes to keep (All types selected by default)'                                               # Filter 6
description_p8   = r'Type of Supply nodes to keep (All types selected by default)'                                               # Filter 7
description_p9   = r'Layer with a single polygon feature to select LCPs by location (leave blank if not to be used as filter):'  # Filter 8
description_p10  = r'Spatial relation to select by location (leave blank if not to be used as filter):'                          # Filter 8
description_p11  = r'Location to save the LCPs with resutls (GeoDatabase)'
description_p12  = r'File name to save the new layer with LCPs:'

list_p_descriptions = [description_p1,description_p2,description_p3,
                       description_p4,description_p5,description_p6,
                       description_p7,description_p8,description_p9,
                       description_p10,description_p11,description_p12]

default_values_p1  = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\All_LCPs_V4_with_Attributes_corrected'
default_values_p2  = r''                                                                                 # Filter 1
default_values_p3  = r''                                                                                 # Filter 2
default_values_p4  = r''                                                                                 # Filter 3
default_values_p5  = r''                                                                                 # Filter 4
default_values_p6  = r'D-D & S-S'                                                                        # Filter 5 
default_values_p7  = r'false false false true false false'                                               # Filter 6
default_values_p8  = r'false false true false false'                                                     # Filter 7
default_values_p9  = r''                                                                                 # Filter 8
default_values_p10 = r'None'                                                                             # Filter 8
default_values_p11 = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Scratch.gdb'              
default_values_p12 = r'Results_LCPs_filter_intento7'

list_of_keys =['p1','p2','p3','p4','p5','p6','p7','p8','p9','p10','p11','p12']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1  = arcpy.GetParameterAsText(0)
p2  = arcpy.GetParameterAsText(1)
p3  = arcpy.GetParameterAsText(2)
p4  = arcpy.GetParameterAsText(3)
p5  = arcpy.GetParameterAsText(4)
p6  = arcpy.GetParameterAsText(5)
p7  = arcpy.GetParameterAsText(6)
p8  = arcpy.GetParameterAsText(7)
p9  = arcpy.GetParameterAsText(8)
p10 = arcpy.GetParameterAsText(9)
p11 = arcpy.GetParameterAsText(10)
p12 = arcpy.GetParameterAsText(11)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                          Definition of Main() 
###############################################################################    

#..............................................................................

def main_function(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12):
          
    #Debugging:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # p1   = default_values_p1
    # p2   = default_values_p2
    # p3   = default_values_p3
    # p4   = default_values_p4 
    # p5   = default_values_p5
    # p6   = default_values_p6
    # p7   = default_values_p7
    # p8   = default_values_p8
    # p9   = default_values_p9
    # p10  = default_values_p10
    # p11  = default_values_p11
    # p12  = default_values_p12
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    time_before_execution = time.time()
    
    # Define global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    layer_LCPs        = p1
    location_results  = p11
    results_name_file = p12
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # load the LCPs layer:
    #..........................................................................
    List_of_field_names_LCPs_layer = [f.name for f in arcpy.ListFields(layer_LCPs)]    
    List_of_field_names_LCPs_layer.remove('Shape')   
    
    NP_Array_LCPs_attribute_table =  arcpy.da.FeatureClassToNumPyArray (layer_LCPs,List_of_field_names_LCPs_layer,skip_nulls=False,null_value=-99999)
    df_input_LCPs = pd.DataFrame(NP_Array_LCPs_attribute_table, columns = List_of_field_names_LCPs_layer)
    
    list_ShapeLength = df_input_LCPs['Shape_Length'].tolist()
    list_PathCost = df_input_LCPs['PathCost'].tolist()
    list_EnvR = df_input_LCPs['EnvRes'].tolist()
    list_DeltaH = df_input_LCPs['Delta_H'].tolist()
    #..........................................................................
    
    # Define the values to filter the LCP layer:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
    
    # Filter 1:
    if not ( p2 == r''):
        value_to_filter_PathLenght = float(p2)
    else:
        value_to_filter_PathLenght = max(list_ShapeLength)
    
    # Filter 2:    
    if not ( p3 == r''):
        value_to_filter_PathCost = float(p3)
    else:
        value_to_filter_PathCost = max(list_PathCost)
    
    # Filter 3:   
    if not ( p4 == r''):
        value_to_filter_EnvR = float(p4)
    else:
        value_to_filter_EnvR = max(list_EnvR)    
    
    # Filter 4:   
    if not ( p5 == r''):
        value_to_filter_DeltaH = float(p5)
    else:
        value_to_filter_DeltaH = max(list_DeltaH)    
        
    # Filter 5:   
    if   ( p6 == r'D-D'):
        SQL_expression_filter_5 = "O_Node = 'D' And D_Node = 'D'"
    elif ( p6 == r'S-S'):
        SQL_expression_filter_5 = "O_Node = 'S' And D_Node = 'S'"
    
    # Filter 6: 
    
    # Order of p7: 
    
    #         1           2           3           4          5 
    #     true/false true/false, true/false, true/false, true/false
    
    # 1 = Rural Potable Water
    # 2 = Urban potable water
    # 3 = Indigenous communities
    # 4 = Mining
    # 5 = Other industry
    
    # if p7 == r'true true true true true true'       -> Don't do anything
    # if p7 == r'false false false false false false' -> Error
    
    if ( p7 == r'false false false false false false'):
        sys.exit(r"ERROR: You need to select at least one type of Demand node to filter LCPs !")
        arcpy.AddMessage(r'ERROR: You need to select at least one type of Demand node to filter LCPs !')
   
    list_of_nodes_types =[r'Rural Potable Water', r'Urban Potable Water', r'Indigenous communities', r'Mining', r'Other industry', r'Agriculture']    
    list_of_booleans = p7.split()  
    list_of_types_to_keep_filter_6=[]
    
    count=0
    for entry in list_of_booleans:
        if (entry == 'true'):
            current_type = list_of_nodes_types[count]
            list_of_types_to_keep_filter_6.append(current_type)
        count=count+1
    
    list_of_types_to_delete_filter_6 = list(set(list_of_nodes_types) - set(list_of_types_to_keep_filter_6))
        
    
    # Filter 7: 
    
    # Order of p8: 
    
    #         1           2           3           4          5  
    #     true/false true/false  true/false  true/false  true/false
    
    # 1 = Surface water
    # 2 = Groundwater
    # 3 = Desalination Plant
    # 4 = Reservoir
    # 5 = Waste Water Treatment Plant
    
    # if p8 == r'true true true true true'      -> Don't do anything
    # if p8 == r'false false false false false'  -> Error
    
    if ( p8 == r'false false false false false'):
        sys.exit(r"ERROR: You need to select at least one type of Supply node to filter LCPs !")
        arcpy.AddMessage(r'ERROR: You need to select at least one type of Supply node to filter LCPs !')
   
    list_of_nodes_types =[r'Surface Water', r'Groundwater', r'Desalination Plant', r'Reservoir' ,'Waste Water Treatment Plant']    
    list_of_booleans = p8.split()  
    list_of_types_to_keep_filter_7=[]
    
    count=0
    for entry in list_of_booleans:
        if (entry == 'true'):
            current_type = list_of_nodes_types[count]
            list_of_types_to_keep_filter_7.append(current_type)
        count=count+1
    
    list_of_types_to_delete_filter_7 = list(set(list_of_nodes_types) - set(list_of_types_to_keep_filter_7))

    # Filter 8:   
    if not ( p9 == r''):
        layer_to_filter_by_location= p9
        Type_of_selection = p10

    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    arcpy.AddMessage(r'Extracting LCPs from input layer, please wait....')
    
    # Filter 1:
    #..........................................................................    
        
    # Use the ID to select by attribute:
    SQL_expression  = r'"'+ r'Shape_Length' + r'"<= ' +  str(value_to_filter_PathLenght)
    
    # Create a new TEMP layer to save the selection:
    layer_filter1 = os.path.join(location_results,r'layer_filter_1')
    filter_1=arcpy.MakeFeatureLayer_management(layer_LCPs, 'layer_filter_1', SQL_expression)
    
    arcpy.CopyFeatures_management(filter_1, layer_filter1)
    
    #..........................................................................
    if (arcpy.GetCount_management(layer_filter1) == 0):
        result_path= os.path.join(location_results,results_name_file)
        arcpy.CopyFeatures_management(layer_LCPs, result_path)
        arcpy.Delete_management(layer_filter1)
        
        arcpy.AddMessage(r'ERROR: NO filter was applied')
        arcpy.AddMessage(r'ERROR: You need to select less restrictions to filter LCPs by Shape_Length !')
        sys.exit(r"ERROR: You have over-restricted the filter, an emppty layer was created !")
    arcpy.AddMessage(r'Filter for Shape_Length applied successfully !')

    # Filter 2:
    #..........................................................................    
    
    # Use the ID to select by attribute:
    SQL_expression  = r'"'+ r'PathCost' + r'"<= ' +  str(value_to_filter_PathCost)
    
    # Create a new TEMP layer to save the selection:
    layer_filter2 = os.path.join(location_results,r'layer_filter_2')
    filter_2=arcpy.MakeFeatureLayer_management(layer_filter1, 'layer_filter_2', SQL_expression)
    
    arcpy.CopyFeatures_management(filter_2, layer_filter2)
    
    #..........................................................................
    if (arcpy.GetCount_management(layer_filter2) == 0):
        result_path= os.path.join(location_results,results_name_file)
        arcpy.CopyFeatures_management(layer_filter2, result_path)
        arcpy.Delete_management(layer_filter1)
        arcpy.Delete_management(layer_filter2)
        
        arcpy.AddMessage(r'ERROR: Layer was filtered sucessfully until filter # 1')
        arcpy.AddMessage(r'ERROR: You need to select less restrictions to filter LCPs by PathCost !')
        sys.exit(r"ERROR: You have over-restricted the filter, an emppty layer was created !")        
    arcpy.AddMessage(r'Filter for PathCost applied successfully !')

    # Filter 3:
    #..........................................................................    
    
    # Use the ID to select by attribute:
    SQL_expression  = r'"'+ r'EnvRes' + r'"<= ' +  str(value_to_filter_EnvR)
    
    # Create a new TEMP layer to save the selection:
    layer_filter3 = os.path.join(location_results,r'layer_filter_3')
    filter_3=arcpy.MakeFeatureLayer_management(layer_filter2, 'layer_filter_3', SQL_expression)
    
    arcpy.CopyFeatures_management(filter_3, layer_filter3)
    
    #..........................................................................
    if (arcpy.GetCount_management(layer_filter3) == 0):
        result_path= os.path.join(location_results,results_name_file)
        arcpy.CopyFeatures_management(layer_filter2, result_path)
        arcpy.Delete_management(layer_filter1)
        arcpy.Delete_management(layer_filter2)
        arcpy.Delete_management(layer_filter3)
        
        arcpy.AddMessage(r'ERROR: Layer was filtered sucessfully until filter # 2')
        arcpy.AddMessage(r'ERROR: You need to select less restrictions to filter LCPs by EnvRes!')
        sys.exit(r"ERROR: You have over-restricted the filter, an emppty layer was created !")    
        
    arcpy.AddMessage(r'Filter for EnvRes applied successfully !')
    
    # Filter 4:
    #..........................................................................
    
    # Use the ID to select by attribute:
    SQL_expression  = r'"'+ r'Delta_H' + r'"<= ' +  str(value_to_filter_DeltaH)
    
    # Create a new TEMP layer to save the selection:
    layer_filter4 = os.path.join(location_results,r'layer_filter_4')
    filter_4=arcpy.MakeFeatureLayer_management(layer_filter3, 'layer_filter_4', SQL_expression)
    
    arcpy.CopyFeatures_management(filter_4, layer_filter4)
    
    #..........................................................................
    if (arcpy.GetCount_management(layer_filter4) == 0):
        result_path= os.path.join(location_results,results_name_file)
        arcpy.CopyFeatures_management(layer_filter3, result_path)
        arcpy.Delete_management(layer_filter1)
        arcpy.Delete_management(layer_filter2)
        arcpy.Delete_management(layer_filter3)
        arcpy.Delete_management(layer_filter4)
        
        arcpy.AddMessage(r'ERROR: Layer was filtered sucessfully until filter # 3')
        arcpy.AddMessage(r'ERROR: You need to select less restrictions to filter LCPs by Delta_H!')
        sys.exit(r"ERROR: You have over-restricted the filter, an emppty layer was created !")    
        
    arcpy.AddMessage(r'Filter for Delta_H applied successfully !')

    
    # Filter 5
    #..........................................................................
    
    layer_filter5 = os.path.join(location_results,r'layer_filter_5')
    arcpy.CopyFeatures_management(layer_filter4, layer_filter5)
        
    if (p6 == r'D-D') or (p6== r'S-S'):
        Selection_filter_6=arcpy.management.SelectLayerByAttribute(layer_filter5, "NEW_SELECTION", SQL_expression_filter_5, None)
        #  execute DeleteFeatures to remove the selected features.
        if int(arcpy.GetCount_management(Selection_filter_6)[0]) > 0:
            arcpy.DeleteFeatures_management(layer_filter5)
            
    elif ( p6 == r'D-D & S-S'):
        
        SQL_expression_filter_5 = "O_Node = 'D' And D_Node = 'D'"
        First_selection_filter_6= arcpy.management.SelectLayerByAttribute(layer_filter5, "NEW_SELECTION", SQL_expression_filter_5, None)
        SQL_expression_filter_5 = "O_Node = 'S' And D_Node = 'S'"
        Second_selection_filter_6=arcpy.management.SelectLayerByAttribute(First_selection_filter_6, "ADD_TO_SELECTION", SQL_expression_filter_5, None)
        #  execute DeleteFeatures to remove the selected features.
        if int(arcpy.GetCount_management(Second_selection_filter_6)[0]) > 0:
            arcpy.DeleteFeatures_management(Second_selection_filter_6)

    #..........................................................................
    if (arcpy.GetCount_management(layer_filter5) == 0):
        result_path= os.path.join(location_results,results_name_file)
        arcpy.CopyFeatures_management(layer_filter4, result_path)
        arcpy.Delete_management(layer_filter1)
        arcpy.Delete_management(layer_filter2)
        arcpy.Delete_management(layer_filter3)
        arcpy.Delete_management(layer_filter4)
        arcpy.Delete_management(layer_filter5)
        
        arcpy.AddMessage(r'ERROR: Layer was filtered sucessfully until filter # 4')
        arcpy.AddMessage(r'ERROR: You need to select less restrictions to filter LCPs according to Path types (Origin-Destination combinations) !')
        sys.exit(r"ERROR: You have over-restricted the filter, an emppty layer was created !")    
        
    arcpy.AddMessage(r'Filter to delete Paths according to Path types (Origin-Destination combinations) applied successfully !')
    
    # Filter 6
    #..........................................................................
    
    layer_filter6 = os.path.join(location_results,r'layer_filter_6')
    arcpy.CopyFeatures_management(layer_filter5, layer_filter6)
    
    if not (p7 == r'false false false false false' or p7 == r'true true true true true' ):
                
        SQL_expression_filter_6  = arcpy.AddFieldDelimiters(layer_filter6, "O_type") + " = " + r"'" + list_of_types_to_delete_filter_6[0] + r"'"
        Selection_Filter_6=arcpy.management.SelectLayerByAttribute(layer_filter6, "NEW_SELECTION", SQL_expression_filter_6, None)
        
        SQL_expression_filter_6  = arcpy.AddFieldDelimiters(layer_filter6, "D_type") + " = " + r"'" + list_of_types_to_delete_filter_6[0] + r"'"
        Selection_Filter_6=arcpy.management.SelectLayerByAttribute(Selection_Filter_6, "ADD_TO_SELECTION", SQL_expression_filter_6, None)
        
        list_of_types_to_delete_filter_6.pop(0)
        
        if (len(list_of_types_to_delete_filter_6)>0):
        
            for type_to_add_to_current_selection in list_of_types_to_delete_filter_6:
                SQL_expression_filter_6  = arcpy.AddFieldDelimiters(layer_filter6, "O_type") + " = " + r"'" + type_to_add_to_current_selection + r"'"
                Selection_Filter_6=arcpy.management.SelectLayerByAttribute(Selection_Filter_6, "ADD_TO_SELECTION", SQL_expression_filter_6, None)
                
                SQL_expression_filter_6  = arcpy.AddFieldDelimiters(Selection_Filter_6, "D_type") + " = " + r"'" + type_to_add_to_current_selection + r"'"
                Selection_Filter_6=arcpy.management.SelectLayerByAttribute(Selection_Filter_6, "ADD_TO_SELECTION", SQL_expression_filter_6, None)
                
                
        #  execute DeleteFeatures to remove the selected features.
        if int(arcpy.GetCount_management(Selection_Filter_6)[0]) > 0:
            arcpy.DeleteFeatures_management(Selection_Filter_6)
    
    #..........................................................................
    if (arcpy.GetCount_management(layer_filter6) == 0):
        result_path= os.path.join(location_results,results_name_file)
        arcpy.CopyFeatures_management(layer_filter5, result_path)
        arcpy.Delete_management(layer_filter1)
        arcpy.Delete_management(layer_filter2)
        arcpy.Delete_management(layer_filter3)
        arcpy.Delete_management(layer_filter4)
        arcpy.Delete_management(layer_filter5)
        arcpy.Delete_management(layer_filter6)
        
        arcpy.AddMessage(r'ERROR: Layer was filtered sucessfully until filter # 5')
        arcpy.AddMessage(r'ERROR: You need to select less restrictions to filter LCPs according to types of Demand nodes !')
        sys.exit(r"ERROR: You have over-restricted the filter, an emppty layer was created !")    
        
    arcpy.AddMessage(r'Filter to select Paths according to types of Demand nodes applied successfully !')
    
    # Filter 7
    #..........................................................................
    
    layer_filter7 = os.path.join(location_results,r'layer_filter_7')
    arcpy.CopyFeatures_management(layer_filter6, layer_filter7)
    
    if not (p8 == r'false false false false' or p8 == r'true true true true' ):
                 
        SQL_expression_filter_7  = arcpy.AddFieldDelimiters(layer_filter7, "O_type") + " = " + r"'" + list_of_types_to_delete_filter_7[0] + r"'"
        Selection_Filter_7= arcpy.management.SelectLayerByAttribute(layer_filter7, "NEW_SELECTION", SQL_expression_filter_7, None)
        
        SQL_expression_filter_7  = arcpy.AddFieldDelimiters(layer_filter7, "D_type") + " = " + r"'" + list_of_types_to_delete_filter_7[0] + r"'"
        Selection_Filter_7= arcpy.management.SelectLayerByAttribute(Selection_Filter_7, "ADD_TO_SELECTION", SQL_expression_filter_7, None)
       
        
        list_of_types_to_delete_filter_7.pop(0)
        
        if (len(list_of_types_to_delete_filter_7)>0):

            for type_to_add_to_current_selection in list_of_types_to_delete_filter_7:
                SQL_expression_filter_7  = arcpy.AddFieldDelimiters(layer_filter7, "O_type") + " = " + r"'" + type_to_add_to_current_selection + r"'"
                Selection_Filter_7= arcpy.management.SelectLayerByAttribute(Selection_Filter_7, "ADD_TO_SELECTION", SQL_expression_filter_7, None)
                
                SQL_expression_filter_7  = arcpy.AddFieldDelimiters(layer_filter7, "D_type") + " = " + r"'" + type_to_add_to_current_selection + r"'"
                Selection_Filter_7= arcpy.management.SelectLayerByAttribute(Selection_Filter_7, "ADD_TO_SELECTION", SQL_expression_filter_7, None)

            
        #  execute DeleteFeatures to remove the selected features.
        if int(arcpy.GetCount_management(Selection_Filter_7)[0]) > 0:
            arcpy.DeleteFeatures_management(Selection_Filter_7)
    
    #..........................................................................
    if (arcpy.GetCount_management(layer_filter7) == 0):
        result_path= os.path.join(location_results,results_name_file)
        arcpy.CopyFeatures_management(layer_filter6, result_path)
        arcpy.Delete_management(layer_filter1)
        arcpy.Delete_management(layer_filter2)
        arcpy.Delete_management(layer_filter3)
        arcpy.Delete_management(layer_filter4)
        arcpy.Delete_management(layer_filter5)
        arcpy.Delete_management(layer_filter6)
        arcpy.Delete_management(layer_filter7)
        
        arcpy.AddMessage(r'ERROR: Layer was filtered sucessfully until filter # 6')
        arcpy.AddMessage(r'ERROR: You need to select less restrictions to filter LCPs according to types of Supply nodes !')
        sys.exit(r"ERROR: You have over-restricted the filter, an emppty layer was created !")    
        
    arcpy.AddMessage(r'Filter to select Paths according to types of Supply nodes applied successfully !')
    
    
    # Filter 8:
    #..........................................................................
    
    layer_filter8 = os.path.join(location_results,r'layer_filter_8')
    arcpy.CopyFeatures_management(layer_filter7, layer_filter8)
    
    if not (p9 == r'' and p9 != r'None'):
        
        # Here you select the opposite of waht you want becaause you want to delete 
        Selection_Filter_8=arcpy.management.SelectLayerByLocation(layer_filter8, Type_of_selection, layer_to_filter_by_location, None, "NEW_SELECTION", "INVERT")
        
        #  execute DeleteFeatures to remove the selected features.
        if int(arcpy.GetCount_management(Selection_Filter_8)[0]) > 0:
            arcpy.DeleteFeatures_management(Selection_Filter_8)
    
    #..........................................................................
    if (arcpy.GetCount_management(layer_filter8) == 0):
        result_path= os.path.join(location_results,results_name_file)
        arcpy.CopyFeatures_management(layer_filter7, result_path)
        arcpy.Delete_management(layer_filter1)
        arcpy.Delete_management(layer_filter2)
        arcpy.Delete_management(layer_filter3)
        arcpy.Delete_management(layer_filter4)
        arcpy.Delete_management(layer_filter5)
        arcpy.Delete_management(layer_filter6)
        arcpy.Delete_management(layer_filter7)
        arcpy.Delete_management(layer_filter8)
        
        arcpy.AddMessage(r'ERROR: Layer was filtered sucessfully until filter # 7')
        arcpy.AddMessage(r'ERROR: You need to select a different restriction to filter LCPs by location!')
        sys.exit(r"ERROR: You have over-restricted the filter, an emppty layer was created !")    
        
    arcpy.AddMessage(r'Filter to select LCPs by location applied successfully !')

    # Create layer resutls:
    #..........................................................................
    result_path= os.path.join(location_results,results_name_file)
    arcpy.CopyFeatures_management(layer_filter8, result_path)
    #..........................................................................
    arcpy.AddMessage(r'Layer with filtered LCPs located at:' + result_path)
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
        
    # Delete TEMP files:
    #..........................................................................
    arcpy.Delete_management(layer_filter1)
    arcpy.Delete_management(layer_filter2)
    arcpy.Delete_management(layer_filter3)
    arcpy.Delete_management(layer_filter4)
    arcpy.Delete_management(layer_filter5)
    arcpy.Delete_management(layer_filter6)
    arcpy.Delete_management(layer_filter7)
    arcpy.Delete_management(layer_filter8)
    #..........................................................................
    
#..............................................................................

###############################################################################
#      ^      ^      ^      ^      ^      ^      ^      ^  Definition of Main() 
###############################################################################   

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################


