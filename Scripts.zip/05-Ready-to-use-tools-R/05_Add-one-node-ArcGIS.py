# -*- coding: utf-8 -*-
"""
Created on Tue May 31 18:54:27 2022

This script adds a new node to the layer with nodes


@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""

###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with the Python interpreter of ArcGIS Pro.

# location of python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 


###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#%%                        PACKAGES YOU NEED TO LOAD
###############################################################################
 
# These are the packages you need to load files

import os
import sys
import shutil
import warnings
import string
import math
import traceback
import glob
import time

import openpyxl

import itertools
from itertools import permutations  

import arcpy
from arcpy.sa import *

import numpy as np
import pandas as pd

from decimal import Decimal

# Allow output to overwrite...
arcpy.env.overwriteOutput = True

# Check out the ArcGIS Spatial Analyst extension license
arcpy.CheckOutExtension("Spatial")

###############################################################################
# ^  ^  ^  ^  ^  ^  ^   PACKAGES YOU NEED TO LOAD       ^  ^  ^  ^  ^  ^  ^ 
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Values for Debugging:
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
# p_1_n_node    = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\SMARTW_all_nodes'
# p_2_n_node    = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb'
# p_3_n_node    = r'SMARTW_with_new_node_V4'
# p_4_n_node    = r'Copiapo usuario X'
# p_5_n_node    = r'413362.575'
# p_6_n_node    = r'6957758.6079'
# p_7_n_node    = r'Rural Potable Water'
# p_8_n_node    = r'S' 
# p_9_n_node    = r'ACTIVE'
# p_10_n_node   = r'0.01'
# p_11_n_node   = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\DEM_30m'
# p_12_n_node   = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM_Temp.gdb'
# #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

# Description of inputs:
#..............................................................................
description_p1    = r'file path with the existing nodes' 
description_p2    = r'location to save the new layer with the additional node'
description_p3    = r'Name of the layer with the new node'
description_p4    = r'Name of the node'
description_p5    = r'X coordinates new node'
description_p6    = r'Y coordinates new node'
description_p7    = r'Node type [Groundwater, Mining, Rural Potable Water, Surface water, Urban potable water, Desalination Plant, Reservoir, Other industry, Indigenous communities ]' 
description_p8    = r'Letter indicating if the node is demand or supply [D,S]'  
description_p9    = r'Node Status [ACTIVE, PROJECT, ASSUMED, CLOSED, OUT OF SCOPE]'  
description_p10   = r'Node Q [m3/sec] '  
description_p11   = r'File to extract elevation '  
description_p12   = r'GDB to save temp data '  

list_p_descriptions = [description_p1,description_p2,description_p3,description_p4,
                       description_p5,description_p6,description_p7,description_p8,
                       description_p9,description_p10,description_p11,description_p12]

list_of_keys =['p1','p2','p3','p4','p5','p6','p7','p8','p9','p10','p11','p12']
dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 
#..............................................................................

#%%
###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

#..............................................................................
def main_function(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12):
    #
    time_before_execution_main = time.time()
    
    arcpy.AddMessage(r'Veryfying if the input layer is the right type....')

    desc = arcpy.Describe(p1)
    if not (desc.shapeType == 'Point'):
        arcpy.AddMessage( r'ERROR 101: Input layer is not a Point layer !')
        arcpy.AddMessage( r'Please change the input node layer and try again...')
        sys.exit() 
        
    
    arcpy.AddMessage(r'Veryfying if the input layer has the right atttribute fields....')
    
    # load the list of existing nodes:
    #..........................................................................
    List_of_field_names = [f.name for f in arcpy.ListFields(p1)]    
    List_of_field_names.remove('Shape')    
        
    NP_Array_nodes_attribute_table =  arcpy.da.FeatureClassToNumPyArray (p1,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_input_nodes = pd.DataFrame(NP_Array_nodes_attribute_table, columns = List_of_field_names)
    #..........................................................................
    
    list_of_required_Fields= ['OBJECTID','ID_CONN','ID_MCI','NODE','TYPE','STATUS','UTM_East','UTM_North','Elevation_M','NAME','Q_m3s']
    
    if not (set(list_of_required_Fields).issubset(List_of_field_names)):
        d = {j:i for i,j in enumerate(list_of_required_Fields)}
        missing_attributes = sorted(list((set(list_of_required_Fields) - set(List_of_field_names))), key = lambda x: d[x])
        arcpy.AddMessage( r'ERROR 101: Input layer does not have the right Fields !!')
        arcpy.AddMessage( r'Missing attributes: ' + str(missing_attributes))
        sys.exit() 
    
    arcpy.AddMessage('Adding new node to layer, please wait....')
    
    
    # Create a copy of the input layer (this layer will hold the result): 
    #......................................................................
    Layer_with_new_node = os.path.join(p2, p3)    
    arcpy.CopyFeatures_management(p1, Layer_with_new_node)
    #......................................................................
    
    #
    # Get the list of attributes of the existing nodes:
    #..........................................................................    
    list_of_Object_IDs = df_input_nodes['OBJECTID'].tolist()
    list_of_nodes_IDs = df_input_nodes['ID_CONN'].tolist()
    list_of_MCI_IDs = df_input_nodes['ID_MCI'].tolist() # will be created based on p7
    list_of_NODE = df_input_nodes['NODE'].tolist()    # [D/S] -> p_8_n_node
    list_of_TYPE = df_input_nodes['TYPE'].tolist()   # p_7_n_node [Groundwater, Mining, Rural Potable Water, Surface water, Urban potable water, Desalination Plant, Reservoir, Other industry, Indigenous communities ]
    list_of_Status = df_input_nodes['STATUS'].tolist()  # p_9_n_node
    list_Coord_X = df_input_nodes['UTM_East'].tolist()   # p_5_n_node
    list_Coord_Y = df_input_nodes['UTM_North'].tolist()  # p_6_n_node
    list_Elevation = df_input_nodes['Elevation_M'].tolist()  # p_6_n_node
    list_names = df_input_nodes['NAME'].tolist()  # p_4_n_node      
    list_Q_s =  df_input_nodes['Q_m3s'].tolist()  # p_10_n_node    
    
    Number_of_nodes=len(list_of_nodes_IDs) 
    #..........................................................................
    
    # Create the attributes of the new nodes:
    #..........................................................................
    New_OBID =int(list_of_Object_IDs[Number_of_nodes-1])+1
    New_IDCONN= max(list(set(list_of_nodes_IDs))) +1
    New_NODE =  str(p8)
    New_TYPE =  str(p7)
    New_STATUS = str(p9)
    New_UTM_East = round(float(p5),0)
    New_UTM_North = round(float(p6),0)
    New_Elevation= 0
    New_Name = str(p4)
    New_Q = round(Decimal(p10),4)
    #..........................................................................
    
    # Add a new row to the copy layer with the result:
    #..........................................................................

    # A list of Tuples with the rows to be added to the layer :
    row_values = [(New_OBID,(float(p5), float(p6)))]

    # Open an InsertCursor
    cursor = arcpy.da.InsertCursor(Layer_with_new_node,['OBJECTID','SHAPE@XY'])
   
    # Insert new row
    # This row will be empty only the shape attributes will have value
    
    for row in row_values:
        cursor.insertRow(row)

    # Delete cursor object
    del cursor
    
    arcpy.AddMessage('Row with new point added to the nodes layer' )

    #..........................................................................
     
    # Create MCI value:
    #..........................................................................    
    
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # Debugging 
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    #Get the list of unique node types:
    #Unique_TYPE_keys = list(set(list_of_TYPE))
    #['Groundwater', 'Rural Potable Water', 'Surface Water','Agriculture','Urban Potable Water', 'Mining', 'Other industry', 'Desalination plant','Waste Water Treatment Plant','Desalination Plant', 'Indigenous communities', 'Reservoir']
    
    # Get list of Unique Letter keys MCI 
    #Unique_MCI_keys = list(set([i.split(r'_')[0] for i in list_of_MCI_IDs])) 
    # ['SW', 'GW', 'WWTP', 'R', 'M', 'UPW', 'IC', 'A', 'I', 'RPW', 'DP']
    
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # Transform the TYPE (p7) into MCI  |  TYPE > MCI: 
     
    unique_Type_keys = list(set(list_of_TYPE)) 
    
    if(str(p7) ==  'Groundwater'):
        MCI_key= 'GW'
    elif (str(p7) ==  'Rural Potable Water'):
        MCI_key= 'RPW'
    elif ( (str(p7) ==  'Surface Water') or (str(p7) ==  'surface water') or (str(p7) ==  'Surface water')):
        MCI_key= 'SW'
    elif (str(p7) ==  'Agriculture'):
        MCI_key= 'A'
    elif (str(p7) ==  'Urban Potable Water') or (str(p7) ==  'Urban potable water') or (str(p7) ==  'Urban Potable water') or (str(p7) ==  'urban potable water'):
        MCI_key= 'UPW'
    elif ( (str(p7) ==  'Mining') or (str(p7) ==  'mining') ):
        MCI_key= 'M'
    elif (str(p7) ==  'Other industry'):
        MCI_key= 'I'
    elif ( (str(p7) ==  'Desalination plant') or (str(p7) == 'Desalination Plant') or (str(p7) == 'desalination plant')):
        MCI_key= 'DP'
    elif (str(p7) ==  'Waste Water Treatment Plant'):
        MCI_key= 'WWTP'
    elif (str(p7) ==  'Indigenous communities'):
        MCI_key= 'IC'
    elif (str(p7) ==  'Reservoir'):
        MCI_key= 'R'
    else:
        MCI_key= 'None'

    # Make the consecutive MCI Key based on existing MCI's    
    
    if (MCI_key== 'SW'):
        sub_list = [s for s in list_of_MCI_IDs if "SW_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'SW_' + str(Number_of_exisitng_Keys+1)
    elif (MCI_key == 'GW'):
        sub_list = [s for s in list_of_MCI_IDs if "GW_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'GW_' + str(Number_of_exisitng_Keys+1)  
    elif(MCI_key == 'WWTP'):
        sub_list = [s for s in list_of_MCI_IDs if "WWTP_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'WWTP' + str(Number_of_exisitng_Keys+1)
    elif(MCI_key == 'R'):
        sub_list = [s for s in list_of_MCI_IDs if "R_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'R_' + str(Number_of_exisitng_Keys+1) 
    elif(MCI_key == 'M'):
        sub_list = [s for s in list_of_MCI_IDs if "M_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'M_' + str(Number_of_exisitng_Keys+1)
    elif(MCI_key == 'UPW'):
        sub_list = [s for s in list_of_MCI_IDs if "UPW_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'UPW_' + str(Number_of_exisitng_Keys+1)
    elif(MCI_key == 'IC'):
        sub_list = [s for s in list_of_MCI_IDs if "IC_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'IC_' + str(Number_of_exisitng_Keys+1)
    elif(MCI_key == 'A'):
        sub_list = [s for s in list_of_MCI_IDs if "A_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'A_' + str(Number_of_exisitng_Keys+1)
    elif(MCI_key == 'I'):
        sub_list = [s for s in list_of_MCI_IDs if "I_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'I_' + str(Number_of_exisitng_Keys+1)
    elif(MCI_key == 'RPW'):
        sub_list = [s for s in list_of_MCI_IDs if "RPW_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'RPW_' + str(Number_of_exisitng_Keys+1)
    elif(MCI_key == 'DP'):
        sub_list = [s for s in list_of_MCI_IDs if "DP_" in s]
        Number_of_exisitng_Keys = len(sub_list)
        New_MCI = r'DP_' + str(Number_of_exisitng_Keys+1)
    else:
        New_MCI = MCI_key + r'_' + str(1)  # The user introduced a new type of node
    
    #..........................................................................
    
    # Get the elevation value
    #..........................................................................
    
    # Select the new node
    SQL_expression  = r'"'+ 'OBJECTID' + r'"= ' +  str(New_OBID)

    # Create a new TEMP layer  to save the selection
    layer_with_new_node_only = arcpy.MakeFeatureLayer_management(Layer_with_new_node, r"New_node_only" , SQL_expression)
    
    # save the layer in a new file in the scratch GDB
    Temp_layer_new_node_only = os.path.join(p12,'New_node_only')
    arcpy.CopyFeatures_management(layer_with_new_node_only, Temp_layer_new_node_only)

    Temp_layer_with_elevation =os.path.join(p12, r'new_node_with_elevation')
    
    #ExtractValuesToPoints(Input_points_filepath,Input_raster_filepath,Output_points_filepath,"INTERPOLATE","VALUE_ONLY")
    ExtractValuesToPoints(Temp_layer_new_node_only,p11,Temp_layer_with_elevation,"INTERPOLATE","VALUE_ONLY")
    
    # load layer and extract elevation value ['RASTERVALUE']
    
    List_of_field_names = [f.name for f in arcpy.ListFields(Temp_layer_with_elevation)]    
    List_of_field_names.remove('Shape')    
    # ['OBJECTID', 'ID_CONN', 'ID_MCI', 'NODE', 'TYPE', 'STATUS', 'UTM_East', 'UTM_North', 'Elevation_M', 'NAME', 'Q_m3s', 'RASTERVALU']
   
    NP_Array_Elev =  arcpy.da.FeatureClassToNumPyArray (Temp_layer_with_elevation,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_Elev = pd.DataFrame(NP_Array_Elev, columns = ['RASTERVALU'])
    
    New_Elevation =round( df_Elev['RASTERVALU'].tolist()[0],2)
    #..........................................................................
    
    # Populate all the fields:
    #..........................................................................
    # Fill up the fields of the new node  in the new layer :

    fields_to_modify = ['OBJECTID',
                        'ID_CONN',
                        'ID_MCI',
                        'NODE',
                        'TYPE',
                        'STATUS',
                        'UTM_East',
                        'UTM_North',
                        'Elevation_M',
                        'NAME',
                        'Q_m3s']

    row_count=0
      
    with arcpy.da.UpdateCursor(Layer_with_new_node, fields_to_modify) as cursor:
      
        for row in cursor:
            
            OBb_ID_row =row[0] 
            
            if(OBb_ID_row == New_OBID):
                row[1] = New_IDCONN
                row[2] = New_MCI
                row[3] = New_NODE
                row[4] = New_TYPE
                row[5] = New_STATUS
                row[6] = New_UTM_East
                row[7] = New_UTM_North
                row[8] = New_Elevation
                row[9] = New_Name
                row[10] = New_Q
                cursor.updateRow(row)
            row_count=row_count +1
            
    #..........................................................................
    
    elapsed_time = (time.time() - time_before_execution_main)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage( r'Layer with new node located at: ' + Layer_with_new_node)
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )    
    
    #..........................................................................
    
#..............................................................................    
    
###############################################################################
#                                                      Getting inputs from GUI
###############################################################################
#
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Debugging:
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# p1= p_1_n_node
# p2= p_2_n_node
# p3= p_3_n_node
# p4= p_4_n_node
# p5= p_5_n_node
# p6= p_6_n_node
# p7= p_7_n_node
# p8= p_8_n_node
# p9= p_9_n_node
# p10= p_10_n_node
# p11= p_11_n_node
# p12= p_12_n_node
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)
p7 = arcpy.GetParameterAsText(6)
p8 = arcpy.GetParameterAsText(7)
p9 = arcpy.GetParameterAsText(8)
p10 = arcpy.GetParameterAsText(9)
p11 = arcpy.GetParameterAsText(10)
p12 = arcpy.GetParameterAsText(11)

# transform the numeric parameters to numbers:
    
p5  =Decimal(p5)
p6  =Decimal(p6)
p10 =Decimal(p10)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12)

arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################
