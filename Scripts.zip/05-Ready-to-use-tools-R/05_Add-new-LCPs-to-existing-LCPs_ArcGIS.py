# -*- coding: utf-8 -*-
"""
Created on Fri Jun  3 06:30:42 a.m 2022

This script merges two layers with LCPs making sure no elements are repeated

        Execution steps:
            
        1. gets a list with PathDes of layer with LCPs to add 
        2. Creates a new layer to save all the LCPS (Copy of the old layer)
        3. Deletes all the rows with the LCPs you want to add as new layers
        4. Uses the ArcGIS merge function to merge the two layers

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
#                        PACKAGES YOU NEED TO LOAD
###############################################################################

import os
import sys
import time

import math
import pandas as pd

import arcpy
from arcpy.sa import *

import numpy as np
import pandas as pd

import math

###############################################################################
# ^  ^  ^  ^  ^  ^  ^   PACKAGES YOU NEED TO LOAD       ^  ^  ^  ^  ^  ^  ^ 
###############################################################################
###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################


###############################################################################
#                                                                List of inputs
###############################################################################

description_p1 = r'Location of layer with existing LCPs'
description_p2 = r'Location of layer with new LCPs'
description_p3 = r'Location to save results layer (GBD)'
description_p4 = r'Name of the resutls layer'
description_p5 = r'Location to save TEMP results'
description_p6 = r'Id field to identify LCPs (No quotation marks)'

list_p_descriptions = [description_p1,description_p2,description_p3,description_p4,
                       description_p5,description_p6]

list_of_keys =['p1','p2','p3','p4','p5','p6']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                       Definition of fucntions 
###############################################################################    

#..............................................................................

def main_function(p1,p2,p3,p4,p5,p6):
    
    time_before_execution = time.time()
    
    # Define function global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    layer_with_old_LCPs= p1
    layer_with_new_LCPs= p2
    Location_to_save_results = p3
    name_results = p4
    Location_Temp_results =p5
    Field_to_identify_LCPs= p6
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    #Debugging:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # layer_with_old_LCPs= r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Temp_Files_multiprocessing\LCPs_to_merge.gdb\Old_LCPs'
    # layer_with_new_LCPs= r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Temp_Files_multiprocessing\LCPs_to_merge.gdb\New_LCPs'
    # layer_results = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM_LCPs_by_node_V3.gdb\All_LCPs_V3_with_Attributes_OP2'
    # Location_Temp_results =r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Temp.gdb'
    # Field_to_identify_LCPs= r'PathDes'
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    layer_results = os.path.join(Location_to_save_results,name_results)

    # Get the list of new LCPs:
    #..............................................................................
    List_of_field_names = [f.name for f in arcpy.ListFields(layer_with_new_LCPs)]    
    List_of_field_names.remove('Shape')
        
    NP_Array_new_LCPs =  arcpy.da.FeatureClassToNumPyArray (layer_with_new_LCPs,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_new_LCPs = pd.DataFrame(NP_Array_new_LCPs, columns = List_of_field_names)
    
    list_new_LCPs = df_new_LCPs[Field_to_identify_LCPs].tolist()
    
    # Get the list of old LCPs:
    #..........................................................................
    
    List_of_field_names = [f.name for f in arcpy.ListFields(layer_with_old_LCPs)]    
    List_of_field_names.remove('Shape')
    
    NP_Array_old_LCPs =  arcpy.da.FeatureClassToNumPyArray (layer_with_old_LCPs,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_old_LCPs = pd.DataFrame(NP_Array_old_LCPs, columns = List_of_field_names)
    
    list_old_LCPs = df_old_LCPs[Field_to_identify_LCPs].tolist()
    #..........................................................................

    # Delete the rows that will be replaced in from the layer with old LCPs :
    #..........................................................................
    # make a copy of the old LCP layer:
    Temp_copy = os.path.join(Location_Temp_results, r'temp_copy_LCPs')    
    arcpy.CopyFeatures_management(layer_with_old_LCPs, Temp_copy)
     
    list_LCPs_repeated = list(set(list_new_LCPs) & set(list_old_LCPs))
        
    with arcpy.da.UpdateCursor(Temp_copy, [Field_to_identify_LCPs]) as cursor:
      for row in cursor:
          current_LCP = row[0]
          if current_LCP in list_LCPs_repeated:
              arcpy.AddMessage( r'Row was replaced with new values: ' + current_LCP)
              cursor.deleteRow()
    #..........................................................................
    
    # Merge the New LCPs to the copy of Old LCPs:
    #..........................................................................
    arcpy.management.Merge([Temp_copy,layer_with_new_LCPs],layer_results)
    #..........................................................................
    
    # Re-number the Object Ids to make sure they are unique:
    #..........................................................................    
    OIDField_LCPs = arcpy.Describe(layer_results).OIDFieldName
    
    List_of_field_names = [f.name for f in arcpy.ListFields(layer_results)]    
    List_of_field_names.remove('Shape')
    
    NP_Array_results =  arcpy.da.FeatureClassToNumPyArray (layer_results,List_of_field_names,skip_nulls=False,null_value=-99999)
    df_results = pd.DataFrame(NP_Array_results, columns = List_of_field_names)
    
    list_OBIDs_resutls = df_results[OIDField_LCPs].tolist()
    
    Number_of_LCPS =len(list_OBIDs_resutls)
    
    New_list_OBIDs =list(range(1, Number_of_LCPS+1))
    
    fields_to_modify = [OIDField_LCPs]
    
    row_count=0
    
    with arcpy.da.UpdateCursor(layer_results, fields_to_modify) as cursor:
      
        for row in cursor:
            
            row[0] = New_list_OBIDs[row_count]
            row_count=row_count+1
            cursor.updateRow(row)
            
    #..........................................................................
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage(r'New layer located at : ' + layer_results ) 
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
   
  
###############################################################################
#%%  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    End
###############################################################################

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6)

arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################