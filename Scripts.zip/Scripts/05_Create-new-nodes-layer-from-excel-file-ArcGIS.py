# -*- coding: utf-8 -*-
"""
Created on Mon Aug  1 17:05:27 2022

This script uses an existing nodes layer as a tempalte to generate a new 
nodes layer based on a lsit of nodes in an excel file

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with the Python interpreter of ArcGIS Pro.

# location of python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 


###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#                          PACKAGES YOU NEED TO LOAD
###############################################################################
 
# These are the packages you need to load files

import os
import sys
import shutil
import warnings
import string
import math
import traceback
import glob
import time

import openpyxl

import itertools
from itertools import permutations  

import arcpy
from arcpy.sa import *

import numpy as np
import pandas as pd

from decimal import Decimal

# Allow output to overwrite...
arcpy.env.overwriteOutput = True

# Check out the ArcGIS Spatial Analyst extension license
arcpy.CheckOutExtension("Spatial")

###############################################################################
# ^  ^  ^  ^  ^  ^  ^   PACKAGES YOU NEED TO LOAD       ^  ^  ^  ^  ^  ^  ^ 
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################


# Description of inputs:
#..............................................................................
description_p1  = r'file path of the layer with the nodes to use as template for fields:' 
description_p2  = r'Location to save the result:'
description_p3  = r'Name of the new layer with nodes to be created:'
description_p4  = r'file path of the excel file with the information of nodes to be created:'
description_p5  = r'Location surface rasters (DEM) to extract elevation (ArcGID format): '  
description_p6  = r'file path to GDB to save temp data:'  

list_p_descriptions = [description_p1,description_p2,description_p3,description_p4,description_p5]

list_of_keys =['p1','p2','p3','p4','p5','p6']
dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 
#..............................................................................


#Default values:
#..............................................................................



#..............................................................................

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################


###############################################################################
#                                                                     Functions
###############################################################################


#..............................................................................
def add_node_attributes_to_layer(layer_to_add_node,New_OBID,New_IDCONN,New_MCI,
                                 New_NODE,New_TYPE,New_STATUS,New_UTM_East,
                                 New_UTM_North,New_Elevation,New_Name,New_Q):
    
    
    
    # Populate all the fields:
    #..........................................................................
    # Fill up the fields of the new node  in the new layer :

    fields_to_modify = ['OBJECTID',
                        'ID_CONN',
                        'ID_MCI',
                        'NODE',
                        'TYPE',
                        'STATUS',
                        'UTM_East',
                        'UTM_North',
                        'Elevation_M',
                        'NAME',
                        'Q_m3s']

    row_count=0
      
    with arcpy.da.UpdateCursor(layer_to_add_node, fields_to_modify) as cursor:
      
        for row in cursor:
            
            OBb_ID_row =row[0] 
            
            if(OBb_ID_row == New_OBID):
                row[1] = New_IDCONN
                row[2] = New_MCI
                row[3] = New_NODE
                row[4] = New_TYPE
                row[5] = New_STATUS
                row[6] = New_UTM_East
                row[7] = New_UTM_North
                row[8] = New_Elevation
                row[9] = New_Name
                row[10] = New_Q
                cursor.updateRow(row)
            row_count=row_count +1
            
    #..........................................................................
    arcpy.AddMessage('Atrtibutes for node '  + New_Name + r' added successfully !') 

#..............................................................................

#..............................................................................
def main_function(p1,p2,p3,p4,p5,p6):
    
    time_before_execution_main = time.time()
        
    arcpy.AddMessage(r'p1 =' + str(p1))
    arcpy.AddMessage(r'p2 =' + str(p2))
    arcpy.AddMessage(r'p3 =' + str(p3))
    arcpy.AddMessage(r'p4 =' + str(p4))
    arcpy.AddMessage(r'p5 =' + str(p5))
    arcpy.AddMessage(r'p6 =' + str(p6))
    
    arcpy.AddMessage(r'Veryfying that the input layer is the right type....')

    desc = arcpy.Describe(p1)
    if not (desc.shapeType == 'Point'):
        arcpy.AddMessage( r'ERROR 101: Input layer is not a Point layer !')
        arcpy.AddMessage( r'Please change the input node layer and try again...')
        sys.exit() 
    arcpy.AddMessage(r'Input layer type OK!')
    
    
    arcpy.AddMessage(r'Veryfying that the input layer has the right atttribute fields....')
    
    # load template layer:
    #..........................................................................
    List_of_field_names = [f.name for f in arcpy.ListFields(p1)]    
    List_of_field_names.remove('Shape')    
    #..........................................................................
    
    list_of_required_Fields= ['OBJECTID','ID_CONN','ID_MCI','NODE','TYPE','STATUS','UTM_East','UTM_North','Elevation_M','NAME','Q_m3s']
    
    if not (set(list_of_required_Fields).issubset(List_of_field_names)):
        d = {j:i for i,j in enumerate(list_of_required_Fields)}
        missing_attributes = sorted(list((set(list_of_required_Fields) - set(List_of_field_names))), key = lambda x: d[x])
        arcpy.AddMessage( r'ERROR 101: Input layer does not have the right Fields !!')
        arcpy.AddMessage( r'Missing attributes: ' + str(missing_attributes))
        sys.exit() 
    
    arcpy.AddMessage(r'Input layer has the right attribute columns !')
    
    # Verify that the input exel is ok:
    #..........................................................................
    
    arcpy.AddMessage(r'Veryfying that the input excel file has the right atttribute fields....')

    df_nodes_to_add = pd.read_excel(p4)
    Excel_fields= df_nodes_to_add.columns
    
    Required_Columns_excel = ['OBJECTID','ID_CONN','ID_MCI','NODE','TYPE','STATUS','UTM_East','UTM_North','NAME','Q_m3s']

    
    if not (set(Required_Columns_excel).issubset(Excel_fields)):
        d = {j:i for i,j in enumerate(Required_Columns_excel)}
        missing_attributes = sorted(list((set(Required_Columns_excel) - set(Excel_fields))), key = lambda x: d[x])
        arcpy.AddMessage( r'ERROR 101: Input excel file does not have the right Fields !!')
        arcpy.AddMessage( r'Missing attributes: ' + str(missing_attributes))
        sys.exit() 
    
    arcpy.AddMessage(r'Input excel file has the right attribute columns !')

    List_of_nodes_to_create= df_nodes_to_add['OBJECTID'].tolist()
    Number_of_nodes_to_add= len(List_of_nodes_to_create)
    #..........................................................................
    
    # Clean the temporal GDB before starting:
    #..........................................................................
    arcpy.AddMessage(r'Cleaning Temp GDB, pelase wait... ')

    arcpy.env.workspace = p6

    fc_list = arcpy.ListFeatureClasses()
    tables = arcpy.ListTables()
    ds_list = arcpy.ListDatasets()
    rasters_list = arcpy.ListRasters("*", "GRID")    

    #feature classes
    for fc in fc_list:
        arcpy.Delete_management(fc)
    
    #tables
    for table in tables:
        arcpy.Delete_management(table)
    
    #data sets
    for ds in ds_list:
        arcpy.Delete_management(ds)
    
    #rasters:
    for raster in rasters_list:
        arcpy.Delete_management(raster)    
    arcpy.AddMessage(r'GDB, cleaned succesfully !!')

    #..........................................................................
    
    # Create a copy of the template layer (this layer will hold the result): 
    #......................................................................
    Result_layer = os.path.join(p2,p3)    
    arcpy.CopyFeatures_management(p1, Result_layer)
    #..........................................................................
    
    
    # Delete all the rows in the temaplte layer:
    #..........................................................................
    
    with arcpy.da.UpdateCursor(Result_layer, ['OBJECTID']) as cursor:
      
        for row in cursor:
            cursor.deleteRow()
                
    #..........................................................................
    
    arcpy.AddMessage('Adding ' + str(Number_of_nodes_to_add) + ' node(s) to layer, please wait....')
    
    for node in List_of_nodes_to_create:
        
        # load the attributes of the current node:
        #......................................................................
        New_OBID      = df_nodes_to_add['OBJECTID'][node-1]
        New_IDCONN    = df_nodes_to_add['ID_CONN'][node-1]
        New_MCI       = df_nodes_to_add['ID_MCI'][node-1]   
        New_NODE      = df_nodes_to_add['NODE'][node-1] 
        New_TYPE      = df_nodes_to_add['TYPE'][node-1] 
        New_STATUS    = df_nodes_to_add['STATUS'][node-1]
        New_UTM_East  = df_nodes_to_add['UTM_East'][node-1]
        New_UTM_North = df_nodes_to_add['UTM_North'][node-1]
        New_Name      = df_nodes_to_add['NAME'][node-1]
        New_Q         = df_nodes_to_add['Q_m3s'][node-1]
        #......................................................................
        
        # Add a new row to the layer:
        #......................................................................
        
        # A list of Tuples with the rows to be added to the layer :
        row_values = [(New_OBID,(New_UTM_East, New_UTM_North))]

        # Open an InsertCursor
        cursor = arcpy.da.InsertCursor(Result_layer,['OBJECTID','SHAPE@XY'])
       
        # Insert new row
        # This row will be empty only the shape attributes will have value
        
        for row in row_values:
            cursor.insertRow(row)

        # Delete cursor object
        del cursor
        
        arcpy.AddMessage('Row with new point: '  + New_Name + r' created' )
        #......................................................................
        
        
        # Get the elevation value
        #......................................................................
        
        arcpy.AddMessage( r'Extracting elevation for node ' + str(node) + r' out of ' + str (Number_of_nodes_to_add) )

        # Select the new node
        SQL_expression  = r'"'+ 'OBJECTID' + r'"= ' +  str(New_OBID)
    
        # Create a new TEMP layer to save the selection
        layer_with_new_node_only = arcpy.MakeFeatureLayer_management(Result_layer, r"New_node_only" , SQL_expression)
        
        # save the layer in a new file in the scratch GDB
        Temp_layer_new_node_only = os.path.join(p6,'New_node_' + str(New_IDCONN))
        arcpy.CopyFeatures_management(layer_with_new_node_only, Temp_layer_new_node_only)
    
        Temp_layer_with_elevation =os.path.join(p6, r'elevation_node_' + str(New_IDCONN))
        
        #ExtractValuesToPoints(Input_points_filepath,Input_raster_filepath,Output_points_filepath,"INTERPOLATE","VALUE_ONLY")
        ExtractValuesToPoints(Temp_layer_new_node_only,p5,Temp_layer_with_elevation,"INTERPOLATE","VALUE_ONLY")
        arcpy.AddMessage( r'Elevation for node ' + str(node) + r' out of ' + str (Number_of_nodes_to_add) + r' extracted successfully...' )

        # load layer and extract elevation value ['RASTERVALUE']
        
        List_of_field_names = [f.name for f in arcpy.ListFields(Temp_layer_with_elevation)]    
        List_of_field_names.remove('Shape')    
        # ['OBJECTID', 'ID_CONN', 'ID_MCI', 'NODE', 'TYPE', 'STATUS', 'UTM_East', 'UTM_North', 'Elevation_M', 'NAME', 'Q_m3s', 'RASTERVALU']
       
        NP_Array_Elev =  arcpy.da.FeatureClassToNumPyArray (Temp_layer_with_elevation,List_of_field_names,skip_nulls=False,null_value=-99999)
        df_Elev = pd.DataFrame(NP_Array_Elev, columns = ['RASTERVALU'])
        
        New_Elevation =round( df_Elev['RASTERVALU'].tolist()[0],2)
        #......................................................................
        
        # Add the current node to layer:
        #......................................................................
        
        add_node_attributes_to_layer(Result_layer,
                                     New_OBID,
                                     New_IDCONN,
                                     New_MCI,
                                     New_NODE,
                                     New_TYPE,
                                     New_STATUS,
                                     New_UTM_East,
                                     New_UTM_North,
                                     New_Elevation,
                                     New_Name,
                                     New_Q)
        
        #......................................................................
        
        # Update the lists with attributes of all nodes:
        #......................................................................
        
        list_of_Object_IDs.append(New_OBID)
        list_of_nodes_IDs.append(New_IDCONN)
        list_of_MCI_IDs.append(New_MCI)
        list_of_NODE.append(New_NODE)
        list_of_TYPE.append(New_TYPE)
        list_of_Status.append(New_STATUS)
        list_Coord_X.append(New_UTM_East)
        list_Coord_Y.append(New_UTM_North)
        list_Elevation.append(New_Elevation)
        list_names.append(New_Name)
        list_Q_s.append(New_Q)
        
        #......................................................................
        arcpy.AddMessage( r'Node ' + str(node) + r' out of ' + str (Number_of_nodes_to_add)+ r' added successfully !')
        elapsed_time = (time.time() - time_before_execution_main)
        Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
        Fraction_of_hours, hours =math.modf(Seconds/3600)
        arcpy.AddMessage('Execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )    
        arcpy.AddMessage( r'.....................................')
        
    elapsed_time = (time.time() - time_before_execution_main)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage( r'Layer with new node(s) located at: ' + Result_layer)
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )    
    
    #..........................................................................

    
#..............................................................................
    
###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^                  Functions
###############################################################################

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6)

arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################
