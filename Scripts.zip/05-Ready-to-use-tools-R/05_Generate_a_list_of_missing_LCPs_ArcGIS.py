# -*- coding: utf-8 -*-
"""
Created on Tue May 31 8:00:00 2022

This script helps the user to dientify if the layer with LCPs is missing
any connection based on a layer with all the nodes

This script creates a list of all the possible connections between nodes and
return an excel file with a list of missing conenections 

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""

###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with the Python interpreter of ArcGIS Pro.

# location of python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 


###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#                                                     PACKAGES YOU NEED TO LOAD
###############################################################################
import os
import sys
import time
import math

import openpyxl
from openpyxl import load_workbook, Workbook

import pandas as pd
import arcpy
from arcpy.sa import *
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^    EMD OF PACKAGES YOU NEED TO LOAD
###############################################################################


###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

description_p1 = r'Location of layer with input nodes'
description_p2 = r'Id field nodes (No quotation amrks)'
description_p3 = r'Location of Layer with all LCPs'
description_p4 = r'Id_field_LCPs (No quotation amrks)'
description_p5 = r'Location to save list of missing LCPs'
description_p6 = r'file name of file to save list of missing LCPs (Without extension)'

list_p_descriptions = [description_p1,description_p2,description_p3,description_p4,
                       description_p5,description_p6]

list_of_keys =['p1','p2','p3','p4','p5','p6']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                       Definition of fucntions 
###############################################################################    

#..............................................................................

def main_function(p1,p2,p3,p4,p5,p6):

    time_before_execution = time.time()
    
    # Define function global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    layer_nodes=p1
    ID_Field_nodes=[p2]
    layer_LCPs=p3
    ID_field_LCPs=[p4]
    location_excel_file=p5
    name_excel_file =p6
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    #Debugging:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # layer_nodes = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM_Scratch.gdb\SMARTW_with_new_node_V4'
    # ID_Field_nodes=['ID_CONN']
    # layer_LCPs = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\All_LCPs_V4_with_Attributes'
    # ID_field_LCPs = ['PathDes']
    # location_excel_file = r'E:\SMARTWSMCI_EHD\05-EHD-GIS\SMARTWSMCI_EHD\SMARTWSMCI_EHD_Files'
    # name_excel_file = r'missing_LCPs_2'
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    
    # You need to know how many time you need to run the main rpocess to 
    # split the tasks adequately:
        
    # load the list of Nodes:
    #..........................................................................
    List_of_field_names_nodes_layer = [f.name for f in arcpy.ListFields(layer_nodes)]    
    List_of_field_names_nodes_layer.remove('Shape')   
    
    NP_Array_nodes_attribute_table =  arcpy.da.FeatureClassToNumPyArray (layer_nodes,List_of_field_names_nodes_layer,skip_nulls=False,null_value=-99999)
    df_input_nodes = pd.DataFrame(NP_Array_nodes_attribute_table, columns = List_of_field_names_nodes_layer)
    list_of_nodes_IDs = df_input_nodes[ID_Field_nodes[0]].tolist()
    Number_of_nodes=len(list_of_nodes_IDs)    
    #..........................................................................
    
    # Generate the list of all possible LCP descriptions:
    #..........................................................................
    list_of_LCPs = []
        
    for index_start_points in range(0,Number_of_nodes):
        
        starting_point= list_of_nodes_IDs[index_start_points]
        LCP_description_with_start = r'From-' + str(starting_point) 
        
        # Be careful to create new lists on each iteration otherwise you will delete form  "list_of_nodes_IDs"
        List_of_possible_destination_nodes =  df_input_nodes[ID_Field_nodes[0]].tolist()
        List_of_possible_destination_nodes.remove(starting_point)
        Number_of_ending_points= len(List_of_possible_destination_nodes)
            
        for index_ending_points in range(0,Number_of_ending_points):
            ending_point = List_of_possible_destination_nodes[index_ending_points]
            
            LCP_description = LCP_description_with_start + r'-to-' +str(ending_point)
            
            list_of_LCPs.append(LCP_description)
    #..........................................................................  
    

    # Generate the list of exsiting LCPS descriptions
    #..........................................................................
    
    List_of_field_names_LCPs_layer = [f.name for f in arcpy.ListFields(layer_LCPs)]    
    List_of_field_names_LCPs_layer.remove('Shape')  
    
    NP_Array_LCPs_attribute_table =  arcpy.da.FeatureClassToNumPyArray (layer_LCPs,List_of_field_names_LCPs_layer,skip_nulls=False,null_value=-99999)
    df_LCPs = pd.DataFrame(NP_Array_LCPs_attribute_table, columns =List_of_field_names_LCPs_layer)
    list_of_description_existing_LCPs = df_LCPs[ID_field_LCPs[0]].tolist()
    
    # Find the list of missing LCPs:
    #..........................................................................
    # get the list of missing LCPs:
    d = {j:i for i,j in enumerate(list_of_LCPs)}
    descriptions_missing_LCPs = sorted(list((set(list_of_LCPs) - set(list_of_description_existing_LCPs))), key = lambda x: d[x])
    dict_missing_LCPs={ID_field_LCPs[0]: descriptions_missing_LCPs}
    df_missing_LCPs =pd.DataFrame(data= dict_missing_LCPs)
    #..........................................................................
    
        
    # Write the excel file with the lsit of LCPs:
    #..........................................................................
    file_name =name_excel_file + r'.xlsx'
    file_path_to_save_excel =os.path.join(location_excel_file, file_name)  
    
    df_missing_LCPs.to_excel(file_path_to_save_excel)
        
    # Delete the first column with no name
    work_book = load_workbook(file_path_to_save_excel)
    sheet =work_book['Sheet1']
    sheet.delete_cols(1,1)
    work_book.save(file_path_to_save_excel)
    #..........................................................................
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage(r'There are ' + str(len(descriptions_missing_LCPs))+ r' missing LCPs' )
    arcpy.AddMessage(r'The file the full list of missing LCPs was created at: ' + file_path_to_save_excel)
    arcpy.AddMessage(r'Excel file with summary of missing LCPs created sucessfully' )
    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    
#..............................................................................

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6)

arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################
