# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 13:56:52 2022

This script helps the user to filter and update a polyline layer with LCPs 
using an excel file with data of nodes as the filter criterea

This script creates a new LCP layer only with the LCPs connecting 
the nodes contained in the input excel file. This layer will have the 
attributes of the nodes Sheet introduced as input paramters

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder/VS/PyCharm) 
# with the Python interpreter of an ArcGIS Pro virtual enviroment.

# The default location of the base python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 

###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#                                                     PACKAGES YOU NEED TO LOAD
###############################################################################
import os
import sys
import time
import math

import pandas as pd
import arcpy
from arcpy.sa import *  # ignore this warning, package not supproted by IDEs
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^    EMD OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError # ignore this warning, package not supproted by IDEs
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError # ignore this warning, package not supproted by IDEs
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################
description_p1  = r'Location of Layer with all LCPs'
description_p2  = r'Location of excel file with nodes data:'
description_p3  = r'Name of the excel Sheet with nodes data (No quotation marks)'
description_p4  = r'Column name in excel file with values of ID_CONN:'
description_p5  = r'Column name in excel file with new values of ID_MCI (leave blank to take values from the input layer):'
description_p6  = r'Column name in excel file with new values of NODE (leave blank to take values from the input layer):'
description_p7  = r'Column name in excel file with new values of TYPE (leave blank to take values from the input layer):'
description_p8  = r'Column name in excel file with new values of STATUS (leave blank to take values from the input layer):'
description_p9  = r'Column name in excel file with new values of Elevation_M (leave blank to take values from the input layer):'
description_p10 = r'Column name in excel file with new values of NAME  (leave blank to take values from input the layer):'
description_p11 = r'Column name in excel file with new values of Q_m3s (leave blank to take values from input the layer):'
description_p12 = r'Location to save the new layer with LCPs'
description_p13 = r'file name of the new layer with LCPs:'

list_p_descriptions = [description_p1,description_p2,description_p3,
                       description_p4,description_p5,description_p6,
                       description_p7,description_p8,description_p9,
                       description_p10,description_p11,description_p12,
                       description_p13]

default_values_p1 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\All_LCPs_V4_with_Attributes_corrected'
default_values_p2 = r'R:\03_GISdata\data_Gabriel\04-Tools\02-Python-Scripts\02-Input-files-R\Nodes_ Scenario_Huasco.xlsx'
default_values_p3 = r'Scenario_Huasco'
default_values_p4 = r'ID_CONN'
default_values_p5 = r'ID_MCI'
default_values_p6 = r'NODE'
default_values_p7 = r'TYPE'
default_values_p8 = r'STATUS'
default_values_p9 = r'Elevation_M'
default_values_p10 = r'NAME'
default_values_p11 = r'Reduced_Q_m3s'
default_values_p12 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM_Scratch.gdb'
default_values_p13 = r'LCPs_nodes_Huasco_scenario'

list_of_keys =['p1','p2','p3','p4','p5','p6','p7','p8','p9','p10','p11','p12','p13']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                          Definition of Main() 
###############################################################################    

#..............................................................................

def main_function(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13):
    
    time_before_execution = time.time()
    
    #Debugging:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # p1= default_values_p1
    # p2= default_values_p2
    # p3= default_values_p3
    # p4= default_values_p4
    # p5= default_values_p5
    # p6= default_values_p6
    # p7= default_values_p7
    # p8=default_values_p8
    # p9=default_values_p9
    # p10=default_values_p10
    # p11=default_values_p11
    # p12=default_values_p12
    # p13=default_values_p13
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    arcpy.AddMessage(r'p1 =' + str(p1))
    arcpy.AddMessage(r'p2 =' + str(p2))
    arcpy.AddMessage(r'p3 =' + str(p3))
    arcpy.AddMessage(r'p4 =' + str(p4))
    arcpy.AddMessage(r'p5 =' + str(p5))
    arcpy.AddMessage(r'p6 =' + str(p6))
    arcpy.AddMessage(r'p7 =' + str(p7))
    arcpy.AddMessage(r'p8 =' + str(p8))
    arcpy.AddMessage(r'p9 =' + str(p9))
    arcpy.AddMessage(r'p10 =' + str(p10))
    arcpy.AddMessage(r'p11 =' + str(p11))
    arcpy.AddMessage(r'p12 =' + str(p12))
    arcpy.AddMessage(r'p13 =' + str(p13))
    
    # Define global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    layer_LCPs=p1
    Excel_file=p2
    Excel_sheeet_name=p3
    ID_field_nodes_excel=p4
    
    if(p5 == r'' or p5 == r'  ' or p5 == r' ' or p5 == r'-' or p5 == r'NO' or p5 == r'no'):
        update_ID_MCI = 'no'
    else:
        update_ID_MCI = 'yes'
        ID_MCI_excel  = p5
    
    if(p6 == r'' or p6 == r'  ' or p6 == r' ' or p6 == r'-' or p6 == r'NO' or p6 == r'no'):
        update_NODE = 'no'
    else:
        update_NODE = 'yes'
        NODE_excel  = p6
    
    if(p7 == r'' or p7 == r'  ' or p7 == r' ' or p7 == r'-' or p7 == r'NO' or p7 == r'no'):
        update_TYPE = 'no'
    else:
        update_TYPE = 'yes'
        TYPE_excel  = p7
    
    if(p8 == r'' or p8 == r'  ' or p8 == r' ' or p8 == r'-' or p8 == r'NO' or p8 == r'no'):
        update_STATUS = 'no'
    else:
        update_STATUS = 'yes'
        STATUS_excel  = p8
    
    if(p9 == r'' or p9 == r'  ' or p9 == r' ' or p9 == r'-' or p9 == r'NO' or p9 == r'no'):
        update_Elevation_M = 'no'
    else:
        update_Elevation_M = 'yes'
        Elevation_M_excel  = p9
    
    if(p10 == r'' or p10 == r'  ' or p10 == r' ' or p10 == r'-' or p10 == r'NO' or p10 == r'no'):
        update_NAME = 'no'
    else:
        update_NAME = 'yes'
        NAME_excel  = p10
    
    if(p11 == r'' or p11 == r'  ' or p11 == r' ' or p11 == r'-' or p11 == r'NO' or p11 == r'no'):
        update_Q_m3s = 'no'
    else:
        update_Q_m3s = 'yes'
        Q_m3s_excel  = p11
    
    list_of_column_Values_excel = [p5,p6,p7,p8,p9,p10,p11]
    
    list_of_keys_LCP_fields = [ r'ID_MCI', r'NODE',
                                r'TYPE', r'STATUS',
                                r'Elevation_M', r'NAME',
                                r'Q_m3s']
    
    list_fields_conds       = [update_ID_MCI, update_NODE,
                               update_TYPE, update_STATUS,
                               update_Elevation_M, update_NAME,
                               update_Q_m3s]     
    
    dictionary_fields_to_update  =dict(zip(list_of_keys_LCP_fields, list_fields_conds)) 
    dict_GIS_2_excel =dict(zip(list_of_keys_LCP_fields, list_of_column_Values_excel))  
    
    # Print the equivalence of the GIS field names and Excel names:
    
    for  field in list_of_keys_LCP_fields:
        arcpy.AddMessage(r' GIS field for ' + field + r' named :' + dict_GIS_2_excel.get(field)+ r' in the Excel File')
        
    location_results  = p12
    results_name_file = p13
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    arcpy.AddMessage(r'Loading layer with LCPs to be filtered, please wait....')
    
    # Load layer with all LCPs:
    #..........................................................................
    List_of_field_names_LCPs_layer = [f.name for f in arcpy.ListFields(layer_LCPs)]    
    List_of_field_names_LCPs_layer.remove('Shape')   
    
    NP_Array_LCPs_attribute_table =  arcpy.da.FeatureClassToNumPyArray (layer_LCPs,List_of_field_names_LCPs_layer,skip_nulls=False,null_value=-99999)
    df_input_LCPs = pd.DataFrame(NP_Array_LCPs_attribute_table, columns = List_of_field_names_LCPs_layer)
    list_of_PathDes = df_input_LCPs[ r'PathDes'].tolist()
    Number_of_LCPs_input_layer=len(list_of_PathDes) 
    #..........................................................................

    # Validate the input LCPs layer:
    #..........................................................................
    
    list_of_Required_Field_Names =  [ 'OBJECTID', 'PathDes', 'OriginID', 'DestinID', 
                                      'PathCost', 'EnvRes', 'Delta_H', 'Shape_Length',
                                      'O_MCI', 'O_type', 'O_Node', 'O_elev', 'O_status', 'O_name', 'O_Qm3s',
                                      'D_MCI', 'D_type', 'D_Node', 'D_elev', 'D_status', 'D_name', 'D_Qm3s']
    
    difference_in_attributes =    list(set(List_of_field_names_LCPs_layer).difference(list_of_Required_Field_Names))
    
    missing_attributes =[]
    
    for attribute_name in difference_in_attributes:
        if (attribute_name in list_of_Required_Field_Names):
            missing_attributes.append(attribute_name)

    
    if  (len(missing_attributes)> 0):
        arcpy.AddMessage( r'The field(s) {} are missing in the input nodes layer'.format(missing_attributes) ) 
        sys.exit() 
    
    arcpy.AddMessage(r'Input layer with LCPs loaded successfully !')

    #..........................................................................
    
    
    arcpy.AddMessage(r'Loading file with nodes to use as a filter, please wait....')
    
    # Load the excel with the list of Nodes to use as a filter:
    #..........................................................................
    try:
        df_excel_file= pd.read_excel(Excel_file, sheet_name=Excel_sheeet_name)
        list_column_names_excel_File = df_excel_file.columns
        Number_of_columns_loaded = len(list_column_names_excel_File)
        arcpy.AddMessage( r' Excel file with ' + str(Number_of_columns_loaded) + r' columns was loaded sucessfully')
    except ValueError:
        arcpy.AddMessage( r"Oops! ")
        arcpy.AddMessage( r'ERROR 101: you have introduced the wrong file location or the wrong Sheet name,  Try again...')
        arcpy.AddMessage( r'Attempted file path: '  + Excel_file)
        arcpy.AddMessage( r'Attempted Sheet name: ' + Excel_sheeet_name)
    #.......................................................................... 
    
    #..........................................................................
    
    arcpy.AddMessage(r'Creating list of LCPs to extract')
    
    # Use node IDs to create a list of LCP descriptions:
    #..........................................................................
    list_of_node_Ids = df_excel_file[ID_field_nodes_excel].tolist()
    
    list_of_unique_ids = list(set(list_of_node_Ids))
    
    if ( len(list_of_node_Ids) != len(list_of_unique_ids)):
        arcpy.AddMessage( r'ERROR 102: you have introduced duplicated rows in the excel file,  Try again...')
        sys.exit("ERROR 102, code execution interrupted")
        
    list_of_LCPs_to_extract = []
        
    for current_point in list_of_node_Ids:
        
        starting_point= current_point
        LCP_description_root = r'From-' + str(starting_point) 
        
        # Be careful to create new lists on each iteration otherwise you will delete form  "list_of_node_Ids"
        List_of_possible_destination_nodes = list_of_node_Ids.copy()
        List_of_possible_destination_nodes.remove(starting_point)
            
        for current_ending_point in List_of_possible_destination_nodes:
            
            LCP_description = LCP_description_root + r'-to-' +str(current_ending_point)
            
            list_of_LCPs_to_extract.append(LCP_description)
            
    number_of_LCPs_to_extract =len(list_of_LCPs_to_extract)
    
    LCPs_to_delete = list(set(list_of_PathDes).difference(list_of_LCPs_to_extract))
    
    #..........................................................................  
    
    arcpy.AddMessage(r'Extracting LCPs from input layer, please wait....')
    

    #Copy input layer with all LCPs :
    #..........................................................................
    file_path_result_layer = os.path.join(location_results, results_name_file)
    arcpy.CopyFeatures_management(layer_LCPs, file_path_result_layer)
    #..........................................................................
    
    # Delete the rows that are not associated with the input nodes (filter LCPs):
    #..........................................................................
    
    count=0
    Number_of_rows_to_delete = Number_of_LCPs_input_layer-number_of_LCPs_to_extract
    
    # These variables are defined for smart execution control 
    # Only 10 execution check points will be printed on console
    residual_for_progress = int(Number_of_rows_to_delete/10)
    
    if(residual_for_progress == 0):
        residual_for_progress=1
    
    with arcpy.da.UpdateCursor(file_path_result_layer, ['PathDes']) as cursor:
      for row in cursor:
          current_LCP = row[0]
          count=count+1
          if current_LCP in LCPs_to_delete:
              cursor.deleteRow()
              if(count%residual_for_progress == 0):
                  arcpy.AddMessage( r'Row ' + str(count) +  r' out of ' + str(Number_of_rows_to_delete)+' deleted')
                  elapsed_time = (time.time() - time_before_execution)
                  Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
                  Fraction_of_hours, hours =math.modf(Seconds/3600)
                  arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
          
    #..........................................................................
    
    # Update LCPs attributes using the excel columns:
    #--------------------------------------------------------------------------
    
    root_fields_to_update= [key for key,value in dictionary_fields_to_update.items() if 'yes' in value]
     
    for i in range(len(root_fields_to_update)):
        if (root_fields_to_update[i]== 'ID_MCI'):
            root_fields_to_update[i] = r'MCI'
        elif (root_fields_to_update[i]== 'NODE'):
            root_fields_to_update[i] = r'Node'
        elif (root_fields_to_update[i]== 'TYPE'):
            root_fields_to_update[i] = r'type'    
        elif (root_fields_to_update[i]== 'STATUS'):
            root_fields_to_update[i] = r'status'   
        elif (root_fields_to_update[i]== 'Elevation_M'):
            root_fields_to_update[i] = r'elev' 
        elif (root_fields_to_update[i]== 'NAME'):
            root_fields_to_update[i] = r'name'
        elif (root_fields_to_update[i]== 'Q_m3s'):
            root_fields_to_update[i] = r'Qm3s'
    
    
    # Add the prefix to the columns to modify        

    fields_attributes_O_nodes_to_update=  [ r'O_' + val for val in root_fields_to_update]  
    fields_attributes_D_nodes_to_update=  [ r'D_' + val for val in root_fields_to_update]  
    
    complete_list_of_attributes_to_update = fields_attributes_O_nodes_to_update + fields_attributes_D_nodes_to_update 
    
    arcpy.AddMessage(r'These are the atttributes that will be updated:')
    
    for attribute_name in complete_list_of_attributes_to_update:
        arcpy.AddMessage(attribute_name)
    
    # You will load all the editable attributes to the cursor
        
    All_possible_fields_to_update = ['PathDes', 'O_MCI', 'O_Node', 'O_type', 'O_status', 'O_elev', 'O_name', 'O_Qm3s',
                                     'D_MCI', 'D_Node','D_type',  'D_status', 'D_elev', 'D_name', 'D_Qm3s']
    
    LCPs_updated=1
    Number_of_LCPs_to_update = number_of_LCPs_to_extract
    
    residual_for_progress = int(Number_of_LCPs_to_update/10)
    
    if(residual_for_progress == 0):
        residual_for_progress=1
    
    with arcpy.da.UpdateCursor(file_path_result_layer, All_possible_fields_to_update) as cursor:
      
        for row in cursor:
            
            description_current_LCP = row[0]
            
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            # Update O attributes:
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            
            if type(df_excel_file[ID_field_nodes_excel].tolist()[0]) == int: 
                ID_O_node = int(description_current_LCP.split(r'-')[1])
            else:
                ID_O_node = description_current_LCP.split(r'-')[1]
                
            # Here you Get the row with the excel attributes of origin node for the current LCP:  
            df_row_O = df_excel_file.loc[ df_excel_file[ID_field_nodes_excel] == ID_O_node]
            
            if (update_ID_MCI == 'yes'):
                O_MCI  = df_row_O[ID_MCI_excel].values[0]
                if (type(O_MCI) == str):
                    row[1] = O_MCI
           
            if (update_NODE == 'yes'):
                O_Node  =df_row_O[NODE_excel].values[0]
                if (type(O_Node) == str):
                    row[2] = O_Node   
               
            if (update_TYPE == 'yes'):
                O_type  =df_row_O[TYPE_excel].values[0]
                if (type(O_type) == str):
                    row[3] = O_type    
            
            if (update_STATUS == 'yes'):
                O_status  =df_row_O[STATUS_excel].values[0]
                if (type(O_status) == str):
                    row[4] = O_status        
            
            if (update_Elevation_M == 'yes'):
                O_elev  =float(df_row_O[Elevation_M_excel].values[0])
                if not (math.isnan(O_elev)):
                    row[5] = O_elev    
            
            if (update_NAME == 'yes'):
                O_name  =df_row_O[NAME_excel].values[0]
                if (type(O_name) == str):
                    row[6] = O_name    
            
            if (update_Q_m3s == 'yes'):
                O_Qm3s  =float(df_row_O[Q_m3s_excel].values[0])
                if not (math.isnan(O_Qm3s)):
                    row[7] = O_Qm3s   
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                  
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
            # Update D attributes:
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::      
            
            if type(df_excel_file[ID_field_nodes_excel].tolist()[0]) == int: 
                ID_D_node = int(description_current_LCP.split(r'-')[3])
            else:
                ID_D_node = description_current_LCP.split(r'-')[3]
                
            # Here you Get the row with the Origin Node attributes of the current LCP:
            
            df_row_D = df_excel_file.loc[ df_excel_file[ID_field_nodes_excel] == ID_D_node]
    
            if (update_ID_MCI == 'yes'):
                D_MCI  = df_row_D[ID_MCI_excel].values[0]
                if (type(D_MCI) == str):
                    row[8] = D_MCI
           
            if (update_NODE == 'yes'):
                D_Node  =df_row_D[NODE_excel].values[0]
                if (type(D_Node) == str):
                    row[9] = D_Node   
               
            if (update_TYPE == 'yes'):
                D_type  =df_row_D[TYPE_excel].values[0]
                if (type(D_type) == str):
                    row[10] = D_type    
            
            if (update_STATUS == 'yes'):
                D_status  =df_row_D[STATUS_excel].values[0]
                if (type(D_status) == str):
                    row[11] = D_status        
            
            if (update_Elevation_M == 'yes'):
                D_elev  =float(df_row_D[Elevation_M_excel].values[0])
                if not (math.isnan(D_elev)):
                    row[12] = D_elev    
            
            if (update_NAME == 'yes'):
                D_name  =df_row_D[NAME_excel].values[0]
                if (type(D_name) == str):
                    row[13] = D_name    
            
            if (update_Q_m3s == 'yes'):
                D_Qm3s  =float(df_row_D[Q_m3s_excel].values[0])
                if not (math.isnan(D_Qm3s)):
                    row[14] = D_Qm3s           
            
            if(LCPs_updated%residual_for_progress == 0):
                arcpy.AddMessage( r'Row ' + str(LCPs_updated) +  r' out of ' + str(Number_of_LCPs_to_update) + ' updated')
                elapsed_time = (time.time() - time_before_execution)
                Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
                Fraction_of_hours, hours =math.modf(Seconds/3600)
                arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
            LCPs_updated =LCPs_updated +1
            cursor.updateRow(row)
            #::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                
    #--------------------------------------------------------------------------
     
    # Print execution time:    
    #..........................................................................
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage(r'The LCPs layer located at: ' + file_path_result_layer)
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    #..........................................................................
       
#..............................................................................

###############################################################################
#      ^      ^      ^      ^      ^      ^      ^      ^  Definition of Main() 
###############################################################################   

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)
p7 = arcpy.GetParameterAsText(6)
p8 = arcpy.GetParameterAsText(7)
p9 = arcpy.GetParameterAsText(8)
p10 = arcpy.GetParameterAsText(9)
p11 = arcpy.GetParameterAsText(10)
p12 = arcpy.GetParameterAsText(11)
p13 = arcpy.GetParameterAsText(12)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################

