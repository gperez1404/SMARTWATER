# -*- coding: utf-8 -*-
"""
This script receives as input a layer with a set of LCPs and converts it to 
an excel file with pivot matrices to execute MIP/PuLP/Gurobi optimisation algorithms

This script allows the user to specify the columns names of a LCPs layer to 
create an excel file with different Sheets containing the following objects:
    
    1: A dictionary with the demand nodes for the LCPs of the input layer
        demand_dict_df = {Node_number_ID_MIP: Node_ID_GIS}
        
    2: A dictionary with the supply nodes  for the LCPs of the input layer
        capacity_dict_df = {Node_number_ID_MIP: Node_ID_GIS}    

    3: A pivot table with the 'Shape_length' for the LCPs of the input layer
        
    4: A pivot table with the 'Delta_H' for the LCPs of the input layer
    
    5: A pivot table with the 'Enviromental cost' for the LCPs of the input layer
         
  
@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""

###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with the Python interpreter of ArcGIS Pro.

# location of python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 


###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#%%                                                   PACKAGES YOU NEED TO LOAD
###############################################################################

import os
import sys
import time
import math

import pandas as pd
import arcpy
from arcpy.sa import *

###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^   END OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

description_p1  = r'Input layer with LCPs:'
description_p2  = r'Name of the field with path distance (Shape_Length by default):'
description_p3  = r'Name of the field with elevation difference (Delta_H by default):'
description_p4  = r'Name of the field with Enviromental cost (EnvRes by default):'
description_p5  = r'Location to save results'
description_p6  = r'Name of the Excel file with MIP inputs (No extension required):'

list_p_descriptions = [description_p1,description_p2,description_p3,
                       description_p4,description_p5,description_p6]

list_of_keys =['p1','p2','p3','p4','p5','p6']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

default_p1 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\Scenario_41_nodes.gdb\LCPs_41_nodes'

default_p5 = r'R:\03_GISdata\data_Gabriel\04-Tools\02-Python-Scripts\02-Input-files-R\Inputs-Gurobi-Desktop'
default_p6 = r'Inputs_Gurobi_41_nodes'

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                          Definition of Main() 
###############################################################################    

#..............................................................................

def main(p1,p2,p3,p4,p5,p6):
    
    # Debugging:
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # p1 =default_p1
    # p2 =default_p2 
    # p3 =default_p3
    # p4 =default_p4
    # p5 =default_p5
    # p6 =default_p6
 
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    time_before_execution = time.time()
    
    arcpy.AddMessage(r'p1 =' + str(p1))
    arcpy.AddMessage(r'p2 =' + str(p2))
    arcpy.AddMessage(r'p3 =' + str(p3))
    arcpy.AddMessage(r'p4 =' + str(p3))
    arcpy.AddMessage(r'p5 =' + str(p3))
    arcpy.AddMessage(r'p6 =' + str(p3))
    
    # Define global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    input_layer_LCPs = p1
    Fields_origin_nodes                = ['O_MCI', 'O_type', 'O_Node', 'O_elev', 'O_status', 'O_name', 'O_Qm3s']
    Fields_destination_nodes           = ['D_MCI', 'D_type', 'D_Node', 'D_elev', 'D_status', 'D_name', 'D_Qm3s']
    LCPs_des                           = r'PathDes'
    Column_LCPs_distance               = p2
    Column_LCPs_altitude               = p3
    Column_LCPs_EnvRes                 = p4
    Column_name_node_type_origin       = r'O_Node'
    Column_name_node_type_destination  = r'D_Node'
    Column_name_Q_origin               = r'O_Qm3s'
    Column_name_Q_destiantion          = r'D_Qm3s'
    file_name = p6 + r'.xlsx'
    file_path_results = os.path.join(p5, file_name )
     
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # Validate input paramters:
    #..........................................................................
    
    # strip any quotation marks or unintended spaces:
    Column_LCPs_distance = Column_LCPs_distance.strip(r'"').strip(r'"').strip(r' ')
    Column_LCPs_altitude = Column_LCPs_altitude.strip(r'"').strip(r'"').strip(r' ')
    Column_LCPs_EnvRes   = Column_LCPs_EnvRes.strip(r'"').strip(r'"').strip(r' ')
    
    if(Column_LCPs_distance == r'-' or Column_LCPs_distance == r''):
        Column_LCPs_distance = r'Shape_Length'
    
    if(Column_LCPs_altitude == r'-' or Column_LCPs_altitude == r''):
        Column_LCPs_altitude = r'Delta_H'
    
    if(Column_LCPs_EnvRes == r'-' or Column_LCPs_EnvRes == r''):
         Column_LCPs_EnvRes = r'EnvRes'
    #..........................................................................
    
    # Verify the input layer has the right attributes:
    #..........................................................................    
    
    List_of_field_names_input_layer = [f.name for f in arcpy.ListFields(input_layer_LCPs)]    
    List_of_field_names_input_layer.remove('Shape')   
    
    list_of_attributes_manually_introduced_by_user = [Column_LCPs_distance,Column_LCPs_altitude,Column_LCPs_EnvRes]
    
    list_of_required_Fields= ['OBJECTID','PathDes','OriginID','DestinID',
                              'PathCost','EnvRes','Delta_H','O_MCI','O_type',
                              'O_Node','O_elev','O_status','O_name','O_Qm3s',
                              'D_MCI','D_type','D_Node','D_elev','D_status',
                              'D_name','D_Qm3s','Shape_Length']
    
    if not (set(list_of_required_Fields).issubset(List_of_field_names_input_layer)):
        d = {j:i for i,j in enumerate(list_of_required_Fields)}
        missing_attributes = sorted(list((set(list_of_required_Fields) - set(List_of_field_names_input_layer))), key = lambda x: d[x])
        arcpy.AddMessage( r'ERROR 101: Wrong input layer or the input layer does not have the right Fields !!')
        arcpy.AddMessage( r'Missing attributes: ' + str(missing_attributes))
        sys.exit() 
    
    if not (set(list_of_attributes_manually_introduced_by_user).issubset(List_of_field_names_input_layer)):
            d = {j:i for i,j in enumerate(list_of_attributes_manually_introduced_by_user)}
            missing_attributes = sorted(list((set(list_of_attributes_manually_introduced_by_user) - set(List_of_field_names_input_layer))), key = lambda x: d[x])
            arcpy.AddMessage( r'ERROR 101: WThe input layer does not ahve the have attribute Fields specified by teh user !!')
            arcpy.AddMessage( r'Missing attributes: ' + str(missing_attributes))
            sys.exit() 
            
    
    arcpy.AddMessage(r'Input layer has the right attributes !')
    #..........................................................................
    

    # Load layer with LCPs:
    #..........................................................................
    
    NP_Array_attribute_table =  arcpy.da.FeatureClassToNumPyArray (input_layer_LCPs,List_of_field_names_input_layer,skip_nulls=False,null_value=-99999)
    df_attribute_table = pd.DataFrame(NP_Array_attribute_table, columns = List_of_field_names_input_layer)
    list_of_LCPs_IDs = df_attribute_table[LCPs_des].tolist()
    
    origin_nodes_list = list(set( [ID_des.split(r'-')[1] for ID_des in list_of_LCPs_IDs]))
    destiantion_nodes_list = list(set( [ID_des.split(r'-')[3] for ID_des in list_of_LCPs_IDs]))
    
    list_of_nodes_IDs = list(set(origin_nodes_list + destiantion_nodes_list))
    list_of_nodes_IDs= list(map(int, list_of_nodes_IDs))
    Total_number_of_nodes = len(list_of_nodes_IDs)
    
    arcpy.AddMessage('Total number of nodes:' +  str(Total_number_of_nodes))
    
    #..........................................................................
    
    # Create a df with the information of origin nodes:
    #--------------------------------------------------------------------------
    df_origin_nodes = df_attribute_table.copy()
    
    fields_to_keep   = ['OriginID']  +  Fields_origin_nodes
    fields_to_delete = [item for item in List_of_field_names_input_layer if item not in fields_to_keep]
    
    df_origin_nodes.drop(fields_to_delete, inplace=True, axis=1)
    
    df_origin_nodes.rename(columns={'OriginID':'nodeID',
                                    Column_name_node_type_origin: 'Node',
                                    Column_name_Q_origin: 'Qm3s'},
                           inplace=True)
    
    # here you delete all the repeated rows:
    df_origin_nodes.drop_duplicates(subset=['nodeID'], inplace=True)
    
    #--------------------------------------------------------------------------
    
    # Create a df with the information of destination nodes:
    #--------------------------------------------------------------------------
    df_destination_nodes = df_attribute_table.copy()
    
    fields_to_keep = ['DestinID'] + Fields_destination_nodes
    fields_to_delete = [item for item in List_of_field_names_input_layer if item not in fields_to_keep]
    
    df_destination_nodes.drop(fields_to_delete, inplace=True, axis=1)
    
    df_destination_nodes.rename(columns={'DestinID':'nodeID', 
                                         Column_name_node_type_destination: 'Node',
                                         Column_name_Q_destiantion: 'Qm3s'}, inplace=True)
    
    df_destination_nodes.drop_duplicates(subset=['nodeID'], inplace=True)
    
    #--------------------------------------------------------------------------
    
    # Merge the dfs with nodes info:
    #--------------------------------------------------------------------------
    df_origin_nodes_to_merge      = df_origin_nodes.copy()
    df_destination_nodes_to_merge = df_destination_nodes.copy()
    
    fields_to_keep = ['nodeID', 'Node' , 'Qm3s']
    
    fields_ori = df_origin_nodes_to_merge.columns
    
    fields_to_delete =  [item for item in fields_ori if item not in fields_to_keep]
    df_origin_nodes_to_merge.drop(fields_to_delete, inplace=True, axis=1)
    
    fields_des = df_destination_nodes_to_merge.columns    
     
    fields_to_delete = [item for item in fields_des if item not in fields_to_keep]
    df_destination_nodes_to_merge.drop(fields_to_delete, inplace=True, axis=1)
    
    df_nodes_info = pd.concat([df_origin_nodes_to_merge,df_destination_nodes_to_merge ], ignore_index=True)
    df_nodes_info.drop_duplicates(subset=['nodeID'], inplace=True)
    
    #--------------------------------------------------------------------------
    
    
    # Generate the dictionary of nodes:
    #--------------------------------------------------------------------------
    
    # Get df with the attributes of nodes with NODE == D:
    df_demnad_nodes = df_nodes_info[(df_nodes_info["Node"] == r'D')]
    
    # Get df with the attributes of nodes with  NODE== S:
    df_supply_nodes = df_nodes_info[(df_nodes_info["Node"] == r'S')]
    
    # Re-order the dfs using the Node IDs:
    df_demnad_nodes.sort_values(by=['nodeID'], ascending=[True],inplace=True)
    df_supply_nodes.sort_values(by=['nodeID'], ascending=[True],inplace=True)
    
    list_demand_nodes = df_demnad_nodes['nodeID'].tolist()
    list_supply_nodes = df_supply_nodes['nodeID'].tolist()
        
    # Generate the new Number_IDs for the MIP inputs:   

    MIP_IDs_supply_nodes = list(range(0,len(list_supply_nodes)))
    MIP_IDs_demand_nodes = list(range(len(list_supply_nodes), len(list_supply_nodes) + len(list_demand_nodes)))
    
    list_of_keys_supply = [str(node) for node in list_supply_nodes]
    list_of_keys_demand = [str(node) for node in list_demand_nodes]
    
    # Create the dictionary for Supply nodes (capcaity):
    dict_supply_nodes = dict(zip(list_of_keys_supply, MIP_IDs_supply_nodes)) 
    
    # Create the dictionary for demand nodes (demand):
    dict_demand_nodes = dict(zip(list_of_keys_demand, MIP_IDs_demand_nodes)) 
    
    #--------------------------------------------------------------------------
    
    # Generate inputs for Optimisation:
    #--------------------------------------------------------------------------    
        
    df_MIP_values = df_attribute_table.copy()
    
    # Use the dictionaries to re-map the ID values
    
    list_of_keys_supply_numbers =  [node for node in list_supply_nodes]
    list_of_keys_demand_numbers =  [node for node in list_demand_nodes]
    
    list_of_keys_numbers = list_of_keys_demand_numbers + list_of_keys_supply_numbers
    list_of_MIP_IDs      = MIP_IDs_demand_nodes + MIP_IDs_supply_nodes
    
    dict_nodes_numbers = dict(zip(list_of_keys_numbers,list_of_MIP_IDs)) 
        
    df_MIP_values=df_MIP_values.replace({"OriginID": dict_nodes_numbers})
    df_MIP_values=df_MIP_values.replace({"DestinID": dict_nodes_numbers})

    
    # sort the df with LCPs attributes using the new order : nodes capacity (supply) > nodes demand
    
    df_MIP_values.sort_values(by=['DestinID'], ascending=[True],inplace=True)
    df_MIP_values.sort_values(by=['OriginID'], ascending=[True],inplace=True)
    
    # Generate the pivot table (matrix) with the Shape_lenght between nodes (distance)
    distance = pd.pivot_table(df_MIP_values,index='DestinID',columns='OriginID',values=Column_LCPs_distance)
    
    # Generate the pivot table (matrix) with the DElta H between nodes (altitude)
    altitude = pd.pivot_table(df_MIP_values,index='DestinID',columns='OriginID',values=Column_LCPs_altitude)
    
    # Generate the pivot table (matrix) with the Environmental Restriction (EnvRes/ env_restric)
    env_restric = pd.pivot_table(df_MIP_values,index='DestinID',columns='OriginID',values=Column_LCPs_EnvRes)
    
    capacity_dict_df = pd.DataFrame(dict_supply_nodes.items())
    demand_dict_df   = pd.DataFrame(dict_demand_nodes.items())
    
    capacity_dict_df.columns = ['GIS_ID','MIP_ID']
    demand_dict_df.columns   = ['GIS_ID','MIP_ID']
    
    GIS_ids_capacity = capacity_dict_df['GIS_ID']
    GIS_ids_demand   = demand_dict_df['GIS_ID']  
    
    capacity_dict_df.drop(labels=['GIS_ID'], axis=1, inplace = True)
    demand_dict_df.drop(labels=['GIS_ID'], axis=1, inplace = True)
    
    capacity = capacity_dict_df.copy()
    demand   = demand_dict_df.copy()
    
    capacity_Qs = df_supply_nodes['Qm3s'].tolist()
    demand_Qs   = df_demnad_nodes['Qm3s'].tolist()
    
    capacity.insert(1, 'Q',capacity_Qs)
    demand.insert(1, 'Q',demand_Qs)
    
    capacity=  capacity.transpose()
    demand =   demand.transpose()
    
    capacity_dict_df.insert(1, 'GIS_ID', GIS_ids_capacity)
    demand_dict_df.insert(1, 'GIS_ID', GIS_ids_demand)
    
    nodes_dict_df = pd.concat([capacity_dict_df,demand_dict_df ], ignore_index=True)
    nodes_dict_df = nodes_dict_df.transpose()
     
    #--------------------------------------------------------------------------
    
    # Write the results in an excel file:
    #--------------------------------------------------------------------------
        
    with pd.ExcelWriter(file_path_results) as writer:
        distance.to_excel(writer, sheet_name='distance', index=False)
        altitude.to_excel(writer, sheet_name = 'altitude',index=False)
        env_restric.to_excel(writer, sheet_name = 'env_restric',index=False)
        capacity.to_excel(writer, 'capacity', index=False, header=False)
        demand.to_excel(writer, 'demand', index=False, header=False)
        nodes_dict_df.to_excel(writer, 'nodes_dictionary',index=False, header=False)       
    
    #--------------------------------------------------------------------------
        
    arcpy.AddMessage('Result file located at:' +  file_path_results)
    
    # Print execution time in console:
    #..........................................................................
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    #..........................................................................    
    
#..............................................................................

###############################################################################
#      ^      ^      ^      ^      ^      ^      ^      ^  Definition of Main() 
###############################################################################   

###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main(p1,p2,p3,p4,p5,p6)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################