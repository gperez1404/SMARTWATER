# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 8:00:00 2022

This script helps the user to filter a polyline layer with LCPs using attribute
values to filter using Select by attribute

This scripts certes a new LCP layer only with the LCPs (Paths) connectecing 
the nodes introduced as parameters

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with the Python interpreter of ArcGIS Pro.

# location of python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 


###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#                                                     PACKAGES YOU NEED TO LOAD
###############################################################################
import os
import sys
import time
import math

import openpyxl
from openpyxl import load_workbook, Workbook

import pandas as pd
import arcpy
from arcpy.sa import *
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^    EMD OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    raise LicenseError
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    raise LicenseError
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

description_p1 = r'Location of input layer with LCPs'
description_p2 = r'Filter for maximum Path lenght value (leave blank if not to be used as filter):' # Filter 1 
description_p3 = r'Filter for maximum PathCost value (leave blank if not to be used as filter):'    # Filter 2
description_p4 = r'Filter for maximum EnvR value (leave blank if not to be used as filter):'        # Filter 3
description_p5 = r'Filter for maximum Delta H value (leave blank if not to be used as filter):'     # Filter 4
description_p6 = r'Location to save the LCPs with resutls (GeoDatabase)'
description_p7 = r'file name of file to save the new layer with LCPs'

list_p_descriptions = [description_p1,description_p2,description_p3,
                       description_p4,description_p5,description_p6,
                       description_p7]

default_values_p1 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\All_LCPs_V4_with_Attributes_corrected'
default_values_p2 = 200000 # Filter 1
default_values_p3 = r''    # Filter 2
default_values_p4 = r''    # Filter 3
default_values_p5 = 2000   # Filter 4
default_values_p6 = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Scratch.gdb'
default_values_p7 = r'Results_LCPs_filter'

list_of_keys =['p1','p2','p3','p4','p5','p6','p7']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

#%%
###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################


###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)
p7 = arcpy.GetParameterAsText(6)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                          Definition of Main() 
###############################################################################    

#..............................................................................

def main_function(p1,p2,p3,p4,p5,p6,p7):
    
    # #Debugging:
    # #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    # p1  = default_values_p1
    # p2  = default_values_p2
    # p3  = default_values_p3
    # p4  = default_values_p4 
    # p5  = default_values_p5
    # p6  = default_values_p6
    # p7  = default_values_p7
    # #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    time_before_execution = time.time()
    
    # Define global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    layer_LCPs        = p1
    location_results  = p6
    results_name_file = p7
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # load the LCPs layer:
    #..........................................................................
    List_of_field_names_LCPs_layer = [f.name for f in arcpy.ListFields(layer_LCPs)]    
    List_of_field_names_LCPs_layer.remove('Shape')   
    
    NP_Array_LCPs_attribute_table =  arcpy.da.FeatureClassToNumPyArray (layer_LCPs,List_of_field_names_LCPs_layer,skip_nulls=False,null_value=-99999)
    df_input_LCPs = pd.DataFrame(NP_Array_LCPs_attribute_table, columns = List_of_field_names_LCPs_layer)
    
    list_ShapeLength = df_input_LCPs['Shape_Length'].tolist()
    list_PathCost = df_input_LCPs['PathCost'].tolist()
    list_EnvR = df_input_LCPs['EnvRes'].tolist()
    list_DeltaH = df_input_LCPs['Delta_H'].tolist()
    #..........................................................................
    
    # Define the values to filter the LCP layer:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
    
    # Filter 1:
    if not ( p2 == r''):
        value_to_filter_PathLenght = float(p2)
    else:
        value_to_filter_PathLenght = max(list_ShapeLength)
    
    # Filter 2:    
    if not ( p3 == r''):
        value_to_filter_PathCost = float(p3)
    else:
        value_to_filter_PathCost = max(list_PathCost)
    
    # Filter 3:   
    if not ( p4 == r''):
        value_to_filter_EnvR = float(p4)
    else:
        value_to_filter_EnvR = max(list_EnvR)    
    
    # Filter 4:   
    if not ( p5 == r''):
        value_to_filter_DeltaH = float(p5)
    else:
        value_to_filter_DeltaH = max(list_DeltaH)    
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
     
    arcpy.AddMessage(r'Extracting LCPs from input layer, please wait....')
    
    # Filter 1:
    #..........................................................................    
        
    # Use the ID to select by attribute:
    SQL_expression  = r'"'+ r'Shape_Length' + r'"<= ' +  str(value_to_filter_PathLenght)

    # Create a new TEMP layer to save the selection:
    layer_filter1 = os.path.join(location_results,r'layer_filter_1')
    filter_1=arcpy.MakeFeatureLayer_management(layer_LCPs, 'layer_filter_1', SQL_expression)
    
    arcpy.CopyFeatures_management(filter_1, layer_filter1)
    
    #..........................................................................
    arcpy.AddMessage(r'Filter for Shape_Length applied successfully !')

    
    # Filter 2:
    #..........................................................................    
    
    # Use the ID to select by attribute:
    SQL_expression  = r'"'+ r'PathCost' + r'"<= ' +  str(value_to_filter_PathCost)

    # Create a new TEMP layer to save the selection:
    layer_filter2 = os.path.join(location_results,r'layer_filter_2')
    filter_2=arcpy.MakeFeatureLayer_management(layer_filter1, 'layer_filter_2', SQL_expression)
    
    arcpy.CopyFeatures_management(filter_2, layer_filter2)
    
    #..........................................................................
    arcpy.AddMessage(r'Filter for PathCost applied successfully !')

    
    # Filter 3:
    #..........................................................................    
    
    # Use the ID to select by attribute:
    SQL_expression  = r'"'+ r'EnvRes' + r'"<= ' +  str(value_to_filter_EnvR)

    # Create a new TEMP layer to save the selection:
    layer_filter3 = os.path.join(location_results,r'layer_filter_3')
    filter_3=arcpy.MakeFeatureLayer_management(layer_filter2, 'layer_filter_3', SQL_expression)
    
    arcpy.CopyFeatures_management(filter_3, layer_filter3)
    
    #..........................................................................
    arcpy.AddMessage(r'Filter for EnvRes applied successfully !')
    
    # Filter 4:
    #..........................................................................
    
    # Use the ID to select by attribute:
    SQL_expression  = r'"'+ r'Delta_H' + r'"<= ' +  str(value_to_filter_DeltaH)

    # Create a new TEMP layer to save the selection:
    layer_filter4 = os.path.join(location_results,r'layer_filter_4')
    filter_4=arcpy.MakeFeatureLayer_management(layer_filter3, 'layer_filter_4', SQL_expression)
    
    arcpy.CopyFeatures_management(filter_4, layer_filter4)
    
    #..........................................................................
    arcpy.AddMessage(r'Filter for Delta_H applied successfully !')
    
    # Create layer resutls:
    #..........................................................................
    result_path= os.path.join(location_results,results_name_file)
    arcpy.CopyFeatures_management(layer_filter4, result_path)
    #..........................................................................
    arcpy.AddMessage(r'Layer with filtered LCPs lcoated at:' + result_path)


    # Delete TEMP files:
    #..........................................................................
    arcpy.Delete_management(layer_filter1)
    arcpy.Delete_management(layer_filter2)
    arcpy.Delete_management(layer_filter3)
    arcpy.Delete_management(layer_filter4)
    #..........................................................................
        
    
#..............................................................................

###############################################################################
#      ^      ^      ^      ^      ^      ^      ^      ^  Definition of Main() 
###############################################################################   


###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6,p7)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################


