# -*- coding: utf-8 -*-
"""
Created on Mon Jul  4 11:47:59 2022

This script uses a layer with nodes to update the attributes of an LCP layer
The layer with nodes should have a field with the same ID used to create the 
field 'PathDes' in the layer with LCPs 

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""

###############################################################################
#%%               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with the Python interpreter of ArcGIS Pro.

# location of python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 


###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#                                                     PACKAGES YOU NEED TO LOAD
###############################################################################

import os
import sys
import time
import math

import openpyxl
from openpyxl import load_workbook, Workbook

import pandas as pd
import arcpy
from arcpy.sa import *
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^   EMD OF PACKAGES YOU NEED TO LOAD
###############################################################################

###############################################################################
#                                 Pre - run 
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

#Checkout Spatial Analyst extension
arcpy.AddMessage("Checking license... ")

if arcpy.CheckExtension("Spatial") == "Available":
    arcpy.CheckOutExtension("Spatial")
    arcpy.AddMessage("Spatial Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: Spatial Analyst license needed... ")
    sys.exit() 

if arcpy.CheckExtension("3D") == "Available":
    arcpy.CheckOutExtension("3D")
    arcpy.AddMessage("3D Analyst license checked out... ")
else:
    arcpy.AddMessage("Error: 3D Analyst license needed... ")
    sys.exit() 
    
###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

description_p1  = r'Location of input layer with LCPs (layer to be updated)'
description_p2  = r'Location of input layer with nodes (These attributes will be used to update LCP layer)'
description_p3  = r'Attribute name with LPCs ID / Description (No quotation marks)'
description_p4  = r'Attribute name nodes ID (No quotation marks)'
description_p5  = r'Location to save new Layer with updated LCPs'
description_p6  = r'Name of the new layer with updated LCPs'

list_p_descriptions = [description_p1,description_p2,description_p3,
                       description_p4,description_p5,description_p6]

list_of_keys =['p1','p2','p3','p4','p5','p6']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#      ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   List of inputs
###############################################################################


###############################################################################
#                                                       Definition of fucntions 
###############################################################################    

#..............................................................................

def main_function(p1,p2,p3,p4,p5,p6):
    
    time_before_execution = time.time()
    
    # Define function global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    LCP_layer=p1
    Nodes_layer=p2
    LCPs_Field_description=[p3]
    ID_Field_nodes=[p4]
    location_to_save_results=p5
    name_results_layer =p6
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # load the LCPs df
    #--------------------------------------------------------------------------
    List_of_field_names_LCPs_layer = [f.name for f in arcpy.ListFields(LCP_layer)]    
    List_of_field_names_LCPs_layer.remove('Shape')   
    
    NP_Array_LCPs_attribute_table =  arcpy.da.FeatureClassToNumPyArray (LCP_layer,List_of_field_names_LCPs_layer,skip_nulls=False,null_value=-99999)
    df_input_LCPs = pd.DataFrame(NP_Array_LCPs_attribute_table, columns = List_of_field_names_LCPs_layer)
    
    list_of_LCPs_Des = df_input_LCPs[LCPs_Field_description[0]].tolist()
    
    Number_of_LCPs=len(list_of_LCPs_Des) 
    #--------------------------------------------------------------------------
    
    
    # load the nodes df
    #--------------------------------------------------------------------------
    List_of_field_names_nodes_layer = [f.name for f in arcpy.ListFields(Nodes_layer)]    
    List_of_field_names_nodes_layer.remove('Shape')   
    
    NP_Array_nodes_attribute_table =  arcpy.da.FeatureClassToNumPyArray (Nodes_layer,List_of_field_names_nodes_layer,skip_nulls=False,null_value=-99999)
    df_input_nodes = pd.DataFrame(NP_Array_nodes_attribute_table, columns = List_of_field_names_nodes_layer)
    
    list_of_nodes_IDs = df_input_nodes[ID_Field_nodes[0]].tolist()
    
    Number_of_nodes=len(list_of_nodes_IDs) 
    
    # Delete the fields you are not using
    df_input_nodes.drop(['OBJECTID'], axis=1, inplace=True)    
    #--------------------------------------------------------------------------

    
    # Filter the input list of LCPs descriptions using the IDs of the input 
    # nodes layer:
    #..........................................................................
    
    list_of_LCPs_Des_to_update =[]
    
    for node in list_of_nodes_IDs:
        
        arcpy.AddMessage(r'Filtering LCPs for node: ' + str(node) )
        
        list_of_LCPs_to_update_current_node =[]
        
        for LCP_Des in list_of_LCPs_Des:
            
            list_LCPs_Des_parts = LCP_Des.split("-")
            Origin = list_LCPs_Des_parts[1]
            Destination= list_LCPs_Des_parts[3]
            
            if(Origin == str(node) or Destination ==str(node)):
                list_of_LCPs_to_update_current_node.append(LCP_Des)
                 
        arcpy.AddMessage(r'Number of LCPs:' + str(len(list_of_LCPs_to_update_current_node)))
        
        list_of_LCPs_Des_to_update=  list_of_LCPs_Des_to_update + list_of_LCPs_to_update_current_node
    
    list_of_LCPs_Des_to_update= list(set(list_of_LCPs_Des_to_update))
    
    Number_of_LCPs_to_update = len(list_of_LCPs_Des_to_update)
    
    df_LCPs_to_be_updated= (df_input_LCPs.loc[df_input_LCPs[LCPs_Field_description[0]].isin(list_of_LCPs_Des_to_update)])
    
    Fields_to_keep= [LCPs_Field_description[0], r'OriginID', r'DestinID']
    
    df_des_LCPs_to_be_updated = df_LCPs_to_be_updated[Fields_to_keep].copy()
    
    #Debuggin:
    #list_of_unique_Origins = list(set([des.split("-")[1] for des in list_of_LCPs_Des_to_update]))  
    #list_of_unique_Destinations = list(set([des.split("-")[3] for des in list_of_LCPs_Des_to_update]))  
    
    #..........................................................................
    
    
    # Make a df with the LCP values to update:
    #..........................................................................
    
    Field_names_nodes_layer     = ['ID_MCI','TYPE','NODE','Elevation_M','STATUS','NAME','Q_m3s'] 
    
    Origin_node_attributes      = ['O_MCI','O_type','O_Node','O_elev','O_status','O_name','O_Qm3s']
    Destination_node_attributes = ['D_MCI','D_type','D_Node','D_elev','D_status','D_name','D_Qm3s']
    
    dict_to_rename_O_fields = dict(zip(Field_names_nodes_layer, Origin_node_attributes)) 
    dict_to_rename_D_fields = dict(zip(Field_names_nodes_layer, Destination_node_attributes)) 
    
    Fields_nodes_layer = ID_Field_nodes + ['ID_MCI','TYPE','NODE','Elevation_M','STATUS','NAME','Q_m3s']
    
    Fields_new_df_values_LCPs_layer = LCPs_Field_description + Origin_node_attributes + Destination_node_attributes
    
    # Here you merge the 7 attributes of the Origin node to the df:
    df_with_new_O_attributes =pd.merge(left=df_des_LCPs_to_be_updated, right=df_input_nodes, how='left', left_on='OriginID', right_on=ID_Field_nodes[0])
    
    # Delete the duplicate with the ID of the origin node:
    df_with_new_O_attributes.drop(['ID_CONN'], axis=1, inplace=True)    
    
    # Rename Columns of the Origin node attributes:
    df_with_new_O_attributes = df_with_new_O_attributes.rename(columns=dict_to_rename_O_fields) 
    
    # Here you merge the 7 attributes of the Destination node to the df:
    df_with_new_D_attributes =pd.merge(left=df_des_LCPs_to_be_updated, right=df_input_nodes, how='left', left_on='DestinID', right_on=ID_Field_nodes[0])
    
    # Delete the duplicate with the ID of the destination node:
    df_with_new_D_attributes.drop(['ID_CONN'], axis=1, inplace=True)
    
    # Rename Columns of the Destination node attributes:
    df_with_new_D_attributes = df_with_new_D_attributes.rename(columns=dict_to_rename_D_fields)     
    
    #..........................................................................
    
    
    # Make a copy of the LCPs layer:
    #..........................................................................
    New_LCPs_layer = os.path.join(location_to_save_results,name_results_layer)
    arcpy.CopyFeatures_management(LCP_layer, New_LCPs_layer)
    #..........................................................................
    
    
    # Go look for rows with the nodes to update and replace the columns 
    #--------------------------------------------------------------------------
    
    Fields_to_update= LCPs_Field_description + Origin_node_attributes + Destination_node_attributes
        
    LCPs_updated=1
    
    residual_for_progress = int(Number_of_LCPs_to_update/10)
    
    if(residual_for_progress == 0):
        residual_for_progress=1
    
    with arcpy.da.UpdateCursor(New_LCPs_layer, Fields_to_update) as cursor:
      
        for row in cursor:
          
          current_LCP_Des = row[0]
        
          if current_LCP_Des in list_of_LCPs_Des_to_update:
              
              # Here you Get the row with the Origin Node attributes of the current LCP:
              
              df_row_O = df_with_new_O_attributes.loc[df_with_new_O_attributes[ LCPs_Field_description[0]] == current_LCP_Des]
              
              O_MCI   =df_row_O['O_MCI'].values[0]
              O_Node  =df_row_O['O_Node'].values[0]
              O_type  =df_row_O['O_type'].values[0]
              O_status=df_row_O['O_status'].values[0]
              O_elev  =float(df_row_O['O_elev'])
              O_name  =df_row_O['O_name'].values[0]
              O_Qm3s  =float(df_row_O['O_Qm3s'])

              # Check the values are not NaN, if not then replace
              
              if (type(O_MCI) == str):
                  row[1] = O_MCI     # 'O_MCI'
                   
              if (type(O_type) == str):
                  row[2] = O_type    # 'O_type'
              
              if (type(O_Node) == str):
                  row[3] = O_Node    # 'O_Node'
              
              if not (math.isnan(O_elev)):
                  row[4] = O_elev    # 'O_elev'
              
              if (type(O_status) == str):
                  row[5] = O_status  # 'O_status'
                 
              if (type(O_name) == str):
                  row[6] = O_name    # 'O_name'
              
              if not (math.isnan(O_Qm3s)):
                  row[7] = O_Qm3s    # 'O_Qm3s'
              
              # Here you Get the row with the Origin Node attributes of the current LCP:
               
              df_row_D = df_with_new_D_attributes.loc[df_with_new_D_attributes[ LCPs_Field_description[0]] == current_LCP_Des]  
              
              D_MCI   =df_row_D['D_MCI'].values[0]
              D_Node  =df_row_D['D_Node'].values[0]
              D_type  =df_row_D['D_type'].values[0]
              D_status=df_row_D['D_status'].values[0]
              D_elev  =float(df_row_D['D_elev'])
              D_name  =df_row_D['D_name'].values[0]
              D_Qm3s  =float(df_row_D['D_Qm3s'])
              
              # Check the values are not NaN, if not then replace
              
              if  (type(D_MCI) == str):
                  row[8] = D_MCI      # 'D_MCI'
                   
              if  (type(D_type) == str):
                  row[9] = D_type     # 'D_type'
              
              if  (type(D_Node) == str):
                  row[10] = D_Node    # 'D_Node'
              
              if not (math.isnan(D_elev)):
                  row[11] = D_elev    # 'D_elev'
              
              if  (type(D_status) == str):
                  row[12] = D_status  # 'D_status'
                 
              if  (type(D_name) == str):
                  row[13] = D_name    # 'D_name'
              
              if not (math.isnan(D_Qm3s)):
                  row[14] = D_Qm3s    # 'D_Qm3s'
              
              if(LCPs_updated%residual_for_progress == 0):
                  arcpy.AddMessage( r'Row ' + str(LCPs_updated) +  r' out of ' + str(Number_of_LCPs_to_update) + ' updated')
                  elapsed_time = (time.time() - time_before_execution)
                  Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
                  Fraction_of_hours, hours =math.modf(Seconds/3600)
                  arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
              LCPs_updated =LCPs_updated +1
              cursor.updateRow(row)
    
    #--------------------------------------------------------------------------
     
    arcpy.AddMessage(r'Layer with results located at: ' + New_LCPs_layer)
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    
    #--------------------------------------------------------------------------

    
    
#..............................................................................

###############################################################################
#    ^    ^    ^    ^    ^    ^    ^    ^    ^    ^     Definition of fucntions
###############################################################################

###############################################################################
#                                                       Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)
p4 = arcpy.GetParameterAsText(3)
p5 = arcpy.GetParameterAsText(4)
p6 = arcpy.GetParameterAsText(5)

#Debugging:
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# p1 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\All_LCPs_V4_with_Attributes'
# p2 = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Scratch.gdb\CRB_nodes_with_updated_Q_values'
# p3 = r'PathDes'
# p4 = r'ID_CONN'
# p5 = r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Scratch.gdb'
# p6 = r'LCps_with_updated_values'
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

###############################################################################
#   ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3,p4,p5,p6)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################






