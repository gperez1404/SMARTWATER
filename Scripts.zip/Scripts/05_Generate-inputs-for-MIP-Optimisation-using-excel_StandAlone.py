# -*- coding: utf-8 -*-
"""
Created on Tue Jul 12 17:48:55 2022

This script receives as input an excel file with columns representing a set of
LCPs and converts it to an excel file with pivot matrices to execute 
MIP optimisation algorithms

This script creates the following objects:
    
    1: A dictionary with the demand nodes of the current scenario
        demand_dict_df = {Node_number_ID_MIP: Node_ID_GIS}
        
    2: A dictionary with the supply nodes of the current scenario
        capacity_dict_df = {Node_number_ID_MIP: Node_ID_GIS}    

    3: pivot table with the 'Shape_length' of all the possible conenctions 
       of the input problem
       
       dist =[Dist_S1-S1......]
        
    4: pivot table with the 'Delta_H' of all the possible conenctions 
       of the input problem
       
       alt =[DeltaH_S1-S1......]    
  
@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""

###############################################################################
#%%                                                   PACKAGES YOU NEED TO LOAD
###############################################################################

import os
import sys
import time
import math
import collections

import openpyxl
from openpyxl import load_workbook, Workbook

import pandas as pd
###############################################################################
#  ^    ^    ^    ^    ^    ^    ^    ^    ^   END OF PACKAGES YOU NEED TO LOAD
###############################################################################
#%%
###############################################################################
#                                                                List of inputs
###############################################################################

description_p1  = r'Input file with LCPs:'
description_p2  = r'Name of the excel sheet with values to load'
description_p3  = r'Column with LCP description (From-XXX-to-XXX)'
description_p4  = r'Column with LCP distance (Shape Length)'
description_p5  = r'Column with elevation difference between origin-destination nodes (Delta H):'
description_p6  = r'List of fields with information of origin nodes [Field_1, Field_2,....]'
description_p7  = r'List of fields with information of destination nodes [Field_1, Field_2,....]'
description_p8  = r'column with origin node type'
description_p9  = r'column with destination node type'
description_p10 = r'column with Flow rates origin nodes'
description_p11 = r'column with Flow rates destination nodes'
description_p12 = r'Location to save results'
description_p13 = r'Name of the file with outputs (No extension required):'

list_p_descriptions = [description_p1,description_p2,description_p3,description_p4,
                       description_p5,description_p6,description_p7,description_p8,
                       description_p9,description_p10,description_p11,description_p12,
                       description_p13]

list_of_keys =['p1','p2','p3','p4','p5','p6','p7','p8','p9','p10','p11','p12','p13']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 


p1  = r'R:\03_GISdata\data_Gabriel\04-Tools\02-Python-Scripts\02-Input-files-R\LCPs_Huasco_Scenario.xlsx'
p2  = r'LCPs_Huasco_Scenario'
p3  = r'PathDes'
p4  = r'Shape_Length'
p5  = r'Delta_H'
p6  = r'[O_MCI, O_type, O_Node, O_status, O_name, O_Qm3s]'
p7  = r'[D_MCI, D_type, D_Node, D_status, D_name, D_Qm3s]'
p8  = r'O_Node'
p9  = r'D_Node'
p10 = r'O_Qm3s'
p11 = r'D_Qm3s'
p12 = r'R:\03_GISdata\data_Gabriel\04-Tools\02-Python-Scripts\03-Output-files-R'
p13 = r'inputs_MIP_Huasco'



###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   List of inputs
###############################################################################

###############################################################################
#                                                          Definition of Main() 
###############################################################################    

#..............................................................................

def main(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13):
        
    time_before_execution = time.time()
    
    print(r'p1 =' + str(p1))
    print(r'p2 =' + str(p2))
    print(r'p3 =' + str(p3))
    print(r'p4 =' + str(p4))
    print(r'p5 =' + str(p5))
    print(r'p6 =' + str(p6))
    print(r'p7 =' + str(p7))
    print(r'p8 =' + str(p8))
    print(r'p9 =' + str(p9))
    print(r'p10 =' + str(p10))
    print(r'p11 =' + str(p11))
    print(r'p12 =' + str(p12))
    print(r'p13 =' + str(p13))
    
    # Define function global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        
    p6= p6.replace("[", "")
    p6= p6.replace("]", "")
    p6= p6.replace(" ", "")
    
    p7= p7.replace("]", "")
    p7= p7.replace("[", "")
    p7= p7.replace(" ", "")
    
    file_path_input_file               = p1
    Sheet_name                         = p2
    LCPs_des                           = p3
    Column_LCPs_distance               = p4
    Column_LCPs_altitude               = p5
    Fields_origin_nodes                = p6.split(r',')
    Fields_destination_nodes           = p7.split(r',')
    Column_name_node_type_origin       = p8
    Column_name_node_type_destination  = p9
    Column_name_Q_origin               = p10
    Column_name_Q_destiantion          = p11
    location_results                   = p12
    results_name_file                  = p13
    
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    
    # Load the excel sheet with info of connections:
    #--------------------------------------------------------------------------
    df_attribute_table = pd.read_excel(file_path_input_file,sheet_name=Sheet_name)
    
    list_of_fields = df_attribute_table.columns

    list_of_LCPs_IDs = df_attribute_table[LCPs_des].tolist()
   
    origin_nodes_list = list(set( [ID_des.split(r'-')[1] for ID_des in list_of_LCPs_IDs]))
    destiantion_nodes_list = list(set( [ID_des.split(r'-')[3] for ID_des in list_of_LCPs_IDs]))
    
    list_of_nodes_IDs = list(set(origin_nodes_list + destiantion_nodes_list))
    list_of_nodes_IDs= list(map(int, list_of_nodes_IDs))
    Total_number_of_nodes = len(list_of_nodes_IDs)
    
    print('Total number of nodes:' +  str(Total_number_of_nodes))
    
    # Create the columns with the Origin ID and the Destination ID if they don't exist
    
    if not (  r'OriginID' in  list_of_fields ):
        df_attribute_table['OriginID'] = origin_nodes_list
        
    if not (  r'DestinID' in  list_of_fields ):
        df_attribute_table['DestinID'] = destiantion_nodes_list    
    
    #-------------------------------------------------------------------------- 
    
    # Create a df with the information of origin nodes:
    #--------------------------------------------------------------------------
    df_origin_nodes = df_attribute_table.copy()
    
    fields_to_keep   = ['OriginID']  +  Fields_origin_nodes
    fields_to_delete = [item for item in list_of_fields if item not in fields_to_keep]
    
    df_origin_nodes.drop(fields_to_delete, inplace=True, axis=1)
    
    df_origin_nodes.rename(columns={'OriginID':'nodeID',
                                    Column_name_node_type_origin: 'Node',
                                    Column_name_Q_origin: 'Qm3s'},
                           inplace=True)
    
    # here you delete all the repeated rows:
    df_origin_nodes.drop_duplicates(subset=['nodeID'], inplace=True)
    
    #--------------------------------------------------------------------------
    
    # Create a df with the information of destination nodes:
    #--------------------------------------------------------------------------
    df_destination_nodes = df_attribute_table.copy()
    
    fields_to_keep = ['DestinID'] + Fields_destination_nodes
    fields_to_delete = [item for item in list_of_fields if item not in fields_to_keep]
    
    df_destination_nodes.drop(fields_to_delete, inplace=True, axis=1)
    
    df_destination_nodes.rename(columns={'DestinID':'nodeID', 
                                         Column_name_node_type_destination: 'Node',
                                         Column_name_Q_destiantion: 'Qm3s'}, inplace=True)
    
    df_destination_nodes.drop_duplicates(subset=['nodeID'], inplace=True)
    
    #--------------------------------------------------------------------------
    
    
    # Merge the dfs with nodes info:
    #--------------------------------------------------------------------------
    df_origin_nodes_to_merge      = df_origin_nodes.copy()
    df_destination_nodes_to_merge = df_destination_nodes.copy()
    
    fields_to_keep = ['nodeID', 'Node' , 'Qm3s']
    
    fields_ori = df_origin_nodes_to_merge.columns
    
    fields_to_delete =  [item for item in fields_ori if item not in fields_to_keep]
    df_origin_nodes_to_merge.drop(fields_to_delete, inplace=True, axis=1)
    
    fields_des = df_destination_nodes_to_merge.columns    
     
    fields_to_delete = [item for item in fields_des if item not in fields_to_keep]
    df_destination_nodes_to_merge.drop(fields_to_delete, inplace=True, axis=1)
    
    df_nodes_info = pd.concat([df_origin_nodes_to_merge,df_destination_nodes_to_merge ], ignore_index=True)
    df_nodes_info.drop_duplicates(subset=['nodeID'], inplace=True)
    
    #--------------------------------------------------------------------------
    
    # Generate the dictionary of nodes:
    #--------------------------------------------------------------------------
    
    # Get df with the attributes of nodes with NODE == D:
    df_demnad_nodes = df_nodes_info[(df_nodes_info["Node"] == r'D')]
    
    # Get df with the attributes of nodes with  NODE== S:
    df_supply_nodes = df_nodes_info[(df_nodes_info["Node"] == r'S')]
    
    # Re-order the dfs using the Node IDs:
    df_demnad_nodes.sort_values(by=['nodeID'], ascending=[True],inplace=True)
    df_supply_nodes.sort_values(by=['nodeID'], ascending=[True],inplace=True)
    
    list_demand_nodes = df_demnad_nodes['nodeID'].tolist()
    list_supply_nodes = df_supply_nodes['nodeID'].tolist()
        
    # Generate the new Number_IDs for the MIP inputs:   

    MIP_IDs_supply_nodes = list(range(0,len(list_supply_nodes)))
    MIP_IDs_demand_nodes = list(range(len(list_supply_nodes), len(list_supply_nodes) + len(list_demand_nodes)))
    
    list_of_keys_supply = [str(node) for node in list_supply_nodes]
    list_of_keys_demand = [str(node) for node in list_demand_nodes]
    
    # Create the dictionary for Supply nodes (capcaity):
    dict_supply_nodes = dict(zip(list_of_keys_supply, MIP_IDs_supply_nodes)) 
    
    # Create the dictionary for demand nodes (demand):
    dict_demand_nodes = dict(zip(list_of_keys_demand, MIP_IDs_demand_nodes)) 
    
    #--------------------------------------------------------------------------
    
    # Generate inputs MIP:
    #--------------------------------------------------------------------------    
        
    df_MIP_values = df_attribute_table.copy()
    
    # Use the dictionaries to re-map the ID values
    
    list_of_keys_supply_numbers =  [node for node in list_supply_nodes]
    list_of_keys_demand_numbers =  [node for node in list_demand_nodes]
    
    list_of_keys_numbers = list_of_keys_demand_numbers + list_of_keys_supply_numbers
    list_of_MIP_IDs      = MIP_IDs_demand_nodes + MIP_IDs_supply_nodes
    
    dict_nodes_numbers = dict(zip(list_of_keys_numbers,list_of_MIP_IDs)) 
        
    df_MIP_values=df_MIP_values.replace({"OriginID": dict_nodes_numbers})
    df_MIP_values=df_MIP_values.replace({"DestinID": dict_nodes_numbers})

    
    # sort the df with LCPs attributes using the new order : nodes capacity (supply) > nodes demand
    
    df_MIP_values.sort_values(by=['DestinID'], ascending=[True],inplace=True)
    df_MIP_values.sort_values(by=['OriginID'], ascending=[True],inplace=True)
    
    # Generate the pivot table (matrix) with the Shape_lenght between nodes (distance)
    distance = pd.pivot_table(df_MIP_values,index='DestinID',columns='OriginID',values=Column_LCPs_distance)
    
    # Generate the pivot table (matrix) with the DElta H between nodes (altitude)
    altitude = pd.pivot_table(df_MIP_values,index='DestinID',columns='OriginID',values=Column_LCPs_altitude)
    
    capacity_dict_df = pd.DataFrame(dict_supply_nodes.items())
    demand_dict_df   = pd.DataFrame(dict_demand_nodes.items())
    
    capacity_dict_df.columns = ['GIS_ID','MIP_ID']
    demand_dict_df.columns   = ['GIS_ID','MIP_ID']
    
    GIS_ids_capacity = capacity_dict_df['GIS_ID']
    GIS_ids_demand   = demand_dict_df['GIS_ID']  
    
    capacity_dict_df.drop(labels=['GIS_ID'], axis=1, inplace = True)
    demand_dict_df.drop(labels=['GIS_ID'], axis=1, inplace = True)
    
    capacity = capacity_dict_df.copy()
    demand   = demand_dict_df.copy()
    
    capacity_Qs = df_supply_nodes['Qm3s'].tolist()
    demand_Qs   = df_demnad_nodes['Qm3s'].tolist()
    
    capacity.insert(1, 'Q',capacity_Qs)
    demand.insert(1, 'Q',demand_Qs)
    
    capacity=  capacity.transpose()
    demand =   demand.transpose()
    
    capacity_dict_df.insert(1, 'GIS_ID', GIS_ids_capacity)
    demand_dict_df.insert(1, 'GIS_ID', GIS_ids_demand)
    
    nodes_dict_df = pd.concat([capacity_dict_df,demand_dict_df ], ignore_index=True)
    nodes_dict_df = nodes_dict_df.transpose()
     
    #--------------------------------------------------------------------------
    
    # Write the results in an excel file:
    #--------------------------------------------------------------------------
    
    file_path_results = os.path.join(location_results, results_name_file + r'.xlsx')
    
    with pd.ExcelWriter(file_path_results) as writer:
        distance.to_excel(writer, sheet_name='distance', index=False)
        altitude.to_excel(writer, sheet_name = 'altitude',index=False)
        capacity.to_excel(writer, 'capacity', index=False, header=False)
        demand.to_excel(writer, 'demand', index=False, header=False)
        nodes_dict_df.to_excel(writer, 'nodes_dictionary',index=False, header=False)       
    
    #--------------------------------------------------------------------------
        
    print('Result file located at:' +  file_path_results)
    
    # Print execution time in console:
    #..........................................................................
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    
    print('Total execution time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    #..........................................................................    
    
###############################################################################
#        ^      ^      ^      ^      ^      ^      ^       Definition of Main() 
###############################################################################   

###############################################################################
#                                                                         Start
###############################################################################

if __name__ == "__main__":
    main(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13)
    print("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################


