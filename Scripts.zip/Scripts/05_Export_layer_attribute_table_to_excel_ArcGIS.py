# -*- coding: utf-8 -*-
"""
This script exports the attribute table of a layer to the specified location:

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""
###############################################################################
#               IMPORTANT REMARKS BEFORE RUNNING THIS SCRIPT
###############################################################################

# You need to have an ArcGIS license to run this script because it 
# imports arcpy. Even if you run the script as standalone you still need 
# a license.

# The script has been written as a function to be called after getting 
# parameters from ArcGIS user interface (GUI). Therefore, this script  only 
# works as it is under ArcGISPro GUI creating a script object inside a .tbx 
# in the "Toolboxes" section of the Catalog tab.  

# To run as a standalone script (without ARCGIS GUI) you need to manually give 
# values to all the inputs and delete the code section called
#  "Getting inputs from GUI". 

# To run as a standalone script you need to connect the python IDE (Spyder) 
# with the Python interpreter of ArcGIS Pro.

# location of python interpreter of ArcGIS Pro:
# C:\Program Files\ArcGIS\Pro\bin\Python\envs\arcgispro-py3\python.exe 


###############################################################################
#  ^    ^     ^  IMPORTANT REMARKS BEFORE RUNNING THIS MODEL    ^    ^     ^  
###############################################################################

###############################################################################
#%%                        PACKAGES YOU NEED TO LOAD
###############################################################################
 
# These are the packages you need to load files

import os
from pathlib import Path

import arcpy

import numpy as np
import pandas as pd

# Allow output to overwrite...
arcpy.env.overwriteOutput = True

# Check out the ArcGIS Spatial Analyst extension license
arcpy.CheckOutExtension("Spatial")

###############################################################################
# ^  ^  ^  ^  ^  ^  ^   PACKAGES YOU NEED TO LOAD       ^  ^  ^  ^  ^  ^  ^ 
###############################################################################

###############################################################################
#                            Pre - run procedures
###############################################################################

# Allow outputs to overwrite...
arcpy.env.overwriteOutput = True

###############################################################################
#         ^       ^      ^     pre- run procedures    ^       ^      ^    
###############################################################################

###############################################################################
#                                                                        Inputs
###############################################################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Values for Debugging:
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
# p_1= r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\SMARTWSMCI_GPM.gdb\All_LCPs_V4_with_Attributes'
# p_2= r'E:\00-GPM\SMARTWSMCI_SMI_C1TTTSY\SMARTWSMCI_SMI_C1TTTSY_Files'
# p_3= r'attribute table'
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    

#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

# Description of inputs:
#..............................................................................
description_p1    = r'file path with the layer or shapefile you want to convert to excel' 
description_p2    = r'location to save the new excel file'
description_p3    = r'Name of the new file (Without extension)'


list_p_descriptions = [description_p1,description_p2]

list_of_keys =['p1','p2','p3']
dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Inputs
###############################################################################


#..............................................................................
def main_function(p1,p2,p3):
    
    # here you create a paths to the attribute table and the result:
    path = Path(p1)
    parent_path= str(path.parent.absolute())

    layer_name =p1
    layer_name= layer_name.strip(parent_path)

    output_filename_with_extension = p3 + r'.xls'

    output_attribute_table= os.path.join(p2,output_filename_with_extension)

    # convert the attribute table into an Excel table
    arcpy.TableToExcel_conversion(p1, output_attribute_table)
    arcpy.AddMessage(r'Table created successfully at: ' + str(output_attribute_table))



###############################################################################
#                                                      Getting inputs from GUI
###############################################################################
#
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# Debugging:
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# p1= p_1
# p2= p_2
# p3= p_3
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)
p3 = arcpy.GetParameterAsText(2)

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2,p3)

arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################