# -*- coding: utf-8 -*-
"""
Created on Mon August 15  07:30:00 2022

This script cretaes the folder structure of a new project 

@author: Gabriel Perez Murillo 
         The University of Queensland
         Created as part of SMARTW project in association with SMI-ICE
         for technical questions and support: g.perezmurillo@uq.edu.au
"""

###############################################################################
##%%                        PACKAGES YOU NEED TO LOAD
###############################################################################

import os 
import sys
import pickle
import requests

import arcpy
from arcpy.sa import *

import shutil
import string
import math
import time 

###############################################################################
# ^  ^  ^  ^  ^  ^  ^   PACKAGES YOU NEED TO LOAD       ^  ^  ^  ^  ^  ^  ^ 
###############################################################################

###############################################################################
#                                                              Define functions
###############################################################################
#..............................................................................
def create_new_GDB(location_to_create_GDB,GDB_name):
    
    GDB_name_with_extension = GDB_name + r'.gdb'
    
    GDB_path= os.path.join(location_to_create_GDB,GDB_name_with_extension)
    
    # Remove the Geodatbase in case it exists 
    try:
        if (os.path.isdir(GDB_path)):
            shutil.rmtree(GDB_path)
            arcpy.AddMessage(r' Geodatabase: ' + GDB_name_with_extension  + ' was deleted')
    except ValueError:
        warnings.warn( r' Geodatabase: '   + GDB_name_with_extension    + r' could not be deleted !')
        pass
    
    # Create Geo-database: 
    arcpy.management.CreateFileGDB(location_to_create_GDB, GDB_name, "CURRENT")
    arcpy.AddMessage( r' Geodatabase:' + GDB_name + ' was created successfully !')
#..............................................................................

#..............................................................................
def create_new_folder(location, folder_name):
    
    folder_path =os.path.join(location,folder_name)
    
    if os.path.isdir(folder_path):
        #  check if the folder already exisit delete it to avoid errors
        try:
            shutil.rmtree(folder_path)
            arcpy.AddMessage(r' Folder: ' + folder_name + ' already existed and was deleted')
        except ValueError:
            warnings.warn( r' Folder: ' + folder_name + ' could not be deleted !')
            pass
     
        # create the folder again
        os.mkdir(folder_path)
    else:
           os.mkdir(folder_path)
           arcpy.AddMessage(r' Folder: ' + folder_name + ' did not exist and was deleted')
#..............................................................................

###############################################################################
#     ^     ^     ^     ^     ^     ^     ^     ^     ^       Define functions
###############################################################################

###############################################################################
#                                                                List of inputs
###############################################################################

# Description of inputs:
#..............................................................................
description_p1 = r'Select the folder location to create new project:'
description_p2 = r'Project names (No spaces):'
description_p3 = r'Url of Repository to download tools (Optional):'


list_p_descriptions = [description_p1,description_p2]

default_values_p1 = r'R:\03_GISdata\data_Gabriel\05-GIS\SMARTWSMCI_GPM\Scenario_Huasco.gdb\Nodes_Huasco_Scenario'
default_values_p2 = r'Workshop_2022'

list_of_keys =['p1','p2']

dict_parameters = dict(zip(list_of_keys, list_p_descriptions)) 

###############################################################################
#    ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  List of inputs
###############################################################################

###############################################################################
#                                                          Definition of Main() 
###############################################################################    

#..............................................................................

def main_function(p1,p2):

    time_before_execution = time.time()
    
    arcpy.AddMessage(r'p1 =' + str(p1))
    arcpy.AddMessage(r'p2 =' + str(p2))
    
    # Define function global variables:
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Root_folder  = p1
    Project_name = p2
    Repo_url     = p3
    #>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # Create Root_folder:
    Project_path =os.path.join(Root_folder, Project_name)
    create_new_folder(Root_folder, Project_name)
    
    # Create sub-folders:
    create_new_folder(Project_path, r'00_Paths')
    create_new_folder(Project_path, r'01_Tools')
    create_new_folder(Project_path, r'02_Data')
    create_new_folder(Project_path, r'03_Results_Spatial_Optimisation')
    create_new_folder(Project_path, r'04_Results_Numeric_Optimisation')
    create_new_folder(Project_path, r'05_Documentation')
    
    # Create sub-folders within the '02_Data' folder:
    Data_path = os.path.join(Project_path, r'02_Data')
        
    create_new_folder(Data_path, r'021_GIS')     
    create_new_folder(Data_path, r'022_Templates')
    create_new_folder(Data_path, r'023_Scratch_data')
    create_new_folder(Data_path, r'024_Optimisation_scenarios')
    
    # Create the Geodatabases inside '021_GIS' folder
    GIS_path = os.path.join(Data_path, r'021_GIS')
    
    create_new_GDB(GIS_path, r'Network')
    create_new_GDB(GIS_path, r'Rasters')
    create_new_GDB(GIS_path, r'Outputs')
    create_new_GDB(GIS_path, r'Scratch')
    create_new_GDB(GIS_path, r'Temp')

    arcpy.AddMessage("All folders and GDBs created sucessfully !")
    
    elapsed_time = (time.time() - time_before_execution)
    Fraction_of_Seconds, Seconds =math.modf(elapsed_time)
    Fraction_of_hours, hours =math.modf(Seconds/3600)
    arcpy.AddMessage('Elapsed time : ' + str(round(hours)) + ' hours ' + str(round(Seconds/60)%60)+ ' minutes ' + str(round(Seconds%60))+' seconds' )
    
    # Create a dictionary file with the default paths:
    
    path_to_save_GIS_results = r''
        
    with open('saved_dictionary.pkl', 'wb') as f:
    pickle.dump(dictionary, f)
    
    # Download the scripts from GitHUB:
    url = "https://github.com/someguy/brilliant/blob/master/somefile.txt"

        
    
#..............................................................................    
    
    
    
###############################################################################
#                                                      Getting inputs from GUI
###############################################################################

p1 = arcpy.GetParameterAsText(0)
p2 = arcpy.GetParameterAsText(1)

###############################################################################
# ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^    Getting inputs from GUI
###############################################################################

###############################################################################
#                                                                         Start
###############################################################################

main_function(p1,p2)
arcpy.AddMessage("Script executed sucessfully... ")

###############################################################################
#%%     ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^  ^   ^  ^   End
###############################################################################
